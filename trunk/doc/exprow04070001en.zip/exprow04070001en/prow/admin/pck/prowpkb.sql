--
-----------------------------------------------------------------------------
--
--   PVCS Identifiers :-
--
--       PVCS id          : $Header:   //vm_latest/archives/prow/pck/prowpkb.sql-arc   2.4   Jun 27 2013 15:42:02   James.Wadsworth  $
--       Module Name      : $Workfile:   prowpkb.sql  $
--       Date into PVCS   : $Date:   Jun 27 2013 15:42:02  $
--       Date fetched Out : $Modtime:   Jun 27 2013 12:36:10  $
--       Version          : $Revision:   2.4  $
--
--   Product upgrade script
--
-----------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
-----------------------------------------------------------------------------

SET echo OFF
SET term OFF

col run_file new_value run_file noprint


SET define ON

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_access_land_parcel_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_address_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_definitive_stat_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_deposition_contact_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_deposition_parcel_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_deposition_renewal_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_deposition_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_enforcement_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_land_contact_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_land_designations_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_land_restriction_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_mod_order_contact_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_mod_order_cost_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_mod_order_objection_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_mod_order_panel_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_mod_order_path_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_mod_order_resol_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_mod_order_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_party_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_path_closure_cost_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_path_closure_ext_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_path_closure_path_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_path_closure_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_path_order_contact_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_path_order_cost_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_path_order_path_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_path_order_resol_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_path_order_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_prosecution_offence_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_prosecution_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_pros_enforcement_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_utilities.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_vehicle_license_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_vehicle_lic_cont_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_vehicle_lic_path_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_worktray_block_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_worktray_role_v_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_audit_api.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prow_worktray.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prowsplit.pkw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prowmerge.pkw' run_file
FROM dual
/
START '&run_file'


SET term ON
