-- SCCS ID Keyword, do not remove
define sccsid = '$Header:   //vm_latest/archives/prow/trg/prowtrg.sql-arc   2.1   Jun 27 2013 15:44:42   James.Wadsworth  $'

------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
--
--	This should be executed during upgrades and new installations.
--
------------------------------------------------------------------------

SET echo OFF
SET term OFF

col run_file new_value run_file noprint


SET define ON

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_access_land_parcel_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_access_land_parcel_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_access_land_parcel_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_address_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_address_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_address_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_definitive_stat_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_definitive_stat_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_definitive_stat_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_deposition_contact_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_deposition_contact_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_deposition_contact_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_deposition_parcel_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_deposition_parcel_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_deposition_parcel_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_deposition_renewal_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_deposition_renewal_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_deposition_renewal_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_deposition_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_deposition_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_deposition_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_enforcements_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_enforcements_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_enforcements_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_land_contact_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_land_contact_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_land_contact_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_land_designation_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_land_designation_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_land_designation_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_land_restriction_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_land_restriction_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_land_restriction_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_contact_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_contact_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_contact_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_cost_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_cost_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_cost_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_objection_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_objection_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_objection_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_panel_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_panel_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_panel_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_path_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_path_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_path_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_resol_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_resol_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_resol_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_party_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_party_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_party_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_closure_cost_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_closure_cost_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_closure_cost_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_closure_ext_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_closure_ext_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_closure_ext_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_closure_path_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_closure_path_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_closure_path_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_closure_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_closure_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_closure_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_contact_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_contact_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_contact_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_cost_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_cost_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_cost_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_path_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_path_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_path_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_resol_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_resol_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_resol_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_prosecutions_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_prosecutions_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_prosecutions_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_prosecution_offence_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_prosecution_offence_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_prosecution_offence_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_pros_enforcement_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_pros_enforcement_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_pros_enforcement_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_vehicle_licenses_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_vehicle_licenses_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_vehicle_licenses_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_vehicle_lic_cont_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_vehicle_lic_cont_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_vehicle_lic_cont_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_vehicle_lic_path_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_vehicle_lic_path_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_vehicle_lic_path_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_worktray_block_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_worktray_block_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_worktray_block_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_worktray_role_v_del.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_worktray_role_v_ins.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_worktray_role_v_upd.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_closure_paths_audit.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_closures_audit.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_order_paths_audit.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_path_orders_audit.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_orders_audit.trg' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prow_mod_order_paths_audit.trg' run_file
FROM dual
/
START '&run_file'
SET term ON
