-- SCCS ID Keyword, do not remove
define sccsid = '$Header:   //vm_latest/archives/prow/views/prowviews.sql-arc   2.1   Jun 27 2013 15:45:48   James.Wadsworth  $'

------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
--
--	This should be executed during upgrades and new installations.
--
------------------------------------------------------------------------

SET echo OFF
SET term OFF

col run_file new_value run_file noprint

SET define ON

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'hig_module_links_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_access_lands_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_access_land_details_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_access_land_parcels_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_action_summary_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_address_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_definitive_statement_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_depositions_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_deposition_contacts_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_deposition_parcels_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_deposition_renewals_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_enforcements_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_enforcement_summary_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_enquiry_summary_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_land_contacts_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_land_designations_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_land_parcels_summary_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_land_parcels_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_land_restrictions_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_mod_orders_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_mod_order_contacts_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_mod_order_costs_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_mod_order_objections_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_mod_order_panels_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_mod_order_paths_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_mod_order_resolutions_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_parties_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_paths_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_path_closures_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_path_closure_costs_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_path_closure_extensions_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_path_closure_paths_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_path_details_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_path_orders_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_path_order_contacts_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_path_order_costs_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_path_order_paths_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_path_order_resolutions_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_prosecutions_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_prosecution_offences_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_pros_enforcements_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_vehicle_licence_cont_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_vehicle_licenses_all_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_vehicle_licenses_path_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_vehicle_licenses_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_worktray_blocks_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_worktray_roles_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_audit_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_audit_rec_type_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_mod_orders_summary_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_path_closures_summary_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_path_orders_summary_v.vw' run_file
FROM dual
/
START '&run_file'

SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prow_work_order_summary_v.vw' run_file
FROM dual
/
START '&run_file'

SET term ON
