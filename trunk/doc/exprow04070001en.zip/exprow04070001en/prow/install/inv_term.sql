-----------------------------------------------------------------------------
--
--   SCCS Identifiers :-
--
--       sccsid           : $Header:   //vm_latest/archives/prow/install/inv_term.sql-arc   2.1   Jun 27 2013 15:46:42   James.Wadsworth  $
--       Module Name      : $Workfile:   inv_term.sql  $
--       Date into SCCS   : $Date:   Jun 27 2013 15:46:42  $
--       Date fetched Out : $Modtime:   Jun 27 2013 12:53:54  $
--       SCCS Version     : $Revision:   2.1  $
--
-----------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
-----------------------------------------------------------------------------
undefine leave_it
col leave_it new_value leave_it noprint
set term on
prompt
prompt &exor_base was specified as the exor base location.
prompt
prompt Value entered for exor base does not end with a recognised directory
prompt terminator. 
prompt
prompt Please re-run the installation script and enter a valid exor base value.
prompt
prompt
prompt
accept leave_it prompt "Press RETURN to exit SQL*PLUS"
prompt
exit;
