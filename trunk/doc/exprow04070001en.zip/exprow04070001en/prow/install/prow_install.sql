--------------------------------------------------------------------------------
--   PVCS Identifiers :-
--
--       sccsid           : $Header:   //vm_latest/archives/prow/install/prow_install.sql-arc   2.14   Dec 10 2013 16:06:10   Chris.Baugh  $
--       Module Name      : $Workfile:   prow_install.sql  $
--       Date into PVCS   : $Date:   Dec 10 2013 16:06:10  $
--       Date fetched Out : $Modtime:   Dec 10 2013 16:05:54  $
--       PVCS Version     : $Revision:   2.14  $
--
--------------------------------------------------------------------------------
-- Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
--------------------------------------------------------------------------------
--
set echo off
set linesize 120
set heading off
set feedback off
--
---------------------------------------------------------------------------------------------------
--                             ****************** LOG FILE *******************
-- Grab date/time to append to log file names this is standard to all upgrade/install scripts
--
undefine log_extension
col         log_extension new_value log_extension noprint
set term off
select  TO_CHAR(sysdate,'DDMONYYYY_HH24MISS')||'.LOG' log_extension from dual
/
set term on

define logfile1='prow_install_1_&log_extension'
define logfile2='prow_install_2_&log_extension'
spool &logfile1
--
---------------------------------------------------------------------------------------------------
--                                     ********** CHECKS  ***********
select 'Installation Date ' || to_char(sysdate, 'DD-MON-YYYY HH24:MI:SS') from dual;

SELECT 'Install Running on ' ||LOWER(USER||'@'||instance_name||'.'||host_name)||' - DB ver : '||version
FROM v$instance;

SELECT 'Current version of '||hpr_product||' ' ||hpr_version
FROM hig_products
WHERE hpr_product IN ('HIG','NET','MAI','ENQ');

WHENEVER SQLERROR EXIT

--
-- Check that the user isn't sys or system
--
BEGIN
   --
      IF USER IN ('SYS','SYSTEM')
       THEN
         RAISE_APPLICATION_ERROR(-20000,'You cannot install this product as ' || USER);
      END IF;
END;
/

--
-- Check that PROW has not already been installed
--
begin
   --
  for v_recs in (select hpr_version
                  from   user_tables
                        ,hig_products
                  where  hpr_product = 'PROW'
                  and    table_name = 'PROW_PROSECUTIONS') loop
     raise_application_error (-20000
                             , 'PROW version ' || v_recs.hpr_version || ' already installed.');
   end loop;
end;
/

--
-- Check that HIG, MAI and ENQ have been installed @ v4.7.0.0, as PROW is dependent on the changes @ v4.7.0.0
--
BEGIN
 hig2.product_exists_at_version (p_product        => 'HIG'
                                ,p_VERSION        => '4.7.0.0'
                                );

 hig2.product_exists_at_version (p_product        => 'MAI'
                                ,p_VERSION        => '4.7.0.0'
                                );

 hig2.product_exists_at_version (p_product        => 'ENQ'
                                ,p_VERSION        => '4.7.0.0'
                                );
END;
/

WHENEVER SQLERROR CONTINUE
--
---------------------------------------------------------------------------------------------------
--                    ********************* TABLES *************************
SET TERM ON
Prompt Tables...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'prow'||'&terminator'||'install'||
        '&terminator'||'prow.tab' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                    ********************* SEQUENCES *************************
SET TERM ON
Prompt Sequences...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'prow'||'&terminator'||'install'||
        '&terminator'||'prow.sqs' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                    ********************* CONSTRAINTS *************************
SET TERM ON
Prompt Constraints...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'prow'||'&terminator'||'install'||
        '&terminator'||'prow.con' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                    ********************* INDEXES *************************
SET TERM ON
Prompt Indexes...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'prow'||'&terminator'||'install'||
        '&terminator'||'prow.ind' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                    ********************* PACKAGE HEADERS *************************
SET TERM ON
Prompt Package Headers...
--SET TERM OFF
SET DEFINE ON
select '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prowpkh.sql' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                    ********************* VIEWS *************************
SET TERM ON
Prompt Views...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'prowviews.sql' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                    ********************* PACKAGE BODIES *************************
SET TERM ON
Prompt Package Bodies...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'pck'||'&terminator'||'prowpkb.sql' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                    ********************* TRIGGERS *************************
SET TERM ON
Prompt Triggers...
SET TERM OFF
SET DEFINE ON
SELECT '&exor_base'||'prow'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'prowtrg.sql' run_file
FROM dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF

SET TERM ON
PROMPT Who Triggers
SET TERM OFF
SET DEFINE ON
SELECT '&exor_base'||'nm3'||'&terminator'||'admin'||'&terminator'||'trg'||
       '&terminator'||'who_trg.sql' run_file
FROM dual
/
SET FEEDBACK ON
start &&run_file
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                        ****************   COMPILE SCHEMA   *******************
SET TERM ON
Prompt Creating Compiling Schema Script...
SET TERM OFF
SPOOL OFF

SET DEFINE ON
SELECT '&exor_base'||'nm3'||'&terminator'||'admin'||
'&terminator'||'utl'||'&terminator'||'compile_schema.sql' run_file
FROM dual
/
START '&run_file'

spool &logfile2

--get some db info
select 'Install Date ' || to_char(sysdate, 'DD-MON-YYYY HH24:MI:SS') from dual;
SELECT 'Install Running on ' ||LOWER(username||'@'||instance_name||'.'||host_name)||' - DB ver : '||version
FROM v$instance
    ,user_users;

START compile_all.sql
--
---------------------------------------------------------------------------------------------------
--                    ********************* META-DATA *************************
SET TERM ON
Prompt Meta-Data...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'prow'||'&terminator'||'install'||
        '&terminator'||'prowdata_install.sql' run_file
from dual
/
SET FEEDBACK ON
start &&run_file
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                        ****************   SYNONYMS   *******************
SET TERM ON
Prompt Creating Synonyms That Do Not Exist...
SET TERM OFF
EXECUTE nm3ddl.refresh_all_synonyms;
--
---------------------------------------------------------------------------------------------------
--                        ****************   ROLES  *******************
SET TERM ON
prompt Roles...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'prow'||'&terminator'||'install'||
        '&terminator'||'prowroles' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT User Roles...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'prow'||'&terminator'||'install'||
        '&terminator'||'prow_user_roles.sql' run_file
from dual
/
SET FEEDBACK ON
start &&run_file
SET FEEDBACK OFF
--
--
SET TERM ON
Prompt Updating HIG_USER_ROLES...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'nm3'||'&terminator'||'install'||
        '&terminator'||'hig_user_roles.sql' run_file
from dual
/
SET FEEDBACK ON
start &&run_file
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                        ****************   VERSION NUMBER   *******************
SET TERM ON
Prompt Setting The Version Number...
SET TERM OFF
BEGIN
      hig2.upgrade('PROW','prow_install.sql','Installed','4.7.0.1');
END;
/
COMMIT;
SELECT 'Product installed at version '||hpr_product||' ' ||hpr_version details
FROM hig_products
WHERE hpr_product IN ('PROW');
--
--
spool off
exit







