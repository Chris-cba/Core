-----------------------------------------------------------------------------
--
--   PVCS Identifiers :-
--
--       PVCS id          : $Header:   //vm_latest/archives/prow/install/prowdata1.sql-arc   2.5   Jun 27 2013 15:48:06   James.Wadsworth  $
--       Module Name      : $Workfile:   prowdata1.sql  $
--       Date into PVCS   : $Date:   Jun 27 2013 15:48:06  $
--       Date fetched Out : $Modtime:   Jun 27 2013 12:53:56  $
--       Version          : $Revision:   2.5  $
--       Table Owner      : PROW_METADATA
--       Generation Date  : 18-SEP-2009 14:09
--
--   Product metadata script
--   As at Release 4.1.0.0
--
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
--
--   TABLES PROCESSED
--   ================
--   HIG_PRODUCTS
--   HIG_MODULES
--   HIG_OPTION_LIST
--   HIG_OPTION_VALUES
--   HIG_DOMAINS
--   HIG_CODES
--   NM_ERRORS
--   HIG_CHECK_CONSTRAINT_ASSOCS
--   HIG_MODULE_BLOCKS
--   HIG_MODULE_LINKS
--   HIG_MODULE_LINK_METHODS
--   HIG_WORKTRAY_BLOCKS
--   DOC_GATEWAYS
--   DOC_GATE_SYNS
--   HIG_STANDARD_FAVOURITES
--
-----------------------------------------------------------------------------


set define off;
set feedback off;

---------------------------------
-- START OF GENERATED METADATA --
---------------------------------


----------------------------------------------------------------------------------------
-- HIG_PRODUCTS
--
-- select * from prow_metadata.hig_products
-- order by hpr_product
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_products
SET TERM OFF

INSERT INTO HIG_PRODUCTS
       (HPR_PRODUCT
       ,HPR_PRODUCT_NAME
       ,HPR_VERSION
       ,HPR_PATH_NAME
       ,HPR_KEY
       ,HPR_SEQUENCE
       ,HPR_IMAGE
       ,HPR_USER_MENU
       ,HPR_LAUNCHPAD_ICON
       ,HPR_IMAGE_TYPE
       )
SELECT 
        'PROW'
       ,'Public Rights Of Way Manager'
       ,'4.0.2.0'
       ,''
       ,80
       ,32
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_PRODUCTS
                   WHERE HPR_PRODUCT = 'PROW');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- HIG_MODULES
--
-- select * from prow_metadata.hig_modules
-- order by hmo_module
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_modules
SET TERM OFF

INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'DOC0150'
       ,'Public Enquiries'
       ,'doc0150'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'ENQ'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'DOC0150');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'MAI3806'
       ,'Defects'
       ,'mai3806'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'MAI'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'MAI3806');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'NM0105'
       ,'Elements'
       ,'nm0105'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'NET'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'NM0105');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6000'
       ,'Worktray'
       ,'prow6000'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6000');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6002'
       ,'Worktray Blocks'
       ,'prow6002'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6002');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6010'
       ,'Action Summary'
       ,'prow6010'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6010');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6012'
       ,'Enquiry Summary'
       ,'prow6012'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6012');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6014'
       ,'Work Order Summary'
       ,'prow6014'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6014');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6020'
       ,'Land Ownership'
       ,'prow6020'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6020');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6021'
       ,'Land Ownership Summary'
       ,'prow6021'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6021');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6022'
       ,'Contacts'
       ,'prow6022'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6022');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6030'
       ,'Access Land'
       ,'prow6030'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6030');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6050'
       ,'Access Land History'
       ,'prow6050'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6050');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6060'
       ,'Path History'
       ,'prow6060'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6060');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6210'
       ,'Vehicle Use Licences'
       ,'prow6210'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6210');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6220'
       ,'Enforcements'
       ,'prow6220'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6220');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6222'
       ,'Enforcement Summary'
       ,'prow6222'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6222');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6230'
       ,'Prosecutions'
       ,'prow6230'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6230');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6240'
       ,'Depositions'
       ,'prow6240'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6240');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6250'
       ,'Definitive Statement'
       ,'prow6250'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6250');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6260'
       ,'Public Path Orders'
       ,'prow6260'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6260');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6261'
       ,'Public Path Order Summary'
       ,'prow6261'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6261');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6270'
       ,'Modification Orders'
       ,'prow6270'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6270');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6271'
       ,'Modification Order Summary'
       ,'prow6271'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6271');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6280'
       ,'Path Closures'
       ,'prow6280'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6280');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6281'
       ,'Path Closure Summary'
       ,'prow6281'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6281');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6290'
       ,'Audit'
       ,'prow6290'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6290');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6292'
       ,'Audit Options'
       ,'prow6292'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6292');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW6294'
       ,'Maintain Closure Types'
       ,'prow6294'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM_PROW' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW6294');
--
INSERT INTO HIG_MODULES
       (HMO_MODULE
       ,HMO_TITLE
       ,HMO_FILENAME
       ,HMO_MODULE_TYPE
       ,HMO_FASTPATH_OPTS
       ,HMO_FASTPATH_INVALID
       ,HMO_USE_GRI
       ,HMO_APPLICATION
       ,HMO_MENU
       )
SELECT 
        'PROW9120'
       ,'Domains'
       ,'prow9120'
       ,'FMX'
       ,''
       ,'N'
       ,'N'
       ,'PROW'
       ,'FORM' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULES
                   WHERE HMO_MODULE = 'PROW9120');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- HIG_OPTION_LIST
--
-- select * from prow_metadata.hig_option_list
-- order by hol_id
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_option_list
SET TERM OFF

INSERT INTO HIG_OPTION_LIST
       (HOL_ID
       ,HOL_PRODUCT
       ,HOL_NAME
       ,HOL_REMARKS
       ,HOL_DOMAIN
       ,HOL_DATATYPE
       ,HOL_MIXED_CASE
       ,HOL_USER_OPTION
       )
SELECT 
        'ACCESSLAND'
       ,'PROW'
       ,'Inventory Type for Access Land'
       ,'Identifies the Inventory Type used for recording PROW Access Land'
       ,''
       ,'VARCHAR2'
       ,'N'
       ,'N' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_OPTION_LIST
                   WHERE HOL_ID = 'ACCESSLAND');
--
INSERT INTO HIG_OPTION_LIST
       (HOL_ID
       ,HOL_PRODUCT
       ,HOL_NAME
       ,HOL_REMARKS
       ,HOL_DOMAIN
       ,HOL_DATATYPE
       ,HOL_MIXED_CASE
       ,HOL_USER_OPTION
       )
SELECT 
        'AUTOZOOMPR'
       ,'PROW'
       ,'Auto Zoom in PROW Forms'
       ,'Set this option to "Y" if you want to automatically synchronize the map when a different data record is selected in PROW forms'
       ,'Y_OR_N'
       ,'VARCHAR2'
       ,'N'
       ,'N' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_OPTION_LIST
                   WHERE HOL_ID = 'AUTOZOOMPR');
--
INSERT INTO HIG_OPTION_LIST
       (HOL_ID
       ,HOL_PRODUCT
       ,HOL_NAME
       ,HOL_REMARKS
       ,HOL_DOMAIN
       ,HOL_DATATYPE
       ,HOL_MIXED_CASE
       ,HOL_USER_OPTION
       )
SELECT 
        'DOCCLASS'
       ,'PROW'
       ,'Doc Class for PROW Enquiries'
       ,'Identifies the Document Class used when recording PROW Enquiries'
       ,''
       ,'VARCHAR2'
       ,'N'
       ,'N' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_OPTION_LIST
                   WHERE HOL_ID = 'DOCCLASS');
--
INSERT INTO HIG_OPTION_LIST
       (HOL_ID
       ,HOL_PRODUCT
       ,HOL_NAME
       ,HOL_REMARKS
       ,HOL_DOMAIN
       ,HOL_DATATYPE
       ,HOL_MIXED_CASE
       ,HOL_USER_OPTION
       )
SELECT 
        'LANDPARCEL'
       ,'PROW'
       ,'Inventory Type for Land Parcel'
       ,'Identifies the Inventory Type used for recording PROW Land Parcels'
       ,''
       ,'VARCHAR2'
       ,'N'
       ,'N' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_OPTION_LIST
                   WHERE HOL_ID = 'LANDPARCEL');
--
INSERT INTO HIG_OPTION_LIST
       (HOL_ID
       ,HOL_PRODUCT
       ,HOL_NAME
       ,HOL_REMARKS
       ,HOL_DOMAIN
       ,HOL_DATATYPE
       ,HOL_MIXED_CASE
       ,HOL_USER_OPTION
       )
SELECT 
        'PATHNW'
       ,'PROW'
       ,'Network Type for Paths'
       ,'Identifies the Network Type used for recording PROW Paths'
       ,''
       ,'VARCHAR2'
       ,'N'
       ,'N' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_OPTION_LIST
                   WHERE HOL_ID = 'PATHNW');
--
INSERT INTO HIG_OPTION_LIST
       (HOL_ID
       ,HOL_PRODUCT
       ,HOL_NAME
       ,HOL_REMARKS
       ,HOL_DOMAIN
       ,HOL_DATATYPE
       ,HOL_MIXED_CASE
       ,HOL_USER_OPTION
       )
SELECT 
        'PATHSECTNW'
       ,'PROW'
       ,'Network Type for Path Sections'
       ,'Identifies the Network Type used for recording PROW Path Sections'
       ,''
       ,'VARCHAR2'
       ,'N'
       ,'N' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_OPTION_LIST
                   WHERE HOL_ID = 'PATHSECTNW');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- HIG_OPTION_VALUES
--
-- select * from prow_metadata.hig_option_values
-- order by hov_id
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_option_values
SET TERM OFF

INSERT INTO HIG_OPTION_VALUES
       (HOV_ID
       ,HOV_VALUE
       )
SELECT 
        'ACCESSLAND'
       ,'ACLD' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_OPTION_VALUES
                   WHERE HOV_ID = 'ACCESSLAND');
--
INSERT INTO HIG_OPTION_VALUES
       (HOV_ID
       ,HOV_VALUE
       )
SELECT 
        'AUTOZOOMPR'
       ,'Y' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_OPTION_VALUES
                   WHERE HOV_ID = 'AUTOZOOMPR');
--
INSERT INTO HIG_OPTION_VALUES
       (HOV_ID
       ,HOV_VALUE
       )
SELECT 
        'DOCCLASS'
       ,'ROW' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_OPTION_VALUES
                   WHERE HOV_ID = 'DOCCLASS');
--
INSERT INTO HIG_OPTION_VALUES
       (HOV_ID
       ,HOV_VALUE
       )
SELECT 
        'LANDPARCEL'
       ,'LAND' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_OPTION_VALUES
                   WHERE HOV_ID = 'LANDPARCEL');
--
INSERT INTO HIG_OPTION_VALUES
       (HOV_ID
       ,HOV_VALUE
       )
SELECT 
        'PATHNW'
       ,'PATH' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_OPTION_VALUES
                   WHERE HOV_ID = 'PATHNW');
--
INSERT INTO HIG_OPTION_VALUES
       (HOV_ID
       ,HOV_VALUE
       )
SELECT 
        'PATHSECTNW'
       ,'PSEC' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_OPTION_VALUES
                   WHERE HOV_ID = 'PATHSECTNW');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- HIG_DOMAINS
--
-- select * from prow_metadata.hig_domains
-- order by hdo_domain
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_domains
SET TERM OFF

INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_CITIES'
       ,'PROW'
       ,'Nearest city is recorded on orders'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_CITIES');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_CLOSURE_STATUS'
       ,'PROW'
       ,'Status of a path closure order'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_CLOSURE_STATUS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_CLOSURE_UNITS'
       ,'PROW'
       ,'Units for closure duration'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_CLOSURE_UNITS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_COST_CATEGORIES'
       ,'PROW'
       ,'Category of costs incurred'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_COST_CATEGORIES');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_COST_TYPES'
       ,'PROW'
       ,'Type of costs incurred'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_COST_TYPES');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_DEPOS_CONTACTS'
       ,'PROW'
       ,'Contact types on depositions'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_DEPOS_CONTACTS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_DEPOS_CONTENT'
       ,'PROW'
       ,'Content of a deposition'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_DEPOS_CONTENT');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_DEPOS_STATUS'
       ,'PROW'
       ,'Status of a deposition'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_DEPOS_STATUS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_DESIGNATIONS'
       ,'PROW'
       ,'Access Land designations'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_DESIGNATIONS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_DMS_DISTRICTS'
       ,'PROW'
       ,'DMS District recorded on orders'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_DMS_DISTRICTS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_ENFORCE_CONTACT'
       ,'PROW'
       ,'Contact types on enforcements'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_ENFORCE_CONTACT');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_ENFORCE_SERVICE'
       ,'PROW'
       ,'Type of service for enforcements'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_ENFORCE_SERVICE');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_ENFORCE_TYPE'
       ,'PROW'
       ,'Type of an enforcement'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_ENFORCE_TYPE');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_LAND_CONTACTS'
       ,'PROW'
       ,'Contact types for land'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_LAND_CONTACTS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_MO_APPEAL_RES'
       ,'PROW'
       ,'Results of appeals on MOs'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_MO_APPEAL_RES');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_MO_CATEGORIES'
       ,'PROW'
       ,'Legal category of MO changes'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_MO_CATEGORIES');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_MO_CONTACTS'
       ,'PROW'
       ,'Contact types on MOs'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_MO_CONTACTS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_MO_EFFECTS'
       ,'PROW'
       ,'Effect of MO changes'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_MO_EFFECTS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_MO_OBJECTIONS'
       ,'PROW'
       ,'Objections on MOs'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_MO_OBJECTIONS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_MO_PAN_DECISION'
       ,'PROW'
       ,'Investigation panel decisions on MOs'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_MO_PAN_DECISION');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_MO_STAGES'
       ,'PROW'
       ,'Processing stages on MOs'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_MO_STAGES');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_MO_STATUS'
       ,'PROW'
       ,'Status of MOs'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_MO_STATUS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_OFFENCE_PLEAS'
       ,'PROW'
       ,'Defendants plea on prosecutions'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_OFFENCE_PLEAS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_OFFENCE_RESULTS'
       ,'PROW'
       ,'Results on prosecutions'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_OFFENCE_RESULTS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_OFFENCE_TYPES'
       ,'PROW'
       ,'Type of offence on prosecutions'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_OFFENCE_TYPES');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_ORDER_DECISIONS'
       ,'PROW'
       ,'Inspector decisions on MOs and PPOs'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_ORDER_DECISIONS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_PATH_STATUS'
       ,'PROW'
       ,'Identifies new paths on MOs and PPOs'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_PATH_STATUS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_PPO_APPEAL_RES'
       ,'PROW'
       ,'Results of appeals on PPOs'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_PPO_APPEAL_RES');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_PPO_AUTHORITY'
       ,'PROW'
       ,'Order making authority on PPOs'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_PPO_AUTHORITY');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_PPO_CATEGORIES'
       ,'PROW'
       ,'Legal category of PPO changes'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_PPO_CATEGORIES');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_PPO_CONTACTS'
       ,'PROW'
       ,'Contact types on PPOs'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_PPO_CONTACTS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_PPO_EFFECTS'
       ,'PROW'
       ,'Effect of PPO changes'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_PPO_EFFECTS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_PPO_LEGISLATION'
       ,'PROW'
       ,'Legislation applicable to PPOs'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_PPO_LEGISLATION');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_PPO_STAGES'
       ,'PROW'
       ,'Processing stages on PPOs'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_PPO_STAGES');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_PROS_DECISIONS'
       ,'PROW'
       ,'Court decision on prosecutions'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_PROS_DECISIONS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_RESOLUT_METHODS'
       ,'PROW'
       ,'Resolution methods on MOs and PPOs'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_RESOLUT_METHODS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_RESTRICT_ORGS'
       ,'PROW'
       ,'Organisations imposing land restrictions'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_RESTRICT_ORGS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_RESTRICT_TYPES'
       ,'PROW'
       ,'Type of restrictions on access land'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_RESTRICT_TYPES');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_TOWNS'
       ,'PROW'
       ,'Nearest town is recorded on orders'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_TOWNS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_VILLAGES'
       ,'PROW'
       ,'Nearest village recorded on orders'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_VILLAGES');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_VL_CONTACTS'
       ,'PROW'
       ,'Contact types on vehicle use licenses'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_VL_CONTACTS');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_VL_STAGES'
       ,'PROW'
       ,'Processing stages on vehicle licenses'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_VL_STAGES');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_VL_TYPES'
       ,'PROW'
       ,'Type of vehicle use licenses'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_VL_TYPES');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_YES_NO'
       ,'PROW'
       ,'Yes/No responses'
       ,3 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_YES_NO');
--
INSERT INTO HIG_DOMAINS
       (HDO_DOMAIN
       ,HDO_PRODUCT
       ,HDO_TITLE
       ,HDO_CODE_LENGTH
       )
SELECT 
        'PROW_YES_NO_NOT'
       ,'PROW'
       ,'Yes/No/Not Applicable'
       ,3 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_DOMAINS
                   WHERE HDO_DOMAIN = 'PROW_YES_NO_NOT');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- HIG_CODES
--
-- select * from prow_metadata.hig_codes
-- order by hco_domain
--         ,hco_code
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_codes
SET TERM OFF

INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_CLOSURE_STATUS'
       ,'CURRENT'
       ,'Current'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_CLOSURE_STATUS'
                    AND  HCO_CODE = 'CURRENT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_CLOSURE_STATUS'
       ,'POTENTIAL'
       ,'Potential'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_CLOSURE_STATUS'
                    AND  HCO_CODE = 'POTENTIAL');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_CLOSURE_STATUS'
       ,'REDUNDANT'
       ,'Redundant'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_CLOSURE_STATUS'
                    AND  HCO_CODE = 'REDUNDANT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_CLOSURE_UNITS'
       ,'DAYS'
       ,'Days'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_CLOSURE_UNITS'
                    AND  HCO_CODE = 'DAYS');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_CLOSURE_UNITS'
       ,'MONTHS'
       ,'Months'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_CLOSURE_UNITS'
                    AND  HCO_CODE = 'MONTHS');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_CLOSURE_UNITS'
       ,'WEEKS'
       ,'Weeks'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_CLOSURE_UNITS'
                    AND  HCO_CODE = 'WEEKS');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_COST_CATEGORIES'
       ,'EXPENSE'
       ,'Expense'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_COST_CATEGORIES'
                    AND  HCO_CODE = 'EXPENSE');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_COST_CATEGORIES'
       ,'INCOME'
       ,'Income'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_COST_CATEGORIES'
                    AND  HCO_CODE = 'INCOME');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_COST_TYPES'
       ,'ADVERT'
       ,'Advertisement'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_COST_TYPES'
                    AND  HCO_CODE = 'ADVERT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_COST_TYPES'
       ,'LABOUR'
       ,'Labour'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_COST_TYPES'
                    AND  HCO_CODE = 'LABOUR');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_COST_TYPES'
       ,'MISC'
       ,'Miscellaneous'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_COST_TYPES'
                    AND  HCO_CODE = 'MISC');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_DEPOS_CONTACTS'
       ,'AGENT'
       ,'Agent'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_DEPOS_CONTACTS'
                    AND  HCO_CODE = 'AGENT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_DEPOS_CONTACTS'
       ,'LANDOWNER'
       ,'Land Owner'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_DEPOS_CONTACTS'
                    AND  HCO_CODE = 'LANDOWNER');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_DEPOS_CONTACTS'
       ,'PROPERTY'
       ,'Affected Property'
       ,'Y'
       ,4
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_DEPOS_CONTACTS'
                    AND  HCO_CODE = 'PROPERTY');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_DEPOS_CONTACTS'
       ,'TENANT'
       ,'Tenant'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_DEPOS_CONTACTS'
                    AND  HCO_CODE = 'TENANT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_DEPOS_CONTENT'
       ,'ORIGINAL'
       ,'Original Plan and Statement'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_DEPOS_CONTENT'
                    AND  HCO_CODE = 'ORIGINAL');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_DEPOS_CONTENT'
       ,'STATUTORY'
       ,'Statutory Declaration'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_DEPOS_CONTENT'
                    AND  HCO_CODE = 'STATUTORY');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_DEPOS_STATUS'
       ,'CURRENT'
       ,'Current'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_DEPOS_STATUS'
                    AND  HCO_CODE = 'CURRENT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_DEPOS_STATUS'
       ,'INTENT'
       ,'Intent'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_DEPOS_STATUS'
                    AND  HCO_CODE = 'INTENT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_DEPOS_STATUS'
       ,'LAPSED'
       ,'Lapsed'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_DEPOS_STATUS'
                    AND  HCO_CODE = 'LAPSED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_DESIGNATIONS'
       ,'AONB'
       ,'AONB'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_DESIGNATIONS'
                    AND  HCO_CODE = 'AONB');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_DESIGNATIONS'
       ,'ARCH'
       ,'Archaeological Site'
       ,'Y'
       ,4
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_DESIGNATIONS'
                    AND  HCO_CODE = 'ARCH');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_DESIGNATIONS'
       ,'KWS'
       ,'KWS'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_DESIGNATIONS'
                    AND  HCO_CODE = 'KWS');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_DESIGNATIONS'
       ,'SSSI'
       ,'SSSI'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_DESIGNATIONS'
                    AND  HCO_CODE = 'SSSI');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ENFORCE_CONTACT'
       ,'AGENT'
       ,'Agent'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ENFORCE_CONTACT'
                    AND  HCO_CODE = 'AGENT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ENFORCE_CONTACT'
       ,'LANDOWNER'
       ,'Land Owner'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ENFORCE_CONTACT'
                    AND  HCO_CODE = 'LANDOWNER');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ENFORCE_CONTACT'
       ,'TENANT'
       ,'Tenant'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ENFORCE_CONTACT'
                    AND  HCO_CODE = 'TENANT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ENFORCE_SERVICE'
       ,'BYHAND'
       ,'By Hand'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ENFORCE_SERVICE'
                    AND  HCO_CODE = 'BYHAND');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ENFORCE_SERVICE'
       ,'OTHER'
       ,'Other Mail Service'
       ,'Y'
       ,4
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ENFORCE_SERVICE'
                    AND  HCO_CODE = 'OTHER');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ENFORCE_SERVICE'
       ,'RECORDED'
       ,'Recorded Delivery'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ENFORCE_SERVICE'
                    AND  HCO_CODE = 'RECORDED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ENFORCE_SERVICE'
       ,'ROYALMAIL'
       ,'Royal Mail'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ENFORCE_SERVICE'
                    AND  HCO_CODE = 'ROYALMAIL');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ENFORCE_TYPE'
       ,'12A'
       ,'Schedule 12A'
       ,'Y'
       ,6
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ENFORCE_TYPE'
                    AND  HCO_CODE = '12A');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ENFORCE_TYPE'
       ,'S143'
       ,'S143 - Removal of Structures'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ENFORCE_TYPE'
                    AND  HCO_CODE = 'S143');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ENFORCE_TYPE'
       ,'S146(2)'
       ,'S146(2) - Repair of Stiles'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ENFORCE_TYPE'
                    AND  HCO_CODE = 'S146(2)');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ENFORCE_TYPE'
       ,'S149'
       ,'S149 - Removal of Deposits on Highway'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ENFORCE_TYPE'
                    AND  HCO_CODE = 'S149');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ENFORCE_TYPE'
       ,'S154'
       ,'S154 - Felling of Trees'
       ,'Y'
       ,4
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ENFORCE_TYPE'
                    AND  HCO_CODE = 'S154');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ENFORCE_TYPE'
       ,'S164'
       ,'S164 - Removal of Barbed Wire'
       ,'Y'
       ,5
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ENFORCE_TYPE'
                    AND  HCO_CODE = 'S164');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_LAND_CONTACTS'
       ,'AGENT'
       ,'Agent'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_LAND_CONTACTS'
                    AND  HCO_CODE = 'AGENT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_LAND_CONTACTS'
       ,'LANDOWNER'
       ,'Land Owner'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_LAND_CONTACTS'
                    AND  HCO_CODE = 'LANDOWNER');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_LAND_CONTACTS'
       ,'OTHER'
       ,'Other Organisation'
       ,'Y'
       ,4
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_LAND_CONTACTS'
                    AND  HCO_CODE = 'OTHER');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_LAND_CONTACTS'
       ,'TENANT'
       ,'Tenant'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_LAND_CONTACTS'
                    AND  HCO_CODE = 'TENANT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_APPEAL_RES'
       ,'DISMISSED'
       ,'Dismissed'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_APPEAL_RES'
                    AND  HCO_CODE = 'DISMISSED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_APPEAL_RES'
       ,'UPHELD'
       ,'Upheld'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_APPEAL_RES'
                    AND  HCO_CODE = 'UPHELD');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_CATEGORIES'
       ,'S53(3)CI'
       ,'s53(3)Ci Add Path'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_CATEGORIES'
                    AND  HCO_CODE = 'S53(3)CI');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_CATEGORIES'
       ,'S53(3)CII'
       ,'s53(3)Cii Upgrade / Downgrade'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_CATEGORIES'
                    AND  HCO_CODE = 'S53(3)CII');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_CATEGORIES'
       ,'S53(3)CIII'
       ,'s53(3)Ciii Deletion'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_CATEGORIES'
                    AND  HCO_CODE = 'S53(3)CIII');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_CONTACTS'
       ,'APPLICANT'
       ,'Applicant'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_CONTACTS'
                    AND  HCO_CODE = 'APPLICANT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_CONTACTS'
       ,'PROPERTY'
       ,'Affected Property'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_CONTACTS'
                    AND  HCO_CODE = 'PROPERTY');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_EFFECTS'
       ,'ADDITION'
       ,'Addition'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_EFFECTS'
                    AND  HCO_CODE = 'ADDITION');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_EFFECTS'
       ,'DELETION'
       ,'Deletion'
       ,'Y'
       ,5
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_EFFECTS'
                    AND  HCO_CODE = 'DELETION');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_EFFECTS'
       ,'DOWNGRADE'
       ,'Downgrade'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_EFFECTS'
                    AND  HCO_CODE = 'DOWNGRADE');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_EFFECTS'
       ,'MODIFY'
       ,'Modify'
       ,'Y'
       ,4
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_EFFECTS'
                    AND  HCO_CODE = 'MODIFY');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_EFFECTS'
       ,'UPGRADE'
       ,'Upgrade'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_EFFECTS'
                    AND  HCO_CODE = 'UPGRADE');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_OBJECTIONS'
       ,'NONE'
       ,'No Objections'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_OBJECTIONS'
                    AND  HCO_CODE = 'NONE');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_OBJECTIONS'
       ,'RESOLVED'
       ,'Resolved Objections'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_OBJECTIONS'
                    AND  HCO_CODE = 'RESOLVED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_OBJECTIONS'
       ,'UNRESOLVED'
       ,'Unresolved Objections'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_OBJECTIONS'
                    AND  HCO_CODE = 'UNRESOLVED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_PAN_DECISION'
       ,'DISMISS'
       ,'Application Dismissed'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_PAN_DECISION'
                    AND  HCO_CODE = 'DISMISS');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_PAN_DECISION'
       ,'MAKE'
       ,'Make Order'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_PAN_DECISION'
                    AND  HCO_CODE = 'MAKE');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_PAN_DECISION'
       ,'MAKEMOD'
       ,'Make Order with Modification'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_PAN_DECISION'
                    AND  HCO_CODE = 'MAKEMOD');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_STAGES'
       ,'ABANDONED'
       ,'Abandoned'
       ,'Y'
       ,9
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_STAGES'
                    AND  HCO_CODE = 'ABANDONED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_STAGES'
       ,'APPEAL'
       ,'Appeal'
       ,'Y'
       ,4
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_STAGES'
                    AND  HCO_CODE = 'APPEAL');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_STAGES'
       ,'APPMADE'
       ,'Application Made'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_STAGES'
                    AND  HCO_CODE = 'APPMADE');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_STAGES'
       ,'CONFIRMED'
       ,'Order Confirmed'
       ,'Y'
       ,8
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_STAGES'
                    AND  HCO_CODE = 'CONFIRMED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_STAGES'
       ,'CONSOLIDATED'
       ,'Consolidated'
       ,'Y'
       ,10
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_STAGES'
                    AND  HCO_CODE = 'CONSOLIDATED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_STAGES'
       ,'DRAFTORDER'
       ,'Draft Order'
       ,'Y'
       ,5
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_STAGES'
                    AND  HCO_CODE = 'DRAFTORDER');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_STAGES'
       ,'INVEST'
       ,'Investigation'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_STAGES'
                    AND  HCO_CODE = 'INVEST');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_STAGES'
       ,'ORDERMADE-O'
       ,'Order Made - Opposed'
       ,'Y'
       ,7
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_STAGES'
                    AND  HCO_CODE = 'ORDERMADE-O');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_STAGES'
       ,'ORDERMADE-U'
       ,'Order Made - Unopposed'
       ,'Y'
       ,6
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_STAGES'
                    AND  HCO_CODE = 'ORDERMADE-U');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_STAGES'
       ,'POTENTIAL'
       ,'Potential'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_STAGES'
                    AND  HCO_CODE = 'POTENTIAL');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_STATUS'
       ,'COMPLETED'
       ,'Completed'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_STATUS'
                    AND  HCO_CODE = 'COMPLETED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_STATUS'
       ,'DETERMINED'
       ,'Determined'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_STATUS'
                    AND  HCO_CODE = 'DETERMINED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_MO_STATUS'
       ,'UNDETERMINED'
       ,'Undetermined'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_MO_STATUS'
                    AND  HCO_CODE = 'UNDETERMINED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_OFFENCE_PLEAS'
       ,'GUILTY'
       ,'Guilty'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_OFFENCE_PLEAS'
                    AND  HCO_CODE = 'GUILTY');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_OFFENCE_PLEAS'
       ,'NOTGUILTY'
       ,'Not Guilty'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_OFFENCE_PLEAS'
                    AND  HCO_CODE = 'NOTGUILTY');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_OFFENCE_RESULTS'
       ,'ABSDISCHARGE'
       ,'Absolute Discharge'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_OFFENCE_RESULTS'
                    AND  HCO_CODE = 'ABSDISCHARGE');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_OFFENCE_RESULTS'
       ,'CONDISCHARGE'
       ,'Conditional Discharge'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_OFFENCE_RESULTS'
                    AND  HCO_CODE = 'CONDISCHARGE');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_OFFENCE_RESULTS'
       ,'FINE'
       ,'Fine'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_OFFENCE_RESULTS'
                    AND  HCO_CODE = 'FINE');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_OFFENCE_TYPES'
       ,'CROPPING'
       ,'Cropping'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_OFFENCE_TYPES'
                    AND  HCO_CODE = 'CROPPING');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_OFFENCE_TYPES'
       ,'OBSTRUCTION'
       ,'Obstruction'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_OFFENCE_TYPES'
                    AND  HCO_CODE = 'OBSTRUCTION');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_OFFENCE_TYPES'
       ,'PLOUGHING'
       ,'Ploughing'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_OFFENCE_TYPES'
                    AND  HCO_CODE = 'PLOUGHING');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ORDER_DECISIONS'
       ,'CONF'
       ,'Confirm Order'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ORDER_DECISIONS'
                    AND  HCO_CODE = 'CONF');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ORDER_DECISIONS'
       ,'CONFMOD'
       ,'Confirm Order with Modification'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ORDER_DECISIONS'
                    AND  HCO_CODE = 'CONFMOD');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_ORDER_DECISIONS'
       ,'DISMISS'
       ,'Dismiss Order'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_ORDER_DECISIONS'
                    AND  HCO_CODE = 'DISMISS');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PATH_STATUS'
       ,'PERM'
       ,'Permanent'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PATH_STATUS'
                    AND  HCO_CODE = 'PERM');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PATH_STATUS'
       ,'PROV'
       ,'Provisional'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PATH_STATUS'
                    AND  HCO_CODE = 'PROV');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_APPEAL_RES'
       ,'DISMISS'
       ,'Appeal Dismissed'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_APPEAL_RES'
                    AND  HCO_CODE = 'DISMISS');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_APPEAL_RES'
       ,'UPHELD'
       ,'Appeal Upheld'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_APPEAL_RES'
                    AND  HCO_CODE = 'UPHELD');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_CATEGORIES'
       ,'COURTORDER'
       ,'Magistrates Court Order'
       ,'Y'
       ,4
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_CATEGORIES'
                    AND  HCO_CODE = 'COURTORDER');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_CATEGORIES'
       ,'CREATIONAGR'
       ,'Creation Agreement'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_CATEGORIES'
                    AND  HCO_CODE = 'CREATIONAGR');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_CATEGORIES'
       ,'CREATIONORD'
       ,'Creation Order'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_CATEGORIES'
                    AND  HCO_CODE = 'CREATIONORD');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_CATEGORIES'
       ,'DIVERSION'
       ,'Diversion Order'
       ,'Y'
       ,6
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_CATEGORIES'
                    AND  HCO_CODE = 'DIVERSION');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_CATEGORIES'
       ,'SIDEORDER'
       ,'Side Roads Order'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_CATEGORIES'
                    AND  HCO_CODE = 'SIDEORDER');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_CATEGORIES'
       ,'STOPPINGUP'
       ,'Stopping Up Order'
       ,'Y'
       ,5
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_CATEGORIES'
                    AND  HCO_CODE = 'STOPPINGUP');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_CONTACTS'
       ,'AGENT'
       ,'Agent'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_CONTACTS'
                    AND  HCO_CODE = 'AGENT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_CONTACTS'
       ,'CONSULTEE'
       ,'Consultee'
       ,'Y'
       ,4
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_CONTACTS'
                    AND  HCO_CODE = 'CONSULTEE');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_CONTACTS'
       ,'LANDOWNER'
       ,'Land Owner'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_CONTACTS'
                    AND  HCO_CODE = 'LANDOWNER');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_CONTACTS'
       ,'PROPERTY'
       ,'Affected Property'
       ,'Y'
       ,5
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_CONTACTS'
                    AND  HCO_CODE = 'PROPERTY');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_CONTACTS'
       ,'SCHOOL'
       ,'Affected School'
       ,'Y'
       ,6
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_CONTACTS'
                    AND  HCO_CODE = 'SCHOOL');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_CONTACTS'
       ,'TENANT'
       ,'Tenant'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_CONTACTS'
                    AND  HCO_CODE = 'TENANT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_EFFECTS'
       ,'CREATION'
       ,'Creation'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_EFFECTS'
                    AND  HCO_CODE = 'CREATION');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_EFFECTS'
       ,'DELETION'
       ,'Deletion'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_EFFECTS'
                    AND  HCO_CODE = 'DELETION');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_EFFECTS'
       ,'DIVERSION'
       ,'Diversion'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_EFFECTS'
                    AND  HCO_CODE = 'DIVERSION');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_LEGISLATION'
       ,'CROW'
       ,'CROW Act 2000'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_LEGISLATION'
                    AND  HCO_CODE = 'CROW');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_LEGISLATION'
       ,'HIGHWAYS'
       ,'Highways Act 1980'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_LEGISLATION'
                    AND  HCO_CODE = 'HIGHWAYS');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_LEGISLATION'
       ,'PLANNING'
       ,'Town and Country Planning Act 1990'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_LEGISLATION'
                    AND  HCO_CODE = 'PLANNING');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_STAGES'
       ,'ABANDONED'
       ,'Abondoned'
       ,'Y'
       ,9
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_STAGES'
                    AND  HCO_CODE = 'ABANDONED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_STAGES'
       ,'APPEAL'
       ,'Appeal'
       ,'Y'
       ,4
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_STAGES'
                    AND  HCO_CODE = 'APPEAL');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_STAGES'
       ,'APPMADE'
       ,'Application Made'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_STAGES'
                    AND  HCO_CODE = 'APPMADE');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_STAGES'
       ,'CONFIRMED'
       ,'Order Confirmed'
       ,'Y'
       ,8
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_STAGES'
                    AND  HCO_CODE = 'CONFIRMED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_STAGES'
       ,'CONSOLIDATED'
       ,'Consolidated'
       ,'Y'
       ,10
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_STAGES'
                    AND  HCO_CODE = 'CONSOLIDATED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_STAGES'
       ,'CONSULTATION'
       ,'Consultation'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_STAGES'
                    AND  HCO_CODE = 'CONSULTATION');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_STAGES'
       ,'DRAFTORDER'
       ,'Draft Order'
       ,'Y'
       ,5
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_STAGES'
                    AND  HCO_CODE = 'DRAFTORDER');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_STAGES'
       ,'ORDERMADE-O'
       ,'Order Made - Opposed'
       ,'Y'
       ,7
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_STAGES'
                    AND  HCO_CODE = 'ORDERMADE-O');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_STAGES'
       ,'ORDERMADE-U'
       ,'Order Made - Unopposed'
       ,'Y'
       ,6
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_STAGES'
                    AND  HCO_CODE = 'ORDERMADE-U');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PPO_STAGES'
       ,'POTENTIAL'
       ,'Potential'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PPO_STAGES'
                    AND  HCO_CODE = 'POTENTIAL');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PROS_DECISIONS'
       ,'CAUTION'
       ,'Caution'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PROS_DECISIONS'
                    AND  HCO_CODE = 'CAUTION');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PROS_DECISIONS'
       ,'NOACTION'
       ,'No Further Action'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PROS_DECISIONS'
                    AND  HCO_CODE = 'NOACTION');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_PROS_DECISIONS'
       ,'PROSECUTE'
       ,'Prosecute'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_PROS_DECISIONS'
                    AND  HCO_CODE = 'PROSECUTE');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_RESOLUT_METHODS'
       ,'ABANDON'
       ,'Abandoned'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_RESOLUT_METHODS'
                    AND  HCO_CODE = 'ABANDON');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_RESOLUT_METHODS'
       ,'INQUIRY'
       ,'Public Inquiry'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_RESOLUT_METHODS'
                    AND  HCO_CODE = 'INQUIRY');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_RESOLUT_METHODS'
       ,'WRITTEN'
       ,'Written Representation'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_RESOLUT_METHODS'
                    AND  HCO_CODE = 'WRITTEN');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_RESTRICT_ORGS'
       ,'ENGLAND'
       ,'Natural England'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_RESTRICT_ORGS'
                    AND  HCO_CODE = 'ENGLAND');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_RESTRICT_ORGS'
       ,'LANDOWNER'
       ,'Land Owner'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_RESTRICT_ORGS'
                    AND  HCO_CODE = 'LANDOWNER');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_RESTRICT_TYPES'
       ,'S22'
       ,'Discretionary'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_RESTRICT_TYPES'
                    AND  HCO_CODE = 'S22');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_RESTRICT_TYPES'
       ,'S24'
       ,'Land Management'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_RESTRICT_TYPES'
                    AND  HCO_CODE = 'S24');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_RESTRICT_TYPES'
       ,'S25'
       ,'Fire'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_RESTRICT_TYPES'
                    AND  HCO_CODE = 'S25');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_RESTRICT_TYPES'
       ,'S26'
       ,'Nature Conservation'
       ,'Y'
       ,4
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_RESTRICT_TYPES'
                    AND  HCO_CODE = 'S26');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_VL_CONTACTS'
       ,'APPLICANT'
       ,'Applicant'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_VL_CONTACTS'
                    AND  HCO_CODE = 'APPLICANT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_VL_CONTACTS'
       ,'LANDOWNER'
       ,'Land Owner'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_VL_CONTACTS'
                    AND  HCO_CODE = 'LANDOWNER');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_VL_CONTACTS'
       ,'TENANT'
       ,'Tenant'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_VL_CONTACTS'
                    AND  HCO_CODE = 'TENANT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_VL_STAGES'
       ,'APPLICATION'
       ,'Application'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_VL_STAGES'
                    AND  HCO_CODE = 'APPLICATION');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_VL_STAGES'
       ,'CONFIRMED'
       ,'Confirmed'
       ,'Y'
       ,4
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_VL_STAGES'
                    AND  HCO_CODE = 'CONFIRMED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_VL_STAGES'
       ,'INPROGRESS'
       ,'In Progress'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_VL_STAGES'
                    AND  HCO_CODE = 'INPROGRESS');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_VL_STAGES'
       ,'INSPECTION'
       ,'Inspection'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_VL_STAGES'
                    AND  HCO_CODE = 'INSPECTION');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_VL_STAGES'
       ,'NOTCONFIRMED'
       ,'Not Confirmed'
       ,'Y'
       ,5
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_VL_STAGES'
                    AND  HCO_CODE = 'NOTCONFIRMED');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_VL_TYPES'
       ,'PERMANENT'
       ,'Permanent'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_VL_TYPES'
                    AND  HCO_CODE = 'PERMANENT');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_VL_TYPES'
       ,'TEMPORARY'
       ,'Temporary'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_VL_TYPES'
                    AND  HCO_CODE = 'TEMPORARY');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_YES_NO'
       ,'NO'
       ,'No'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_YES_NO'
                    AND  HCO_CODE = 'NO');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_YES_NO'
       ,'YES'
       ,'Yes'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_YES_NO'
                    AND  HCO_CODE = 'YES');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_YES_NO_NOT'
       ,'N/A'
       ,'Not Applicable'
       ,'Y'
       ,3
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_YES_NO_NOT'
                    AND  HCO_CODE = 'N/A');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_YES_NO_NOT'
       ,'NO'
       ,'No'
       ,'Y'
       ,2
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_YES_NO_NOT'
                    AND  HCO_CODE = 'NO');
--
INSERT INTO HIG_CODES
       (HCO_DOMAIN
       ,HCO_CODE
       ,HCO_MEANING
       ,HCO_SYSTEM
       ,HCO_SEQ
       ,HCO_START_DATE
       ,HCO_END_DATE
       )
SELECT 
        'PROW_YES_NO_NOT'
       ,'YES'
       ,'Yes'
       ,'Y'
       ,1
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CODES
                   WHERE HCO_DOMAIN = 'PROW_YES_NO_NOT'
                    AND  HCO_CODE = 'YES');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- NM_ERRORS
--
-- select * from prow_metadata.nm_errors
-- order by ner_id
--         ,ner_appl
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT nm_errors
SET TERM OFF

INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,1
       ,null
       ,'Primary key value cannot be changed'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 1
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,2
       ,null
       ,'Primary contact already exists'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 2
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,3
       ,null
       ,'That contact does not exist'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 3
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,4
       ,null
       ,'This is not a land item'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 4
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,5
       ,null
       ,'End date must be greater then or equal to start date'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 5
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,6
       ,null
       ,'A contact cannot perform more then one role on the land parcel'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 6
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,7
       ,null
       ,'Land Parcels theme does not exist'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 7
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,8
       ,null
       ,'The Name must be selected from the list of values'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 8
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,9
       ,null
       ,'Contact is already associated with this licence'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 9
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,10
       ,null
       ,'Enforcement must be associated with access land or a path'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 10
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,11
       ,null
       ,'Cannot delete master contact since it is associated with an Enquiry'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 11
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,12
       ,null
       ,'Cannot delete master contact since it is associated with a Closure'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 12
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,13
       ,null
       ,'Cannot delete master contact since it is associated with a Deposition'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 13
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,14
       ,null
       ,'Cannot delete master contact since it is associated with an Enforcement'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 14
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,15
       ,null
       ,'Cannot delete master contact since it is associated with Land'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 15
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,16
       ,null
       ,'Cannot delete master contact since it is associated with a Modification Order'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 16
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,17
       ,null
       ,'Cannot delete master contact since it is associated with a Public Path Order'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 17
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,18
       ,null
       ,'Cannot delete master contact since it is associated with a Prosecution'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 18
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,19
       ,null
       ,'Cannot delete master contact since it is associated with a vehicle License'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 19
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,20
       ,null
       ,'Prosecution must be associated with access land or a path'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 20
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,21
       ,null
       ,'Prosecution is already associated with that enforcement'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 21
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,22
       ,null
       ,'Link definition is invalid'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 22
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,23
       ,null
       ,'Link definition is invalid, wrong calling block parameter name'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 23
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,24
       ,null
       ,'Too many link definitions for same block combination'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 24
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,25
       ,null
       ,'Duration must be set in days or months but cannot be both'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 25
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,26
       ,null
       ,'Closure type already exists.  It must be unique'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 26
                    AND  NER_APPL = 'PROW');
--
INSERT INTO NM_ERRORS
       (NER_APPL
       ,NER_ID
       ,NER_HER_NO
       ,NER_DESCR
       ,NER_CAUSE
       )
SELECT 
        'PROW'
       ,27
       ,null
       ,'Closure type description already exists.  It must be unique'
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM NM_ERRORS
                   WHERE NER_ID = 27
                    AND  NER_APPL = 'PROW');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- HIG_CHECK_CONSTRAINT_ASSOCS
--
-- select * from prow_metadata.hig_check_constraint_assocs
-- order by hcca_constraint_name
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_check_constraint_assocs
SET TERM OFF

INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'DEC_FK_HCT'
       ,'DOC_ENQUIRY_CONTACTS'
       ,'PROW'
       ,11 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'DEC_FK_HCT');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PCL_HCT_FK'
       ,'PROW_CLOSURES'
       ,'PROW'
       ,12 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PCL_HCT_FK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PCT_DURATION_CHECK'
       ,'PROW_CLOSURE_TYPES'
       ,'PROW'
       ,25 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PCT_DURATION_CHECK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PCT_PK'
       ,'PROW_CLOSURE_TYPES'
       ,'PROW'
       ,26 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PCT_PK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PCT_UK'
       ,'PROW_CLOSURE_TYPES'
       ,'PROW'
       ,27 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PCT_UK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PDE_HCT_FK'
       ,'PROW_DEPOSITIONS'
       ,'PROW'
       ,13 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PDE_HCT_FK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PEN_HCT_FK'
       ,'HIG_CONTACTS'
       ,'PROW'
       ,14 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PEN_HCT_FK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PEN_PATH_OR_LAND_CHK'
       ,'PROW_ENFORCEMENTS'
       ,'PROW'
       ,10 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PEN_PATH_OR_LAND_CHK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PLC_DATE_CHECK'
       ,'PROW_LAND_CONTACTS'
       ,'PROW'
       ,5 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PLC_DATE_CHECK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PLC_HCT_FK'
       ,'PROW_LAND_CONTACTS'
       ,'PROW'
       ,15 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PLC_HCT_FK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PLC_PK'
       ,'PROW_LAND_CONTACTS'
       ,'PROW'
       ,6 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PLC_PK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PMO_HCT_FK'
       ,'PROW_MOD_ORDERS'
       ,'PROW'
       ,16 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PMO_HCT_FK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PPE_PK'
       ,'PROW_PROSECUTION_ENFORCEMENTS'
       ,'PROW'
       ,21 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PPE_PK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PPOC_HCT_FK'
       ,'PROW_PATH_ORDER_CONTACTS'
       ,'PROW'
       ,17 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PPOC_HCT_FK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PPRO_PATH_OR_LAND_CHK'
       ,'PROW_PROSECUTIONS'
       ,'PROW'
       ,20 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PPRO_PATH_OR_LAND_CHK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PPR_HCT_FK'
       ,'PROW_PROSECUTIONS'
       ,'PROW'
       ,18 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PPR_HCT_FK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PVLC_HCT_FK'
       ,'PROW_VEHICLE_LICENSE_CONTACTS'
       ,'PROW'
       ,19 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PVLC_HCT_FK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PVLC_PK'
       ,'PROW_VEHICLE_LICENSE_CONTACTS'
       ,'PROW'
       ,9 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PVLC_PK');
--
INSERT INTO HIG_CHECK_CONSTRAINT_ASSOCS
       (HCCA_CONSTRAINT_NAME
       ,HCCA_TABLE_NAME
       ,HCCA_NER_APPL
       ,HCCA_NER_ID
       )
SELECT 
        'PVL_DATE_CHECK'
       ,'PROW_VEHICLE_LICENSES'
       ,'PROW'
       ,5 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_CHECK_CONSTRAINT_ASSOCS
                   WHERE HCCA_CONSTRAINT_NAME = 'PVL_DATE_CHECK');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- HIG_MODULE_BLOCKS
--
-- select * from prow_metadata.hig_module_blocks
-- order by hmb_module_name
--         ,hmb_block_name
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_module_blocks
SET TERM OFF

INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'DOC0150'
       ,'B1'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'DOC0150'
                    AND  HMB_BLOCK_NAME = 'B1');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6000'
       ,'CONTROL'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6000'
                    AND  HMB_BLOCK_NAME = 'CONTROL');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6010'
       ,'PROW_ACTION_SUMMARY_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6010'
                    AND  HMB_BLOCK_NAME = 'PROW_ACTION_SUMMARY_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6012'
       ,'PROW_ENQUIRY_SUMMARY_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6012'
                    AND  HMB_BLOCK_NAME = 'PROW_ENQUIRY_SUMMARY_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6014'
       ,'PROW_WORK_ORDER_SUMMARY_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6014'
                    AND  HMB_BLOCK_NAME = 'PROW_WORK_ORDER_SUMMARY_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6020'
       ,'PROW_LAND_CONTACTS_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6020'
                    AND  HMB_BLOCK_NAME = 'PROW_LAND_CONTACTS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6020'
       ,'PROW_LAND_PARCELS_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6020'
                    AND  HMB_BLOCK_NAME = 'PROW_LAND_PARCELS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6021'
       ,'PROW_LAND_PARCELS_SUMMARY_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6021'
                    AND  HMB_BLOCK_NAME = 'PROW_LAND_PARCELS_SUMMARY_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6022'
       ,'PROW_PARTIES_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6022'
                    AND  HMB_BLOCK_NAME = 'PROW_PARTIES_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6030'
       ,'IIT'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6030'
                    AND  HMB_BLOCK_NAME = 'IIT');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6030'
       ,'PROW_ACCESS_LAND_PARCELS_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6030'
                    AND  HMB_BLOCK_NAME = 'PROW_ACCESS_LAND_PARCELS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6050'
       ,'PROW_ACCESS_LANDS_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6050'
                    AND  HMB_BLOCK_NAME = 'PROW_ACCESS_LANDS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6050'
       ,'PROW_ACCESS_LAND_DETAILS_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6050'
                    AND  HMB_BLOCK_NAME = 'PROW_ACCESS_LAND_DETAILS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6060'
       ,'PROW_PATHS_DETAILS_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6060'
                    AND  HMB_BLOCK_NAME = 'PROW_PATHS_DETAILS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6060'
       ,'PROW_PATHS_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6060'
                    AND  HMB_BLOCK_NAME = 'PROW_PATHS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6210'
       ,'PROW_VEHICLE_LICENCES_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6210'
                    AND  HMB_BLOCK_NAME = 'PROW_VEHICLE_LICENCES_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6210'
       ,'PROW_VEHICLE_LICENCE_CONT_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6210'
                    AND  HMB_BLOCK_NAME = 'PROW_VEHICLE_LICENCE_CONT_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6210'
       ,'PROW_VEHICLE_LICENSES_PATH_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6210'
                    AND  HMB_BLOCK_NAME = 'PROW_VEHICLE_LICENSES_PATH_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6220'
       ,'PROW_ENFORCEMENTS_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6220'
                    AND  HMB_BLOCK_NAME = 'PROW_ENFORCEMENTS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6222'
       ,'PROW_ENFORCEMENT_SUMMARY_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6222'
                    AND  HMB_BLOCK_NAME = 'PROW_ENFORCEMENT_SUMMARY_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6230'
       ,'PROW_PROSECUTIONS_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6230'
                    AND  HMB_BLOCK_NAME = 'PROW_PROSECUTIONS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6230'
       ,'PROW_PROSECUTION_OFFENCES_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6230'
                    AND  HMB_BLOCK_NAME = 'PROW_PROSECUTION_OFFENCES_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6230'
       ,'PROW_PROS_ENFORCEMENTS_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6230'
                    AND  HMB_BLOCK_NAME = 'PROW_PROS_ENFORCEMENTS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6240'
       ,'PROW_DEPOSITIONS_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6240'
                    AND  HMB_BLOCK_NAME = 'PROW_DEPOSITIONS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6240'
       ,'PROW_DEPOSITION_CONTACTS_V'
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,to_date('20090415103947','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6240'
                    AND  HMB_BLOCK_NAME = 'PROW_DEPOSITION_CONTACTS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6250'
       ,'PROW_DEFINITIVE_STATEMENT_V'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6250'
                    AND  HMB_BLOCK_NAME = 'PROW_DEFINITIVE_STATEMENT_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6260'
       ,'PROW_PATH_ORDERS_V'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6260'
                    AND  HMB_BLOCK_NAME = 'PROW_PATH_ORDERS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6260'
       ,'PROW_PATH_ORDER_CONTACTS_V'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6260'
                    AND  HMB_BLOCK_NAME = 'PROW_PATH_ORDER_CONTACTS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6260'
       ,'PROW_PATH_ORDER_PATHS_V'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6260'
                    AND  HMB_BLOCK_NAME = 'PROW_PATH_ORDER_PATHS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6261'
       ,'PROW_PATH_ORDERS_SUMMARY_V'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6261'
                    AND  HMB_BLOCK_NAME = 'PROW_PATH_ORDERS_SUMMARY_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6270'
       ,'PROW_MOD_ORDERS_V'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6270'
                    AND  HMB_BLOCK_NAME = 'PROW_MOD_ORDERS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6270'
       ,'PROW_MOD_ORDER_CONTACTS_V'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6270'
                    AND  HMB_BLOCK_NAME = 'PROW_MOD_ORDER_CONTACTS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6270'
       ,'PROW_MOD_ORDER_PATHS_V'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6270'
                    AND  HMB_BLOCK_NAME = 'PROW_MOD_ORDER_PATHS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6271'
       ,'PROW_MOD_ORDERS_SUMMARY_V'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6271'
                    AND  HMB_BLOCK_NAME = 'PROW_MOD_ORDERS_SUMMARY_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6280'
       ,'PROW_PATH_CLOSURES_V'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6280'
                    AND  HMB_BLOCK_NAME = 'PROW_PATH_CLOSURES_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6280'
       ,'PROW_PATH_CLOSURE_PATHS_V'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6280'
                    AND  HMB_BLOCK_NAME = 'PROW_PATH_CLOSURE_PATHS_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6281'
       ,'PROW_PATH_CLOSURES_SUMMARY_V'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6281'
                    AND  HMB_BLOCK_NAME = 'PROW_PATH_CLOSURES_SUMMARY_V');
--
INSERT INTO HIG_MODULE_BLOCKS
       (HMB_MODULE_NAME
       ,HMB_BLOCK_NAME
       ,HMB_DATE_CREATED
       ,HMB_DATE_MODIFIED
       ,HMB_CREATED_BY
       ,HMB_MODIFIED_BY
       )
SELECT 
        'PROW6290'
       ,'PROW_AUDIT_REC_TYPE_V'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_BLOCKS
                   WHERE HMB_MODULE_NAME = 'PROW6290'
                    AND  HMB_BLOCK_NAME = 'PROW_AUDIT_REC_TYPE_V');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- HIG_MODULE_LINKS
--
-- select * from prow_metadata.hig_module_links
-- order by hml_id
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_module_links
SET TERM OFF

INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000001
       ,'PROW6021'
       ,'PROW_LAND_PARCELS_SUMMARY_V'
       ,'PROW6020'
       ,'PROW_LAND_PARCELS_V'
       ,'N'
       ,'Land Parcel Ownership'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000001);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000002
       ,'PROW6060'
       ,'PROW_PATHS_DETAILS_V'
       ,'PROW6230'
       ,'PROW_PROSECUTIONS_V'
       ,'N'
       ,'Prosecutions'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000002);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000003
       ,'PROW6050'
       ,'PROW_ACCESS_LAND_DETAILS_V'
       ,'PROW6022'
       ,'PROW_PARTIES_V'
       ,'N'
       ,'Contact Details'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000003);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000004
       ,'PROW6050'
       ,'PROW_ACCESS_LAND_DETAILS_V'
       ,'PROW6230'
       ,'PROW_PROSECUTIONS_V'
       ,'N'
       ,'Prosecutions'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000004);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000005
       ,'PROW6060'
       ,'PROW_PATHS_DETAILS_V'
       ,'PROW6210'
       ,'PROW_VEHICLE_LICENCES_V'
       ,'N'
       ,'Vehicle Use Licenses'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000005);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000006
       ,'PROW6222'
       ,'PROW_ENFORCEMENT_SUMMARY_V'
       ,'PROW6220'
       ,'PROW_ENFORCEMENTS_V'
       ,'N'
       ,'Enforcements'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000006);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000007
       ,'PROW6050'
       ,'PROW_ACCESS_LAND_DETAILS_V'
       ,'PROW6220'
       ,'PROW_ENFORCEMENTS_V'
       ,'N'
       ,'Enforcements'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000007);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000008
       ,'PROW6060'
       ,'PROW_PATHS_DETAILS_V'
       ,'PROW6220'
       ,'PROW_ENFORCEMENTS_V'
       ,'N'
       ,'Enforcements'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000008);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000009
       ,'PROW6050'
       ,'PROW_ACCESS_LAND_DETAILS_V'
       ,'PROW6030'
       ,'IIT'
       ,'N'
       ,'Access Land'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000009);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000010
       ,'PROW6030'
       ,'IIT'
       ,'PROW6020'
       ,'PROW_LAND_PARCELS_V'
       ,'N'
       ,'Access Land Ownership'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000010);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000011
       ,'PROW6030'
       ,'PROW_ACCESS_LAND_PARCELS_V'
       ,'PROW6020'
       ,'PROW_LAND_PARCELS_V'
       ,'N'
       ,'Land Parcel Ownership'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000011);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000013
       ,'PROW6020'
       ,'PROW_LAND_CONTACTS_V'
       ,'PROW6022'
       ,'PROW_PARTIES_V'
       ,'N'
       ,'Contact Details'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000013);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000014
       ,'PROW6210'
       ,'PROW_VEHICLE_LICENCE_CONT_V'
       ,'PROW6022'
       ,'PROW_PARTIES_V'
       ,'N'
       ,'Contact Details'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000014);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000015
       ,'PROW6220'
       ,'PROW_ENFORCEMENTS_V'
       ,'PROW6022'
       ,'PROW_PARTIES_V'
       ,'N'
       ,'Contact Details'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000015);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000017
       ,'PROW6240'
       ,'PROW_DEPOSITION_CONTACTS_V'
       ,'PROW6022'
       ,'PROW_PARTIES_V'
       ,'N'
       ,'Contact Details'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000017);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000018
       ,'PROW6260'
       ,'PROW_PATH_ORDER_CONTACTS_V'
       ,'PROW6022'
       ,'PROW_PARTIES_V'
       ,'N'
       ,'Contact Details'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000018);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000020
       ,'PROW6012'
       ,'PROW_ENQUIRY_SUMMARY_V'
       ,'DOC0150'
       ,'B1'
       ,'N'
       ,'Enquiry Details'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000020);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000021
       ,'PROW6030'
       ,'IIT'
       ,'PROW6050'
       ,'PROW_ACCESS_LANDS_V'
       ,'N'
       ,'Access Land History'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000021);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000023
       ,'PROW6260'
       ,'PROW_PATH_ORDERS_V'
       ,'PROW6010'
       ,'PROW_ACTION_SUMMARY_V'
       ,'N'
       ,'Actions'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000023);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000024
       ,'PROW6270'
       ,'PROW_MOD_ORDERS_V'
       ,'PROW6010'
       ,'PROW_ACTION_SUMMARY_V'
       ,'N'
       ,'Actions'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000024);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000025
       ,'PROW6260'
       ,'PROW_PATH_ORDER_PATHS_V'
       ,'PROW6060'
       ,'PROW_PATHS_V'
       ,'N'
       ,'Path History'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000025);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000026
       ,'PROW6060'
       ,'PROW_PATHS_DETAILS_V'
       ,'PROW6270'
       ,'PROW_MOD_ORDERS_V'
       ,'N'
       ,'Modification Orders'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000026);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000027
       ,'PROW6060'
       ,'PROW_PATHS_DETAILS_V'
       ,'PROW6250'
       ,'PROW_DEFINITIVE_STATEMENT_V'
       ,'N'
       ,'Definitive Statements'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000027);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000028
       ,'PROW6220'
       ,'PROW_ENFORCEMENTS_V'
       ,'PROW6060'
       ,'PROW_PATHS_V'
       ,'N'
       ,'Path History'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000028);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000029
       ,'PROW6220'
       ,'PROW_ENFORCEMENTS_V'
       ,'PROW6050'
       ,'PROW_ACCESS_LANDS_V'
       ,'N'
       ,'Access Land History'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000029);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000030
       ,'PROW6220'
       ,'PROW_ENFORCEMENTS_V'
       ,'PROW6230'
       ,'PROW_PROSECUTIONS_V'
       ,'N'
       ,'Prosecutions (for this person)'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000030);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000031
       ,'PROW6060'
       ,'PROW_PATHS_DETAILS_V'
       ,'PROW6260'
       ,'PROW_PATH_ORDERS_V'
       ,'N'
       ,'Public Path Orders'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000031);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000032
       ,'PROW6060'
       ,'PROW_PATHS_DETAILS_V'
       ,'PROW6280'
       ,'PROW_PATH_CLOSURES_V'
       ,'N'
       ,'Path Closures'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000032);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000033
       ,'PROW6020'
       ,'PROW_LAND_PARCELS_V'
       ,'PROW6030'
       ,'IIT'
       ,'N'
       ,'Access Land'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000033);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000034
       ,'PROW6220'
       ,'PROW_ENFORCEMENTS_V'
       ,'PROW6230'
       ,'PROW_PROSECUTIONS_V'
       ,'N'
       ,'Prosecutions (for this enforcement)'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000034);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000035
       ,'PROW6050'
       ,'PROW_ACCESS_LAND_DETAILS_V'
       ,'PROW6240'
       ,'PROW_DEPOSITIONS_V'
       ,'N'
       ,'Depositions'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000035);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000036
       ,'PROW6050'
       ,'PROW_ACCESS_LAND_DETAILS_V'
       ,'DOC0150'
       ,'B1'
       ,'N'
       ,'Enquiry Details'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000036);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000037
       ,'PROW6060'
       ,'PROW_PATHS_DETAILS_V'
       ,'DOC0150'
       ,'B1'
       ,'N'
       ,'Enquiry Details'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000037);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000038
       ,'PROW6260'
       ,'PROW_PATH_ORDERS_V'
       ,'DOC0150'
       ,'B1'
       ,'N'
       ,'Enquiry Details'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000038);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000039
       ,'PROW6020'
       ,'PROW_LAND_PARCELS_V'
       ,'PROW6050'
       ,'PROW_ACCESS_LANDS_V'
       ,'N'
       ,'Access Land History'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000039);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000040
       ,'PROW6280'
       ,'PROW_PATH_CLOSURES_V'
       ,'PROW6022'
       ,'PROW_PARTIES_V'
       ,'N'
       ,'Contact Details'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000040);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000041
       ,'PROW6280'
       ,'PROW_PATH_CLOSURE_PATHS_V'
       ,'PROW6060'
       ,'PROW_PATHS_V'
       ,'N'
       ,'Path History'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000041);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000042
       ,'PROW6270'
       ,'PROW_MOD_ORDER_CONTACTS_V'
       ,'PROW6022'
       ,'PROW_PARTIES_V'
       ,'N'
       ,'Contact Details'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000042);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000043
       ,'PROW6270'
       ,'PROW_MOD_ORDER_PATHS_V'
       ,'PROW6060'
       ,'PROW_PATHS_V'
       ,'N'
       ,'Path History'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000043);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000044
       ,'PROW6270'
       ,'PROW_MOD_ORDERS_V'
       ,'DOC0150'
       ,'B1'
       ,'N'
       ,'Enquiry Details'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000044);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000045
       ,'PROW6250'
       ,'PROW_DEFINITIVE_STATEMENT_V'
       ,'PROW6060'
       ,'PROW_PATHS_V'
       ,'N'
       ,'Path History'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000045);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000046
       ,'PROW6230'
       ,'PROW_PROS_ENFORCEMENTS_V'
       ,'PROW6220'
       ,'PROW_ENFORCEMENTS_V'
       ,'N'
       ,'Enforcements'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000046);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000047
       ,'PROW6230'
       ,'PROW_PROSECUTION_OFFENCES_V'
       ,'PROW6060'
       ,'PROW_PATHS_V'
       ,'N'
       ,'Path History'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000047);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000048
       ,'PROW6210'
       ,'PROW_VEHICLE_LICENSES_PATH_V'
       ,'PROW6060'
       ,'PROW_PATHS_V'
       ,'N'
       ,'Path History'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000048);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000049
       ,'PROW6260'
       ,'PROW_PATH_ORDERS_V'
       ,'PROW6290'
       ,'PROW_AUDIT_REC_TYPE_V'
       ,'N'
       ,'Audit'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000049);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000050
       ,'PROW6270'
       ,'PROW_MOD_ORDERS_V'
       ,'PROW6290'
       ,'PROW_AUDIT_REC_TYPE_V'
       ,'N'
       ,'Audit'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000050);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000051
       ,'PROW6280'
       ,'PROW_PATH_CLOSURES_V'
       ,'PROW6290'
       ,'PROW_AUDIT_REC_TYPE_V'
       ,'N'
       ,'Audit'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000051);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000052
       ,'PROW6000'
       ,'CONTROL'
       ,'PROW6281'
       ,'PROW_PATH_CLOSURES_SUMMARY_V'
       ,'N'
       ,'Path Closure Summary'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000052);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000053
       ,'PROW6000'
       ,'CONTROL'
       ,'PROW6271'
       ,'PROW_MOD_ORDERS_SUMMARY_V'
       ,'N'
       ,'Modification Order Summary'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000053);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000054
       ,'PROW6000'
       ,'CONTROL'
       ,'PROW6012'
       ,'PROW_ENQUIRY_SUMMARY_V'
       ,'N'
       ,'Enquiry Summary'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000054);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000055
       ,'PROW6000'
       ,'CONTROL'
       ,'PROW6261'
       ,'PROW_PATH_ORDERS_SUMMARY_V'
       ,'N'
       ,'Public Path Order Summary'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000055);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000057
       ,'PROW6261'
       ,'PROW_PATH_ORDERS_SUMMARY_V'
       ,'PROW6260'
       ,'PROW_PATH_ORDERS_V'
       ,'N'
       ,'Public Path Orders'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000057);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000058
       ,'PROW6271'
       ,'PROW_MOD_ORDERS_SUMMARY_V'
       ,'PROW6270'
       ,'PROW_MOD_ORDERS_V'
       ,'N'
       ,'Modification Orders'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000058);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000059
       ,'PROW6281'
       ,'PROW_PATH_CLOSURES_SUMMARY_V'
       ,'PROW6280'
       ,'PROW_PATH_CLOSURES_V'
       ,'N'
       ,'Path Closures'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000059);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000060
       ,'PROW6000'
       ,'CONTROL'
       ,'PROW6010'
       ,'PROW_ACTION_SUMMARY_V'
       ,'N'
       ,'Actions Summary'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000060);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000061
       ,'PROW6210'
       ,'PROW_VEHICLE_LICENCES_V'
       ,'DOC0150'
       ,'B1'
       ,'N'
       ,'Enquiry Details'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000061);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000062
       ,'PROW6240'
       ,'PROW_DEPOSITIONS_V'
       ,'DOC0150'
       ,'B1'
       ,'N'
       ,'Enquiry Details'
       ,'N'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000062);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000063
       ,'PROW6230'
       ,'PROW_PROSECUTIONS_V'
       ,'PROW6022'
       ,'PROW_PARTIES_V'
       ,'N'
       ,'Defendant Details'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000063);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000064
       ,'PROW6230'
       ,'PROW_PROSECUTIONS_V'
       ,'PROW6022'
       ,'PROW_PARTIES_V'
       ,'N'
       ,'Solicitor Details'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000064);
--
INSERT INTO HIG_MODULE_LINKS
       (HML_ID
       ,HML_MODULE_NAME_FROM
       ,HML_BLOCK_NAME_FROM
       ,HML_MODULE_NAME_TO
       ,HML_BLOCK_NAME_TO
       ,HML_FORCE_COMMIT
       ,HML_MENU_ITEM_LABEL
       ,HML_SHOW_ON_MENU
       ,HML_DATE_CREATED
       ,HML_DATE_MODIFIED
       ,HML_CREATED_BY
       ,HML_MODIFIED_BY
       )
SELECT 
        1000065
       ,'PROW6000'
       ,'CONTROL'
       ,'PROW6014'
       ,'PROW_WORK_ORDER_SUMMARY_V'
       ,'N'
       ,'Work Order Summary'
       ,'Y'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINKS
                   WHERE HML_ID = 1000065);
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- HIG_MODULE_LINK_METHODS
--
-- select * from prow_metadata.hig_module_link_methods
-- order by hmlm_id
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_module_link_methods
SET TERM OFF

INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000001
       ,1000001
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000001);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000002
       ,1000002
       ,'PATH_RECORD_ID'
       ,'NUMBER'
       ,'PPR_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000002);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000005
       ,1000003
       ,'ACLD_RECORD_ID'
       ,'NUMBER'
       ,'HCT_ID'
       ,'NUMBER'
       ,':PARAM_TO =  :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000005);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000006
       ,1000004
       ,'ACLD_RECORD_ID'
       ,'NUMBER'
       ,'PPR_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000006);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000007
       ,1000005
       ,'PATH_RECORD_ID'
       ,'NUMBER'
       ,'PVL_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000007);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000009
       ,1000006
       ,'PEN_ID'
       ,'NUMBER'
       ,'PEN_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000009);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000010
       ,1000007
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,'PEN_IIT_NE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000010);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000011
       ,1000008
       ,'NE_ID'
       ,'NUMBER'
       ,'PEN_NE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000011);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000012
       ,1000009
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000012);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000013
       ,1000010
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,':PARAM_TO IN (SELECT IIG.IIG_ITEM_ID FROM NM_INV_ITEM_GROUPINGS_ALL IIG, PROW_LAND_PARCELS_V V_PARCEL WHERE IIG.IIG_PARENT_ID = :PARAM_FROM)'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000013);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000014
       ,1000011
       ,'IIG_ITEM_ID'
       ,'NUMBER'
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000014);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000016
       ,1000013
       ,'PLC_HCT_ID'
       ,'NUMBER'
       ,'HCT_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000016);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000017
       ,1000014
       ,'HCT_ID'
       ,'NUMBER'
       ,'HCT_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000017);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000018
       ,1000015
       ,'PEN_HCT_ID'
       ,'NUMBER'
       ,'HCT_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000018);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000020
       ,1000017
       ,'PDEC_HCT_ID'
       ,'NUMBER'
       ,'HCT_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000020);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000021
       ,1000018
       ,'PPOC_HCT_ID'
       ,'NUMBER'
       ,'HCT_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000021);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000025
       ,1000020
       ,'DOC_ID'
       ,'NUMBER'
       ,'DOC_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000025);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000026
       ,1000021
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000026);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000031
       ,1000023
       ,'DAS_DOC_ID'
       ,'NUMBER'
       ,'DAC_DOC_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000031);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000032
       ,1000024
       ,'DAS_DOC_ID'
       ,'NUMBER'
       ,'DAC_DOC_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000032);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000033
       ,1000025
       ,'PPOP_NE_ID'
       ,'NUMBER'
       ,'NE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000033);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000034
       ,1000026
       ,'PATH_RECORD_ID'
       ,'NUMBER'
       ,'PMO_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000034);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000035
       ,1000027
       ,'PATH_RECORD_ID'
       ,'NUMBER'
       ,'PDS_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000035);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000036
       ,1000028
       ,'PEN_NE_ID'
       ,'NUMBER'
       ,'NE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000036);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000037
       ,1000029
       ,'PEN_IIT_NE_ID'
       ,'NUMBER'
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000037);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000038
       ,1000030
       ,'PEN_HCT_ID'
       ,'NUMBER'
       ,'PPR_DEFENDANT_HCT_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000038);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000039
       ,1000031
       ,'PATH_RECORD_ID'
       ,'NUMBER'
       ,'PPO_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000039);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000040
       ,1000032
       ,'PATH_RECORD_ID'
       ,'NUMBER'
       ,'PCL_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000040);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000041
       ,1000034
       ,'PEN_ID'
       ,'NUMBER'
       ,'PPR_ID'
       ,'NUMBER'
       ,':PARAM_TO IN (SELECT PPE.PPE_PPR_ID FROM PROW_PROS_ENFORCEMENTS_V PPE WHERE PPE.PEN_ID = :PARAM_FROM)'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000041);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000042
       ,1000033
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,':PARAM_TO IN (SELECT IIG_PARENT_ID FROM PROW_ACCESS_LAND_PARCELS_V WHERE IIG_ITEM_ID = :PARAM_FROM)'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000042);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000043
       ,1000035
       ,'ACLD_RECORD_ID'
       ,'NUMBER'
       ,'PDE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000043);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000044
       ,1000036
       ,'ACLD_RECORD_ID'
       ,'NUMBER'
       ,'DOC_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000044);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000045
       ,1000037
       ,'PATH_RECORD_ID'
       ,'NUMBER'
       ,'DOC_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000045);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000046
       ,1000038
       ,'DAS_DOC_ID'
       ,'NUMBER'
       ,'DOC_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000046);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000047
       ,1000039
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,'IIT_NE_ID'
       ,'NUMBER'
       ,':PARAM_TO IN (SELECT IIG_PARENT_ID FROM PROW_ACCESS_LAND_PARCELS_V WHERE IIG_ITEM_ID = :PARAM_FROM)'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000047);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000048
       ,1000040
       ,'PCL_HCT_ID'
       ,'NUMBER'
       ,'HCT_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000048);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000049
       ,1000041
       ,'PCLP_NE_ID'
       ,'NUMBER'
       ,'NE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000049);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000050
       ,1000042
       ,'PMOC_HCT_ID'
       ,'NUMBER'
       ,'HCT_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000050);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000051
       ,1000043
       ,'PMOP_NE_ID'
       ,'NUMBER'
       ,'NE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000051);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000052
       ,1000044
       ,'DAS_DOC_ID'
       ,'NUMBER'
       ,'DOC_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000052);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000053
       ,1000045
       ,'PDS_NE_ID'
       ,'NUMBER'
       ,'NE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000053);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000054
       ,1000046
       ,'PEN_ID'
       ,'NUMBER'
       ,'PEN_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000054);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000055
       ,1000047
       ,'PPRO_NE_ID'
       ,'NUMBER'
       ,'NE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000055);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000056
       ,1000048
       ,'NE_ID'
       ,'NUMBER'
       ,'NE_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000056);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000058
       ,1000049
       ,'PPO_AUDIT_LINK_DATA'
       ,'VARCHAR2'
       ,'PAT_PRIMARY_TABLE_NAME'
       ,'VARCHAR2'
       ,':PARAM_TO = '':PARAM_FROM'''
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000058);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000059
       ,1000049
       ,'PPO_ID'
       ,'NUMBER'
       ,'PAU_PRIMARY_RECORD_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000059);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000060
       ,1000050
       ,'PMO_AUDIT_LINK_DATA'
       ,'VARCHAR2'
       ,'PAT_PRIMARY_TABLE_NAME'
       ,'VARCHAR2'
       ,':PARAM_TO = '':PARAM_FROM'''
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000060);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000061
       ,1000050
       ,'PMO_ID'
       ,'NUMBER'
       ,'PAU_PRIMARY_RECORD_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000061);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000062
       ,1000051
       ,'PCL_AUDIT_LINK_DATA'
       ,'VARCHAR2'
       ,'PAT_PRIMARY_TABLE_NAME'
       ,'VARCHAR2'
       ,':PARAM_TO = '':PARAM_FROM'''
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000062);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000063
       ,1000051
       ,'PCL_ID'
       ,'NUMBER'
       ,'PAU_PRIMARY_RECORD_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000063);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000067
       ,1000052
       ,'HUS_NAME'
       ,'NUMBER'
       ,'PCL_OFFICER_USER_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000067);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000068
       ,1000052
       ,'TYPE_OR_STAGE'
       ,'VARCHAR2'
       ,'PCL_PCT_ID'
       ,'VARCHAR2'
       ,':PARAM_TO IN (:PARAM_FROM) AND pcl_closure_status != ''REDUNDANT'''
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000068);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000069
       ,1000053
       ,'TYPE_OR_STAGE'
       ,'VARCHAR2'
       ,'PMO_ORDER_STAGE'
       ,'VARCHAR2'
       ,':PARAM_TO IN (:PARAM_FROM)'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000069);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000070
       ,1000053
       ,'HUS_NAME'
       ,'NUMBER'
       ,'PMO_OFFICER_USER_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000070);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000071
       ,1000054
       ,'TYPE_OR_STAGE'
       ,'VARCHAR2'
       ,'STAGE'
       ,'VARCHAR2'
       ,':PARAM_TO IN (:PARAM_FROM)'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000071);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000072
       ,1000054
       ,'HUS_NAME'
       ,'NUMBER'
       ,'DOC_COMPL_USER_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000072);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000073
       ,1000054
       ,'PRIORITY'
       ,'VARCHAR2'
       ,'DOC_COMPL_CPR_ID'
       ,'VARCHAR2'
       ,':PARAM_TO IN (:PARAM_FROM)'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000073);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000074
       ,1000055
       ,'TYPE_OR_STAGE'
       ,'VARCHAR2'
       ,'PPO_ORDER_STAGE'
       ,'VARCHAR2'
       ,':PARAM_TO IN (:PARAM_FROM)'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000074);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000075
       ,1000055
       ,'HUS_NAME'
       ,'NUMBER'
       ,'PPO_OFFICER_USER_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000075);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000077
       ,1000057
       ,'PPO_ID'
       ,'NUMBER'
       ,'PPO_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000077);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000078
       ,1000058
       ,'PMO_ID'
       ,'NUMBER'
       ,'PMO_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000078);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000079
       ,1000059
       ,'PCL_ID'
       ,'NUMBER'
       ,'PCL_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000079);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000080
       ,1000060
       ,'TYPE_OR_STAGE'
       ,'VARCHAR2'
       ,'STAGE'
       ,'VARCHAR2'
       ,':PARAM_TO IN (:PARAM_FROM)'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000080);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000081
       ,1000060
       ,'HUS_NAME'
       ,'NUMBER'
       ,'HUS_USER_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000081);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000082
       ,1000061
       ,'DOC_ID'
       ,'NUMBER'
       ,'DOC_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000082);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000083
       ,1000062
       ,'DOC_ID'
       ,'NUMBER'
       ,'DOC_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000083);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000084
       ,1000063
       ,'PPR_DEFENDANT_HCT_ID'
       ,'NUMBER'
       ,'HCT_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000084);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000085
       ,1000064
       ,'PPR_SOLICITOR_HCT_ID'
       ,'NUMBER'
       ,'HCT_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000085);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000086
       ,1000065
       ,'HUS_NAME'
       ,'NUMBER'
       ,'HUS_USER_ID'
       ,'NUMBER'
       ,':PARAM_TO = :PARAM_FROM'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000086);
--
INSERT INTO HIG_MODULE_LINK_METHODS
       (HMLM_ID
       ,HMLM_MODULE_LINK_ID
       ,HMLM_PARAM_FROM
       ,HMLM_PARAM_FROM_TYPE
       ,HMLM_PARAM_TO
       ,HMLM_PARAM_TO_TYPE
       ,HMLM_METHOD_SQL
       ,HMLM_DATE_CREATED
       ,HMLM_DATE_MODIFIED
       ,HMLM_CREATED_BY
       ,HMLM_MODIFIED_BY
       )
SELECT 
        1000087
       ,1000065
       ,'TYPE_OR_STAGE'
       ,'VARCHAR2'
       ,'STAGE'
       ,'VARCHAR2'
       ,':PARAM_TO IN (:PARAM_FROM)'
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,to_date('20090415103948','YYYYMMDDHH24MISS')
       ,'PROW_METADATA'
       ,'PROW_METADATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_LINK_METHODS
                   WHERE HMLM_ID = 1000087);
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- HIG_WORKTRAY_BLOCKS
--
-- select * from prow_metadata.hig_worktray_blocks
-- order by hwb_id
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_worktray_blocks
SET TERM OFF

INSERT INTO HIG_WORKTRAY_BLOCKS
       (HWB_ID
       ,HWB_BLOCK_NAME
       ,HWB_ENABLED
       ,HWB_SEQUENCE
       ,HWB_DESCRIPTION
       ,HWB_DATE_CREATED
       ,HWB_DATE_MODIFIED
       ,HWB_CREATED_BY
       ,HWB_MODIFIED_BY
       )
SELECT 
        'PROW_DEFINITIVE_MAP'
       ,'PROW Definitive Map'
       ,'Y'
       ,2
       ,'This block shows a summary of outstanding enquiries and legal orders for a selected user.   This block is normally made available to the PROW Definitive Map team and managers.'
       ,to_date('20070129160127','YYYYMMDDHH24MISS')
       ,to_date('20070129160514','YYYYMMDDHH24MISS')
       ,'PROWDATA'
       ,'PROWDATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_WORKTRAY_BLOCKS
                   WHERE HWB_ID = 'PROW_DEFINITIVE_MAP');
--
INSERT INTO HIG_WORKTRAY_BLOCKS
       (HWB_ID
       ,HWB_BLOCK_NAME
       ,HWB_ENABLED
       ,HWB_SEQUENCE
       ,HWB_DESCRIPTION
       ,HWB_DATE_CREATED
       ,HWB_DATE_MODIFIED
       ,HWB_CREATED_BY
       ,HWB_MODIFIED_BY
       )
SELECT 
        'PROW_MANAGEMENT'
       ,'PROW Management'
       ,'Y'
       ,3
       ,'This block shows an overview of the responsibilities and YTD workloads for a selected user. '
       ,to_date('20070129160418','YYYYMMDDHH24MISS')
       ,to_date('20070129160418','YYYYMMDDHH24MISS')
       ,'PROWDATA'
       ,'PROWDATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_WORKTRAY_BLOCKS
                   WHERE HWB_ID = 'PROW_MANAGEMENT');
--
INSERT INTO HIG_WORKTRAY_BLOCKS
       (HWB_ID
       ,HWB_BLOCK_NAME
       ,HWB_ENABLED
       ,HWB_SEQUENCE
       ,HWB_DESCRIPTION
       ,HWB_DATE_CREATED
       ,HWB_DATE_MODIFIED
       ,HWB_CREATED_BY
       ,HWB_MODIFIED_BY
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW Operations'
       ,'Y'
       ,1
       ,'This block shows a summary of outstanding enquiries and work orders for a selected user.   This block is normally made available to the PROW Operations team and managers.'
       ,to_date('20070129155717','YYYYMMDDHH24MISS')
       ,to_date('20070129160151','YYYYMMDDHH24MISS')
       ,'PROWDATA'
       ,'PROWDATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_WORKTRAY_BLOCKS
                   WHERE HWB_ID = 'PROW_OPERATIONS');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- DOC_GATEWAYS
--
-- select * from prow_metadata.doc_gateways
-- order by dgt_table_name
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT doc_gateways
SET TERM OFF

INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'PROW_CLOSURES'
       ,'PROW Closures'
       ,'PCL_ID'
       ,'PCL_REFERENCE||'', ''||HCT_FIRST_NAME||'' ''||HCT_SURNAME||'', ''||TO_CHAR(PCL_DATE_COMMENCED,''DD-MON-RRRR'')'
       ,'PROW_CLOSURES, HIG_CONTACTS'
       ,'PCL_HCT_ID = HCT_ID'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'PROW_CLOSURES');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'PROW_DEFINITIVE_STATEMENT'
       ,'PROW Definitive Statement'
       ,'PDS_ID'
       ,'NE_UNIQUE||'', ''||PDS_RIGHT_OF_WAY_NO||'' ''||PDS_DISTRICT||'', ''||TO_CHAR(PDS_RELEVANT_DATE,''DD-MON-RRRR'')'
       ,'PROW_DEFINITIVE_STATEMENT, NM_ELEMENTS_ALL'
       ,'PDS_NE_ID = NE_ID'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'PROW_DEFINITIVE_STATEMENT');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'PROW_DEPOSITIONS'
       ,'PROW Depositions'
       ,'PDE_ID'
       ,'PDE_REFERENCE||'', ''||HCT_FIRST_NAME||'' ''||HCT_SURNAME||'', ''||TO_CHAR(PDE_DATE_OF_SUBMISSION,''DD-MON-RRRR'')'
       ,'PROW_DEPOSITIONS, PROW_DEPOSITION_CONTACTS, HIG_CONTACTS'
       ,'PDEC_PDE_ID = PDE_ID AND PDEC_PRIMARY_CONTACT = ''Y'' AND PDEC_HCT_ID = HCT_ID'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'PROW_DEPOSITIONS');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'PROW_ENFORCEMENTS'
       ,'PROW Enforcements'
       ,'PEN_ID'
       ,'PEN_REFERENCE||'', ''||HCT_FIRST_NAME||'' ''||HCT_SURNAME||'', ''||TO_CHAR(PEN_DATE_EFFECTIVE,''DD-MON-RRRR'')'
       ,'PROW_ENFORCEMENTS, HIG_CONTACTS'
       ,'PEN_HCT_ID = HCT_ID'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'PROW_ENFORCEMENTS');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PROW Modification Orders'
       ,'PMO_ID'
       ,'PMO_REFERENCE||'', ''||HCT_FIRST_NAME||'' ''||HCT_SURNAME||'', ''||PMO_ORDER_STAGE||'', ''||TO_CHAR(PMO_INVEST_APPL_RECEIVED,''DD-MON-RRRR'')'
       ,'PROW_MOD_ORDERS, PROW_MOD_ORDER_CONTACTS, HIG_CONTACTS'
       ,'PMOC_PMO_ID = PMO_ID AND PMOC_PRIMARY_CONTACT = ''Y'' AND PMOC_HCT_ID = HCT_ID'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'PROW_MOD_ORDERS');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PROW Path Orders'
       ,'PPO_ID'
       ,'PPO_REFERENCE||'', ''||HCT_FIRST_NAME||'' ''||HCT_SURNAME||'', ''||PPO_ORDER_STAGE||'', ''||TO_CHAR(PPO_INVEST_APPL_RECEIVED,''DD-MON-RRRR'')'
       ,'PROW_PATH_ORDERS, PROW_PATH_ORDER_CONTACTS, HIG_CONTACTS'
       ,'PPOC_PPO_ID = PPO_ID AND PPOC_PRIMARY_CONTACT = ''Y'' AND PPOC_HCT_ID = HCT_ID'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'PROW_PATH_ORDERS');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'PROW_PROSECUTIONS'
       ,'PROW Prosecutions'
       ,'PPR_ID'
       ,'PPR_REFERENCE||'', ''||HCT_FIRST_NAME||'' ''||HCT_SURNAME||'', ''||TO_CHAR(PPR_DATE_COMMENCED,''DD-MON-RRRR'')'
       ,'PROW_PROSECUTIONS, HIG_CONTACTS'
       ,'PPR_HCT_ID = HCT_ID'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'PROW_PROSECUTIONS');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'PROW_VEHICLE_LICENSES'
       ,'PROW Vehicle Use Licenses'
       ,'PVL_ID'
       ,'PVL_REFERENCE||'', ''||HCT_FIRST_NAME||'' ''||HCT_SURNAME||'', ''||TO_CHAR(PVL_START_DATE,''DD-MON-RRRR'')'
       ,'PROW_VEHICLE_LICENSES, PROW_VEHICLE_LICENSE_CONTACTS, HIG_CONTACTS'
       ,'PVLC_PVL_ID = PVL_ID AND PVLC_PRIMARY_CONTACT = ''Y'' AND PVLC_HCT_ID = HCT_ID'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'PROW_VEHICLE_LICENSES');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- DOC_GATE_SYNS
--
-- select * from prow_metadata.doc_gate_syns
-- order by dgs_dgt_table_name
--         ,dgs_table_syn
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT doc_gate_syns
SET TERM OFF

INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'DOCS'
       ,'PROW_ENQUIRY_SUMMARY_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'DOCS'
                    AND  DGS_TABLE_SYN = 'PROW_ENQUIRY_SUMMARY_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'NM_INV_ITEMS_ALL'
       ,'PROW_ACCESS_LANDS_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'NM_INV_ITEMS_ALL'
                    AND  DGS_TABLE_SYN = 'PROW_ACCESS_LANDS_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'NM_INV_ITEMS_ALL'
       ,'PROW_ACCESS_LAND_PARCELS_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'NM_INV_ITEMS_ALL'
                    AND  DGS_TABLE_SYN = 'PROW_ACCESS_LAND_PARCELS_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'NM_INV_ITEMS_ALL'
       ,'PROW_LAND_PARCELS_SUMMARY_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'NM_INV_ITEMS_ALL'
                    AND  DGS_TABLE_SYN = 'PROW_LAND_PARCELS_SUMMARY_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'NM_INV_ITEMS_ALL'
       ,'PROW_LAND_PARCELS_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'NM_INV_ITEMS_ALL'
                    AND  DGS_TABLE_SYN = 'PROW_LAND_PARCELS_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'PROW_CLOSURES'
       ,'PROW_PATH_CLOSURES_SUMMARY_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'PROW_CLOSURES'
                    AND  DGS_TABLE_SYN = 'PROW_PATH_CLOSURES_SUMMARY_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'PROW_CLOSURES'
       ,'PROW_PATH_CLOSURES_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'PROW_CLOSURES'
                    AND  DGS_TABLE_SYN = 'PROW_PATH_CLOSURES_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'PROW_DEFINITIVE_STATEMENT'
       ,'PROW_DEFINITIVE_STATEMENT_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'PROW_DEFINITIVE_STATEMENT'
                    AND  DGS_TABLE_SYN = 'PROW_DEFINITIVE_STATEMENT_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'PROW_DEPOSITIONS'
       ,'PROW_DEPOSITIONS_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'PROW_DEPOSITIONS'
                    AND  DGS_TABLE_SYN = 'PROW_DEPOSITIONS_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'PROW_ENFORCEMENTS'
       ,'PROW_ENFORCEMENTS_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'PROW_ENFORCEMENTS'
                    AND  DGS_TABLE_SYN = 'PROW_ENFORCEMENTS_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'PROW_ENFORCEMENTS'
       ,'PROW_ENFORCEMENT_SUMMARY_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'PROW_ENFORCEMENTS'
                    AND  DGS_TABLE_SYN = 'PROW_ENFORCEMENT_SUMMARY_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PROW_MOD_ORDERS_SUMMARY_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'PROW_MOD_ORDERS'
                    AND  DGS_TABLE_SYN = 'PROW_MOD_ORDERS_SUMMARY_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PROW_MOD_ORDERS_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'PROW_MOD_ORDERS'
                    AND  DGS_TABLE_SYN = 'PROW_MOD_ORDERS_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PROW_PATH_ORDERS_SUMMARY_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'PROW_PATH_ORDERS'
                    AND  DGS_TABLE_SYN = 'PROW_PATH_ORDERS_SUMMARY_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PROW_PATH_ORDERS_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'PROW_PATH_ORDERS'
                    AND  DGS_TABLE_SYN = 'PROW_PATH_ORDERS_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'PROW_PROSECUTIONS'
       ,'PROW_PROSECUTIONS_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'PROW_PROSECUTIONS'
                    AND  DGS_TABLE_SYN = 'PROW_PROSECUTIONS_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'PROW_VEHICLE_LICENSES'
       ,'PROW_VEHICLE_LICENSES_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'PROW_VEHICLE_LICENSES'
                    AND  DGS_TABLE_SYN = 'PROW_VEHICLE_LICENSES_V');
--
INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'ROAD_SEGMENTS_ALL'
       ,'PROW_PATHS_V' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'ROAD_SEGMENTS_ALL'
                    AND  DGS_TABLE_SYN = 'PROW_PATHS_V');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- HIG_STANDARD_FAVOURITES
--
-- select * from prow_metadata.hig_standard_favourites
-- order by hstf_parent
--         ,hstf_child
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_standard_favourites
SET TERM OFF

INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'FAVOURITES'
       ,'PROW'
       ,'Public Rights Of Way Manager'
       ,'F'
       ,3 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'FAVOURITES'
                    AND  HSTF_CHILD = 'PROW');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW'
       ,'PROW_DEFINITIVE'
       ,'Definitive Map'
       ,'F'
       ,2 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW'
                    AND  HSTF_CHILD = 'PROW_DEFINITIVE');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW'
       ,'PROW_OPERATIONS'
       ,'Operations'
       ,'F'
       ,1 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW'
                    AND  HSTF_CHILD = 'PROW_OPERATIONS');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW'
       ,'PROW_REFERENCE'
       ,'Reference Data'
       ,'F'
       ,3 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW'
                    AND  HSTF_CHILD = 'PROW_REFERENCE');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_DEFINITIVE'
       ,'DOC0150'
       ,'Enquiries'
       ,'M'
       ,3 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_DEFINITIVE'
                    AND  HSTF_CHILD = 'DOC0150');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_DEFINITIVE'
       ,'PROW6000'
       ,'Worktray'
       ,'M'
       ,1 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_DEFINITIVE'
                    AND  HSTF_CHILD = 'PROW6000');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_DEFINITIVE'
       ,'PROW6012'
       ,'Enquiry Summary'
       ,'M'
       ,2 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_DEFINITIVE'
                    AND  HSTF_CHILD = 'PROW6012');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_DEFINITIVE'
       ,'PROW6022'
       ,'Contacts'
       ,'M'
       ,4 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_DEFINITIVE'
                    AND  HSTF_CHILD = 'PROW6022');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_DEFINITIVE'
       ,'PROW6060'
       ,'Path History'
       ,'M'
       ,13 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_DEFINITIVE'
                    AND  HSTF_CHILD = 'PROW6060');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_DEFINITIVE'
       ,'PROW6240'
       ,'Depositions'
       ,'M'
       ,5 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_DEFINITIVE'
                    AND  HSTF_CHILD = 'PROW6240');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_DEFINITIVE'
       ,'PROW6250'
       ,'Definitive Statement'
       ,'M'
       ,6 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_DEFINITIVE'
                    AND  HSTF_CHILD = 'PROW6250');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_DEFINITIVE'
       ,'PROW6260'
       ,'Public Path Orders'
       ,'M'
       ,8 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_DEFINITIVE'
                    AND  HSTF_CHILD = 'PROW6260');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_DEFINITIVE'
       ,'PROW6261'
       ,'Public Path Order Summary'
       ,'M'
       ,7 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_DEFINITIVE'
                    AND  HSTF_CHILD = 'PROW6261');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_DEFINITIVE'
       ,'PROW6270'
       ,'Modification Orders'
       ,'M'
       ,10 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_DEFINITIVE'
                    AND  HSTF_CHILD = 'PROW6270');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_DEFINITIVE'
       ,'PROW6271'
       ,'Modification Order Summary'
       ,'M'
       ,9 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_DEFINITIVE'
                    AND  HSTF_CHILD = 'PROW6271');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_DEFINITIVE'
       ,'PROW6280'
       ,'Path Closures'
       ,'M'
       ,12 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_DEFINITIVE'
                    AND  HSTF_CHILD = 'PROW6280');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_DEFINITIVE'
       ,'PROW6281'
       ,'Path Closure Summary'
       ,'M'
       ,11 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_DEFINITIVE'
                    AND  HSTF_CHILD = 'PROW6281');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'DOC0150'
       ,'Enquiries'
       ,'M'
       ,3 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'DOC0150');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'MAI3800'
       ,'Work Orders (Defects)'
       ,'M'
       ,3.4 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'MAI3800');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'NM0510'
       ,'Asset Items'
       ,'M'
       ,5 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'NM0510');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW6000'
       ,'Worktray'
       ,'M'
       ,1 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'PROW6000');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW6012'
       ,'Enquiry Summary'
       ,'M'
       ,2 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'PROW6012');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW6014'
       ,'Work Order Summary'
       ,'M'
       ,3.2 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'PROW6014');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW6020'
       ,'Land Ownership'
       ,'M'
       ,7 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'PROW6020');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW6021'
       ,'Land Ownership Summary'
       ,'M'
       ,6 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'PROW6021');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW6022'
       ,'Contacts'
       ,'M'
       ,4 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'PROW6022');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW6030'
       ,'Access Land'
       ,'M'
       ,8 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'PROW6030');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW6050'
       ,'Access Land History'
       ,'M'
       ,9 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'PROW6050');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW6060'
       ,'Path History'
       ,'M'
       ,14 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'PROW6060');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW6210'
       ,'Vehicle Use Licences'
       ,'M'
       ,13 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'PROW6210');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW6220'
       ,'Enforcements'
       ,'M'
       ,11 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'PROW6220');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW6222'
       ,'Enforcement Summary'
       ,'M'
       ,10 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'PROW6222');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW6230'
       ,'Prosecutions'
       ,'M'
       ,12 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_OPERATIONS'
                    AND  HSTF_CHILD = 'PROW6230');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_REFERENCE'
       ,'NM0410'
       ,'Asset Metamodel'
       ,'M'
       ,2 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_REFERENCE'
                    AND  HSTF_CHILD = 'NM0410');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_REFERENCE'
       ,'PROW6002'
       ,'Worktray Blocks'
       ,'M'
       ,3 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_REFERENCE'
                    AND  HSTF_CHILD = 'PROW6002');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_REFERENCE'
       ,'PROW6292'
       ,'Audit Options'
       ,'M'
       ,4 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_REFERENCE'
                    AND  HSTF_CHILD = 'PROW6292');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_REFERENCE'
       ,'PROW6294'
       ,'Maintain Closure Types'
       ,'M'
       ,5 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_REFERENCE'
                    AND  HSTF_CHILD = 'PROW6294');
--
INSERT INTO HIG_STANDARD_FAVOURITES
       (HSTF_PARENT
       ,HSTF_CHILD
       ,HSTF_DESCR
       ,HSTF_TYPE
       ,HSTF_ORDER
       )
SELECT 
        'PROW_REFERENCE'
       ,'PROW9120'
       ,'Domains'
       ,'M'
       ,1 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_STANDARD_FAVOURITES
                   WHERE HSTF_PARENT = 'PROW_REFERENCE'
                    AND  HSTF_CHILD = 'PROW9120');
--
--
--
----------------------------------------------------------------------------------------

--
COMMIT;
--
set feedback on
set define on
--
-------------------------------
-- END OF GENERATED METADATA --
-------------------------------
--
