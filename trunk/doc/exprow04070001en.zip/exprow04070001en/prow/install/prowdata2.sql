-----------------------------------------------------------------------------
--
--   PVCS Identifiers :-
--
--       PVCS id          : $Header:   //vm_latest/archives/prow/install/prowdata2.sql-arc   2.2   Jun 27 2013 15:48:06   James.Wadsworth  $
--       Module Name      : $Workfile:   prowdata2.sql  $
--       Date into PVCS   : $Date:   Jun 27 2013 15:48:06  $
--       Date fetched Out : $Modtime:   Jun 27 2013 12:53:56  $
--       Version          : $Revision:   2.2  $
--       Table Owner      : PROW_METADATA
--       Generation Date  : 10-SEP-2009 15:31
--
--   Product metadata script
--   As at Release 4.1.0.0
--
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
--
--   TABLES PROCESSED
--   ================
--   GRI_MODULES
--   GRI_PARAMS
--   GRI_MODULE_PARAMS
--   GRI_PARAM_DEPENDENCIES
--   GRI_PARAM_LOOKUP
--
-----------------------------------------------------------------------------


set define off;
set feedback off;

---------------------------------
-- START OF GENERATED METADATA --
---------------------------------


----------------------------------------------------------------------------------------
-- GRI_MODULES
--
-- select * from prow_metadata.gri_modules
-- order by grm_module
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT gri_modules
SET TERM OFF

--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- GRI_PARAMS
--
-- select * from prow_metadata.gri_params
-- order by gp_param
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT gri_params
SET TERM OFF

--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- GRI_MODULE_PARAMS
--
-- select * from prow_metadata.gri_module_params
-- order by gmp_module
--         ,gmp_param
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT gri_module_params
SET TERM OFF

--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- GRI_PARAM_DEPENDENCIES
--
-- select * from prow_metadata.gri_param_dependencies
-- order by gpd_indep_param
--         ,gpd_module
--         ,gpd_dep_param
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT gri_param_dependencies
SET TERM OFF

--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- GRI_PARAM_LOOKUP
--
-- select * from prow_metadata.gri_param_lookup
-- order by gpl_param
--         ,gpl_value
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT gri_param_lookup
SET TERM OFF

--
--
----------------------------------------------------------------------------------------

--
COMMIT;
--
set feedback on
set define on
--
-------------------------------
-- END OF GENERATED METADATA --
-------------------------------
--
