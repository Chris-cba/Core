-----------------------------------------------------------------------------
--
--   PVCS Identifiers :-
--
--       PVCS id          : $Header:   //vm_latest/archives/prow/install/prowdata3.sql-arc   2.3   Jun 27 2013 15:48:06   James.Wadsworth  $
--       Module Name      : $Workfile:   prowdata3.sql  $
--       Date into PVCS   : $Date:   Jun 27 2013 15:48:06  $
--       Date fetched Out : $Modtime:   Jun 27 2013 12:53:56  $
--       Version          : $Revision:   2.3  $
--       Table Owner      : PROW_METADATA
--       Generation Date  : 10-SEP-2009 15:31
--
--   Product metadata script
--   As at Release 4.1.0.0
--
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
--
--   TABLES PROCESSED
--   ================
--   HIG_ROLES
--   HIG_MODULE_ROLES
--   HIG_WORKTRAY_ROLES
--
-----------------------------------------------------------------------------


set define off;
set feedback off;

---------------------------------
-- START OF GENERATED METADATA --
---------------------------------


----------------------------------------------------------------------------------------
-- HIG_ROLES
--
-- select * from prow_metadata.hig_roles
-- order by hro_role
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_roles
SET TERM OFF

INSERT INTO HIG_ROLES
       (HRO_ROLE
       ,HRO_PRODUCT
       ,HRO_DESCR
       )
SELECT 
        'PROW_ADMIN'
       ,'PROW'
       ,'Public Rights of Way Manager Administration' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ROLES
                   WHERE HRO_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_ROLES
       (HRO_ROLE
       ,HRO_PRODUCT
       ,HRO_DESCR
       )
SELECT 
        'PROW_READONLY'
       ,'PROW'
       ,'Public Rights of Way Manager Readonly Access' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ROLES
                   WHERE HRO_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_ROLES
       (HRO_ROLE
       ,HRO_PRODUCT
       ,HRO_DESCR
       )
SELECT 
        'PROW_USER'
       ,'PROW'
       ,'Public Rights of Way Manager Updates' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ROLES
                   WHERE HRO_ROLE = 'PROW_USER');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- HIG_MODULE_ROLES
--
-- select * from prow_metadata.hig_module_roles
-- order by hmr_module
--         ,hmr_role
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_module_roles
SET TERM OFF

INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6000'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6000'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6000'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6000'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6000'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6000'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6002'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6002'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6002'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6002'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6002'
       ,'PROW_USER'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6002'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6010'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6010'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6010'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6010'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6010'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6010'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6012'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6012'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6012'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6012'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6012'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6012'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6014'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6014'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6014'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6014'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6014'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6014'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6020'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6020'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6020'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6020'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6020'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6020'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6021'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6021'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6021'
       ,'PROW_READONLY'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6021'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6021'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6021'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6022'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6022'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6022'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6022'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6022'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6022'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6030'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6030'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6030'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6030'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6030'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6030'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6050'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6050'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6050'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6050'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6050'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6050'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6060'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6060'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6060'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6060'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6060'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6060'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6210'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6210'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6210'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6210'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6210'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6210'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6220'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6220'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6220'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6220'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6220'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6220'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6222'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6222'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6222'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6222'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6222'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6222'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6230'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6230'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6230'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6230'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6230'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6230'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6240'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6240'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6240'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6240'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6240'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6240'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6250'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6250'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6250'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6250'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6250'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6250'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6260'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6260'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6260'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6260'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6260'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6260'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6261'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6261'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6261'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6261'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6261'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6261'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6270'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6270'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6270'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6270'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6270'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6270'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6271'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6271'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6271'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6271'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6271'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6271'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6280'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6280'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6280'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6280'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6280'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6280'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6281'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6281'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6281'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6281'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6281'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6281'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6290'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6290'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6290'
       ,'PROW_READONLY'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6290'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6290'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6290'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6292'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6292'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6292'
       ,'PROW_READONLY'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6292'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6292'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6292'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6294'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6294'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6294'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6294'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW6294'
       ,'PROW_USER'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW6294'
                    AND  HMR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW9120'
       ,'PROW_ADMIN'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW9120'
                    AND  HMR_ROLE = 'PROW_ADMIN');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW9120'
       ,'PROW_READONLY'
       ,'READONLY' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW9120'
                    AND  HMR_ROLE = 'PROW_READONLY');
--
INSERT INTO HIG_MODULE_ROLES
       (HMR_MODULE
       ,HMR_ROLE
       ,HMR_MODE
       )
SELECT 
        'PROW9120'
       ,'PROW_USER'
       ,'NORMAL' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_MODULE_ROLES
                   WHERE HMR_MODULE = 'PROW9120'
                    AND  HMR_ROLE = 'PROW_USER');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- HIG_WORKTRAY_ROLES
--
-- select * from prow_metadata.hig_worktray_roles
-- order by hwr_hwb_id
--         ,hwr_role
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_worktray_roles
SET TERM OFF

INSERT INTO HIG_WORKTRAY_ROLES
       (HWR_HWB_ID
       ,HWR_ROLE
       ,HWR_DATE_CREATED
       ,HWR_DATE_MODIFIED
       ,HWR_CREATED_BY
       ,HWR_MODIFIED_BY
       )
SELECT 
        'PROW_DEFINITIVE_MAP'
       ,'PROW_USER'
       ,to_date('20070129160743','YYYYMMDDHH24MISS')
       ,to_date('20070129160743','YYYYMMDDHH24MISS')
       ,'PROWDATA'
       ,'PROWDATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_WORKTRAY_ROLES
                   WHERE HWR_HWB_ID = 'PROW_DEFINITIVE_MAP'
                    AND  HWR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_WORKTRAY_ROLES
       (HWR_HWB_ID
       ,HWR_ROLE
       ,HWR_DATE_CREATED
       ,HWR_DATE_MODIFIED
       ,HWR_CREATED_BY
       ,HWR_MODIFIED_BY
       )
SELECT 
        'PROW_MANAGEMENT'
       ,'PROW_USER'
       ,to_date('20070129160756','YYYYMMDDHH24MISS')
       ,to_date('20070129160756','YYYYMMDDHH24MISS')
       ,'PROWDATA'
       ,'PROWDATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_WORKTRAY_ROLES
                   WHERE HWR_HWB_ID = 'PROW_MANAGEMENT'
                    AND  HWR_ROLE = 'PROW_USER');
--
INSERT INTO HIG_WORKTRAY_ROLES
       (HWR_HWB_ID
       ,HWR_ROLE
       ,HWR_DATE_CREATED
       ,HWR_DATE_MODIFIED
       ,HWR_CREATED_BY
       ,HWR_MODIFIED_BY
       )
SELECT 
        'PROW_OPERATIONS'
       ,'PROW_USER'
       ,to_date('20070129160729','YYYYMMDDHH24MISS')
       ,to_date('20070129160729','YYYYMMDDHH24MISS')
       ,'PROWDATA'
       ,'PROWDATA' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_WORKTRAY_ROLES
                   WHERE HWR_HWB_ID = 'PROW_OPERATIONS'
                    AND  HWR_ROLE = 'PROW_USER');
--
--
--
----------------------------------------------------------------------------------------

--
COMMIT;
--
set feedback on
set define on
--
-------------------------------
-- END OF GENERATED METADATA --
-------------------------------
--
