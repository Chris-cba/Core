-----------------------------------------------------------------------------
--
--   PVCS Identifiers :-
--
--       PVCS id          : $Header:   //vm_latest/archives/prow/install/prowdata4.sql-arc   2.2   Jun 27 2013 15:48:08   James.Wadsworth  $
--       Module Name      : $Workfile:   prowdata4.sql  $
--       Date into PVCS   : $Date:   Jun 27 2013 15:48:08  $
--       Date fetched Out : $Modtime:   Jun 27 2013 12:53:56  $
--       Version          : $Revision:   2.2  $
--       Table Owner      : PROW_METADATA
--       Generation Date  : 10-SEP-2009 15:31
--
--   Product metadata script
--   As at Release 4.1.0.0
--
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
--
--   TABLES PROCESSED
--   ================
--   PROW_AUDIT_TABLES
--   PROW_AUDIT_COLUMNS
--   PROW_CLOSURE_TYPES
--   PROW_MOD_ORDER_STAGES
--
-----------------------------------------------------------------------------


set define off;
set feedback off;

---------------------------------
-- START OF GENERATED METADATA --
---------------------------------


----------------------------------------------------------------------------------------
-- PROW_AUDIT_TABLES
--
-- select * from prow_metadata.prow_audit_tables
-- order by pat_table_name
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT prow_audit_tables
SET TERM OFF

INSERT INTO PROW_AUDIT_TABLES
       (PAT_PRIMARY_TABLE_NAME
       ,PAT_TABLE_NAME
       ,PAT_AUDITED
       ,PAT_TABLE_TEXT
       )
SELECT 
        'PROW_CLOSURES'
       ,'PROW_CLOSURES'
       ,'N'
       ,'Path Closure' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_TABLES
                   WHERE PAT_TABLE_NAME = 'PROW_CLOSURES');
--
INSERT INTO PROW_AUDIT_TABLES
       (PAT_PRIMARY_TABLE_NAME
       ,PAT_TABLE_NAME
       ,PAT_AUDITED
       ,PAT_TABLE_TEXT
       )
SELECT 
        'PROW_CLOSURES'
       ,'PROW_CLOSURE_PATHS'
       ,'N'
       ,'Path' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_TABLES
                   WHERE PAT_TABLE_NAME = 'PROW_CLOSURE_PATHS');
--
INSERT INTO PROW_AUDIT_TABLES
       (PAT_PRIMARY_TABLE_NAME
       ,PAT_TABLE_NAME
       ,PAT_AUDITED
       ,PAT_TABLE_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PROW_MOD_ORDERS'
       ,'N'
       ,'Modification Order' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_TABLES
                   WHERE PAT_TABLE_NAME = 'PROW_MOD_ORDERS');
--
INSERT INTO PROW_AUDIT_TABLES
       (PAT_PRIMARY_TABLE_NAME
       ,PAT_TABLE_NAME
       ,PAT_AUDITED
       ,PAT_TABLE_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PROW_MOD_ORDER_PATHS'
       ,'N'
       ,'Path' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_TABLES
                   WHERE PAT_TABLE_NAME = 'PROW_MOD_ORDER_PATHS');
--
INSERT INTO PROW_AUDIT_TABLES
       (PAT_PRIMARY_TABLE_NAME
       ,PAT_TABLE_NAME
       ,PAT_AUDITED
       ,PAT_TABLE_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PROW_PATH_ORDERS'
       ,'N'
       ,'Public Path Order' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_TABLES
                   WHERE PAT_TABLE_NAME = 'PROW_PATH_ORDERS');
--
INSERT INTO PROW_AUDIT_TABLES
       (PAT_PRIMARY_TABLE_NAME
       ,PAT_TABLE_NAME
       ,PAT_AUDITED
       ,PAT_TABLE_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PROW_PATH_ORDER_PATHS'
       ,'N'
       ,'Path' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_TABLES
                   WHERE PAT_TABLE_NAME = 'PROW_PATH_ORDER_PATHS');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- PROW_AUDIT_COLUMNS
--
-- select * from prow_metadata.prow_audit_columns
-- order by pac_column_name
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT prow_audit_columns
SET TERM OFF

INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_CLOSURE_PATHS'
       ,'PCLP_ALTERNATIVE_ROUTE'
       ,'N'
       ,'Path'
       ,'Alternative Route' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PCLP_ALTERNATIVE_ROUTE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_CLOSURE_PATHS'
       ,'PCLP_DESCRIPTION'
       ,'N'
       ,'Path'
       ,'Descriptions' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PCLP_DESCRIPTION');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_CLOSURES'
       ,'PCL_CLOSURE_STATUS'
       ,'N'
       ,'Summ'
       ,'Status' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PCL_CLOSURE_STATUS');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_CLOSURES'
       ,'PCL_COMMENTS'
       ,'N'
       ,'Summ'
       ,'Comments' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PCL_COMMENTS');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_CLOSURES'
       ,'PCL_DATE_COMMENCED'
       ,'N'
       ,'Summ'
       ,'Order Commenced' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PCL_DATE_COMMENCED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_CLOSURES'
       ,'PCL_DATE_COMPLETE'
       ,'N'
       ,'Summ'
       ,'Date Order Complete' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PCL_DATE_COMPLETE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_CLOSURES'
       ,'PCL_DATE_EXPIRES'
       ,'N'
       ,'Summ'
       ,'Order Expires' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PCL_DATE_EXPIRES');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_CLOSURES'
       ,'PCL_HCT_ID'
       ,'N'
       ,'Summ'
       ,'Contact' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PCL_HCT_ID');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_CLOSURES'
       ,'PCL_OFFICER_USER_ID'
       ,'N'
       ,'Summ'
       ,'Officer' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PCL_OFFICER_USER_ID');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_CLOSURES'
       ,'PCL_PATH_OFFICER_USER_ID'
       ,'Y'
       ,'Summ'
       ,'Path Officer' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PCL_PATH_OFFICER_USER_ID');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_CLOSURES'
       ,'PCL_PCT_ID'
       ,'N'
       ,'Summ'
       ,'Closure Type' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PCL_PCT_ID');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_CLOSURES'
       ,'PCL_REASON'
       ,'N'
       ,'Summ'
       ,'Reason' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PCL_REASON');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_CLOSURES'
       ,'PCL_RECHARGEABLE'
       ,'N'
       ,'Summ'
       ,'Rechargeable' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PCL_RECHARGEABLE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_CLOSURES'
       ,'PCL_REFERENCE'
       ,'N'
       ,'Summ'
       ,'Reference' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PCL_REFERENCE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDER_PATHS'
       ,'PMOP_CATEGORY'
       ,'N'
       ,'Path'
       ,'Category' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMOP_CATEGORY');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDER_PATHS'
       ,'PMOP_EFFECT'
       ,'N'
       ,'Path'
       ,'Effect' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMOP_EFFECT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDER_PATHS'
       ,'PMOP_END_GRID_REF'
       ,'N'
       ,'Path'
       ,'End OS Grid Ref' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMOP_END_GRID_REF');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDER_PATHS'
       ,'PMOP_START_GRID_REF'
       ,'N'
       ,'Path'
       ,'Start OS Grid Ref' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMOP_START_GRID_REF');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_APPEAL_DIRECTION'
       ,'N'
       ,'Appeal'
       ,'Sec of State Direction' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_APPEAL_DIRECTION');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_APPEAL_NOTES'
       ,'N'
       ,'Appeal'
       ,'Notes' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_APPEAL_NOTES');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_APPEAL_RESULT'
       ,'N'
       ,'Appeal'
       ,'Result of Appeal' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_APPEAL_RESULT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_APPEAL_SUBMITTED'
       ,'N'
       ,'Appeal'
       ,'Submission Date to PINS' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_APPEAL_SUBMITTED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_CONSOL_DATE'
       ,'N'
       ,'Consol'
       ,'Date of Consolidation into DMS' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_CONSOL_DATE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_CONSOL_DISTRICT'
       ,'N'
       ,'Consol'
       ,'DMS District' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_CONSOL_DISTRICT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_CONSOL_LEGAL_EVENT'
       ,'N'
       ,'Consol'
       ,'Consolidation Legal Event Identifier' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_CONSOL_LEGAL_EVENT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_CONSOL_LEGAL_SUBEVENT'
       ,'N'
       ,'Consol'
       ,'Consolidation Legal Event Sub-Id' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_CONSOL_LEGAL_SUBEVENT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_CONSOL_MAP_TILES'
       ,'N'
       ,'Consol'
       ,'O.S. Map Titles' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_CONSOL_MAP_TILES');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_CONSOL_NOTES'
       ,'N'
       ,'Consol'
       ,'Notes' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_CONSOL_NOTES');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_CONSOL_PAGE_KEY'
       ,'N'
       ,'Consol'
       ,'DMS Page Key' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_CONSOL_PAGE_KEY');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_CONSOL_PAGE_NO'
       ,'N'
       ,'Consol'
       ,'DMS Page' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_CONSOL_PAGE_NO');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_COST_NOTES'
       ,'N'
       ,'Cost'
       ,'Notes' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_COST_NOTES');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_INVEST_APPEAL_MADE'
       ,'N'
       ,'Invest'
       ,'Appeal Made' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_INVEST_APPEAL_MADE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_INVEST_APPL_RECEIVED'
       ,'N'
       ,'Invest'
       ,'Application Received' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_INVEST_APPL_RECEIVED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_INVEST_EV_SUMMARISED'
       ,'N'
       ,'Invest'
       ,'User Evidence Summarised' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_INVEST_EV_SUMMARISED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_INVEST_EV_SUMMARY_SENT'
       ,'N'
       ,'Invest'
       ,'Doc Ev Summary to Landowner' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_INVEST_EV_SUMMARY_SENT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_INVEST_GROUPS_CONSULTED'
       ,'N'
       ,'Invest'
       ,'User Groups and Auth Consulted' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_INVEST_GROUPS_CONSULTED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_INVEST_LAND_SEARCH'
       ,'N'
       ,'Invest'
       ,'Land Search' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_INVEST_LAND_SEARCH');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_INVEST_NOTES'
       ,'N'
       ,'Invest'
       ,'Investigation Notes' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_INVEST_NOTES');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_INVEST_OWNER_CONSULT'
       ,'N'
       ,'Invest'
       ,'Land Owner Consultation' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_INVEST_OWNER_CONSULT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_INVEST_REPORT_RECEIVED'
       ,'N'
       ,'Invest'
       ,'Archivist Report Received' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_INVEST_REPORT_RECEIVED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_INVEST_REPORT_REQUESTED'
       ,'N'
       ,'Invest'
       ,'Archivist Report Requested' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_INVEST_REPORT_REQUESTED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_INVEST_REPORT_TARGET'
       ,'N'
       ,'Invest'
       ,'Report Target Date' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_INVEST_REPORT_TARGET');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_INVEST_USER_SUMMARY_SENT'
       ,'N'
       ,'Invest'
       ,'User Evidence to Land Owner' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_INVEST_USER_SUMMARY_SENT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_MAKE_CONFIRMATION_NOTES'
       ,'N'
       ,'Make'
       ,'Confirmation Notes' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_MAKE_CONFIRMATION_NOTES');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_MAKE_NOTES'
       ,'N'
       ,'Make'
       ,'Notes' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_MAKE_NOTES');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_MAKE_ORDER_CONFIRMED'
       ,'N'
       ,'Make'
       ,'Order Confirmed Date' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_MAKE_ORDER_CONFIRMED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_MAKE_ORDER_TITLE'
       ,'N'
       ,'Make'
       ,'Order Title' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_MAKE_ORDER_TITLE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_MAKE_WORKS_COMPLETE'
       ,'N'
       ,'Make'
       ,'Works Complete' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_MAKE_WORKS_COMPLETE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_MAKE_WORKS_REQUESTED'
       ,'N'
       ,'Make'
       ,'Works Requested' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_MAKE_WORKS_REQUESTED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_OFFICER_USER_ID'
       ,'N'
       ,'Summ'
       ,'Officer' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_OFFICER_USER_ID');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_ORDER_STAGE'
       ,'N'
       ,'Summ'
       ,'Order Stage' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_ORDER_STAGE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_REFERENCE'
       ,'N'
       ,'Summ'
       ,'Reference 1' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_REFERENCE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_REFERENCE2'
       ,'N'
       ,'Summ'
       ,'Reference 2' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_REFERENCE2');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_SUMM_DATE_COMPLETE'
       ,'N'
       ,'Summ'
       ,'Order Complete' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_SUMM_DATE_COMPLETE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_SUMM_DESCRIPTION'
       ,'N'
       ,'Summ'
       ,'Application Description' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_SUMM_DESCRIPTION');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_SUMM_NEAREST_CITY'
       ,'N'
       ,'Summ'
       ,'Nearest City' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_SUMM_NEAREST_CITY');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_SUMM_NEAREST_TOWN'
       ,'N'
       ,'Summ'
       ,'Nearest Town' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_SUMM_NEAREST_TOWN');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_SUMM_NEAREST_VILLAGE'
       ,'N'
       ,'Summ'
       ,'Nearest Village' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_SUMM_NEAREST_VILLAGE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_SUMM_NOTES'
       ,'N'
       ,'Summ'
       ,'Notes' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_SUMM_NOTES');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_SUMM_PRIORITY'
       ,'N'
       ,'Summ'
       ,'Order Priority' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_SUMM_PRIORITY');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_MOD_ORDERS'
       ,'PMO_SUMM_TARGET_DATE'
       ,'N'
       ,'Summ'
       ,'Target Date' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PMO_SUMM_TARGET_DATE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDER_PATHS'
       ,'PPOP_CATEGORY'
       ,'N'
       ,'Path'
       ,'Category' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPOP_CATEGORY');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDER_PATHS'
       ,'PPOP_EFFECT'
       ,'N'
       ,'Path'
       ,'Effect' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPOP_EFFECT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDER_PATHS'
       ,'PPOP_END_GRID_REF'
       ,'N'
       ,'Path'
       ,'End OS Grid Ref' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPOP_END_GRID_REF');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDER_PATHS'
       ,'PPOP_START_GRID_REF'
       ,'N'
       ,'Path'
       ,'Start OS Grid Ref' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPOP_START_GRID_REF');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_APPEAL_DIRECTION'
       ,'N'
       ,'Appeal'
       ,'Sec of State Direction' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_APPEAL_DIRECTION');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_APPEAL_NOTES'
       ,'N'
       ,'Appeal'
       ,'Notes' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_APPEAL_NOTES');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_APPEAL_RESULT'
       ,'N'
       ,'Appeal'
       ,'Result of Appeal' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_APPEAL_RESULT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_APPEAL_SUBMITTED'
       ,'N'
       ,'Appeal'
       ,'Submission Date to PINS' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_APPEAL_SUBMITTED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_CONSOL_CROW_ORDER'
       ,'N'
       ,'Consol'
       ,'CRoW Act Schedule 5 Order?' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_CONSOL_CROW_ORDER');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_CONSOL_DATE'
       ,'N'
       ,'Consol'
       ,'Date of Consolidation into DMS' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_CONSOL_DATE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_CONSOL_DISTRICT'
       ,'N'
       ,'Consol'
       ,'DMS District' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_CONSOL_DISTRICT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_CONSOL_LEGAL_EVENT'
       ,'N'
       ,'Consol'
       ,'Consolidation Legal Event Identifier' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_CONSOL_LEGAL_EVENT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_CONSOL_LEGAL_SUBEVENT'
       ,'N'
       ,'Consol'
       ,'Consolidation Legal Event Sub-Id' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_CONSOL_LEGAL_SUBEVENT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_CONSOL_MAP_TILES'
       ,'N'
       ,'Consol'
       ,'O.S. Map Titles' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_CONSOL_MAP_TILES');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_CONSOL_NOTES'
       ,'N'
       ,'Consol'
       ,'Notes' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_CONSOL_NOTES');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_CONSOL_PAGE_KEY'
       ,'N'
       ,'Consol'
       ,'DMS Page Key' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_CONSOL_PAGE_KEY');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_CONSOL_PAGE_NO'
       ,'N'
       ,'Consol'
       ,'DMS Page' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_CONSOL_PAGE_NO');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_COST_NOTES'
       ,'N'
       ,'Cost'
       ,'Notes' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_COST_NOTES');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_DISCON_AUTHORITY'
       ,'N'
       ,'Other OMA'
       ,'Order Making Authority' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_DISCON_AUTHORITY');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_DISCON_CONFIRMED'
       ,'N'
       ,'Other OMA'
       ,'Date Order Confirmed' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_DISCON_CONFIRMED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_DISCON_CONSULTATION'
       ,'N'
       ,'Other OMA'
       ,'Date of Consultation' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_DISCON_CONSULTATION');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_DISCON_COUNCIL_RESPONDED'
       ,'N'
       ,'Other OMA'
       ,'Date County Council Responded' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_DISCON_COUNCIL_RESPONDED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_DISCON_INSTRUCTED'
       ,'N'
       ,'Other OMA'
       ,'Date OMA Instructed to Confirm' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_DISCON_INSTRUCTED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_DISCON_LEGISLATION'
       ,'N'
       ,'Other OMA'
       ,'Legislation' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_DISCON_LEGISLATION');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_DISCON_LOCATION'
       ,'N'
       ,'Other OMA'
       ,'Location' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_DISCON_LOCATION');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_DISCON_MAINT_AGREEMENT'
       ,'N'
       ,'Other OMA'
       ,'Maintenance Agreement' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_DISCON_MAINT_AGREEMENT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_DISCON_PUBLISHED'
       ,'N'
       ,'Other OMA'
       ,'Date Order Published' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_DISCON_PUBLISHED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_DISCON_RESPONSE'
       ,'N'
       ,'Other OMA'
       ,'Details of Response' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_DISCON_RESPONSE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_DISCON_WORKS_COMPLETED'
       ,'N'
       ,'Other OMA'
       ,'Date Works Completed' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_DISCON_WORKS_COMPLETED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_INVEST_APPL_ACK'
       ,'N'
       ,'Invest'
       ,'Application Acknowledged' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_INVEST_APPL_ACK');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_INVEST_APPL_INFORMED'
       ,'N'
       ,'Invest'
       ,'Date Applicant Informed' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_INVEST_APPL_INFORMED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_INVEST_APPL_RECEIVED'
       ,'N'
       ,'Invest'
       ,'Application Received' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_INVEST_APPL_RECEIVED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_INVEST_FORM_AUTHORISED'
       ,'N'
       ,'Invest'
       ,'Date Authorised' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_INVEST_FORM_AUTHORISED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_INVEST_INSTRUCTED_LEGAL'
       ,'N'
       ,'Invest'
       ,'Date of Instruction to Legal' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_INVEST_INSTRUCTED_LEGAL');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_INVEST_LEGISLATION'
       ,'N'
       ,'Invest'
       ,'Legislation' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_INVEST_LEGISLATION');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_INVEST_OBJECTIONS'
       ,'N'
       ,'Invest'
       ,'Objections at Consultation' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_INVEST_OBJECTIONS');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_INVEST_OFFICER_CONSULT'
       ,'N'
       ,'Invest'
       ,'Date Officer Consulted' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_INVEST_OFFICER_CONSULT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_INVEST_OFFICER_USER_ID'
       ,'N'
       ,'Invest'
       ,'Officer Consulted' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_INVEST_OFFICER_USER_ID');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_INVEST_POTENTIAL_CROW'
       ,'N'
       ,'Invest'
       ,'Potential CRoW Act appellant' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_INVEST_POTENTIAL_CROW');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_INVEST_PROTECTED_SITE'
       ,'N'
       ,'Invest'
       ,'Protected Site' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_INVEST_PROTECTED_SITE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_INVEST_SITE_CONSULT'
       ,'N'
       ,'Invest'
       ,'Date of Consultation' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_INVEST_SITE_CONSULT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_INVEST_SITE_VISIT'
       ,'N'
       ,'Invest'
       ,'Date of Site Visit' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_INVEST_SITE_VISIT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_AUTHORITY_DECISION'
       ,'N'
       ,'Make'
       ,'Decision' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_AUTHORITY_DECISION');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_AWAITING_WORKS'
       ,'N'
       ,'Make'
       ,'Awaiting Site Works?' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_AWAITING_WORKS');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_CERT_DATE'
       ,'N'
       ,'Make'
       ,'Date Certified' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_CERT_DATE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_CERT_USER_ID'
       ,'N'
       ,'Make'
       ,'Path Certified By' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_CERT_USER_ID');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_CONF_ADVERT'
       ,'N'
       ,'Make'
       ,'Date Advertised 2' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_CONF_ADVERT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_CONF_DATE'
       ,'N'
       ,'Make'
       ,'Date Confirmed' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_CONF_DATE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_CONSULTED'
       ,'N'
       ,'Make'
       ,'Date Consulted' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_CONSULTED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_EFFECTIVE'
       ,'N'
       ,'Make'
       ,'Order Effective' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_EFFECTIVE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_LEGAL_INSTRUCTED'
       ,'N'
       ,'Make'
       ,'Date Legal Instructed' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_LEGAL_INSTRUCTED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_MAINT_AGREEMENT'
       ,'N'
       ,'Make'
       ,'Maintenance Agreement' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_MAINT_AGREEMENT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_OBJ_RECEIVED'
       ,'N'
       ,'Make'
       ,'Objections Received' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_OBJ_RECEIVED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_OBJ_WITHDRAWN'
       ,'N'
       ,'Make'
       ,'Objections Withdrawn' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_OBJ_WITHDRAWN');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_OFFICER_USER_ID'
       ,'N'
       ,'Make'
       ,'Officer Consulted' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_OFFICER_USER_ID');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_ORDER_ADVERT'
       ,'N'
       ,'Make'
       ,'Date Advertised' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_ORDER_ADVERT');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_ORDER_CHECKED'
       ,'N'
       ,'Make'
       ,'Date Draft Checked' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_ORDER_CHECKED');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_ORDER_MADE'
       ,'N'
       ,'Make'
       ,'Date Order Made' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_ORDER_MADE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_MAKE_ORDER_TITLE'
       ,'N'
       ,'Make'
       ,'Order Title' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_MAKE_ORDER_TITLE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_OFFICER_USER_ID'
       ,'N'
       ,'Summ'
       ,'Officer' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_OFFICER_USER_ID');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_ORDER_STAGE'
       ,'N'
       ,'Summ'
       ,'Order Stage' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_ORDER_STAGE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_REFERENCE'
       ,'N'
       ,'Summ'
       ,'Reference 1' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_REFERENCE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_REFERENCE2'
       ,'N'
       ,'Summ'
       ,'Reference 2' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_REFERENCE2');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_SUMM_DATE_COMPLETE'
       ,'N'
       ,'Summ'
       ,'Order Complete' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_SUMM_DATE_COMPLETE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_SUMM_DESCRIPTION'
       ,'N'
       ,'Summ'
       ,'Application Description' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_SUMM_DESCRIPTION');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_SUMM_NEAREST_CITY'
       ,'N'
       ,'Summ'
       ,'Nearest City' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_SUMM_NEAREST_CITY');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_SUMM_NEAREST_TOWN'
       ,'N'
       ,'Summ'
       ,'Nearest Town' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_SUMM_NEAREST_TOWN');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_SUMM_NEAREST_VILLAGE'
       ,'N'
       ,'Summ'
       ,'Nearest Village' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_SUMM_NEAREST_VILLAGE');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_SUMM_NOTES'
       ,'N'
       ,'Summ'
       ,'Notes' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_SUMM_NOTES');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_SUMM_PRIORITY'
       ,'N'
       ,'Summ'
       ,'Order Priority' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_SUMM_PRIORITY');
--
INSERT INTO PROW_AUDIT_COLUMNS
       (PAC_TABLE_NAME
       ,PAC_COLUMN_NAME
       ,PAC_AUDITED
       ,PAC_BLOCK_TEXT
       ,PAC_ITEM_TEXT
       )
SELECT 
        'PROW_PATH_ORDERS'
       ,'PPO_SUMM_TARGET_DATE'
       ,'N'
       ,'Summ'
       ,'Target Date' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_AUDIT_COLUMNS
                   WHERE PAC_COLUMN_NAME = 'PPO_SUMM_TARGET_DATE');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- PROW_CLOSURE_TYPES
--
-- select * from prow_metadata.prow_closure_types
-- order by pct_id
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT prow_closure_types
SET TERM OFF

INSERT INTO PROW_CLOSURE_TYPES
       (PCT_ID
       ,PCT_CLOSURE_TYPE
       ,PCT_DURATION
       ,PCT_DAYS
       ,PCT_MONTHS
       )
SELECT 
        'EMERGENCY'
       ,'Emergency'
       ,'3 weeks'
       ,21
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_CLOSURE_TYPES
                   WHERE PCT_ID = 'EMERGENCY');
--
INSERT INTO PROW_CLOSURE_TYPES
       (PCT_ID
       ,PCT_CLOSURE_TYPE
       ,PCT_DURATION
       ,PCT_DAYS
       ,PCT_MONTHS
       )
SELECT 
        'SPECIAL'
       ,'Special Event'
       ,'3 days'
       ,3
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_CLOSURE_TYPES
                   WHERE PCT_ID = 'SPECIAL');
--
INSERT INTO PROW_CLOSURE_TYPES
       (PCT_ID
       ,PCT_CLOSURE_TYPE
       ,PCT_DURATION
       ,PCT_DAYS
       ,PCT_MONTHS
       )
SELECT 
        'TEMPORARY'
       ,'Temporary'
       ,'6 months'
       ,null
       ,6 FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_CLOSURE_TYPES
                   WHERE PCT_ID = 'TEMPORARY');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- PROW_MOD_ORDER_STAGES
--
-- select * from prow_metadata.prow_mod_order_stages
-- order by pmos_order_stage
--         ,pmos_status_code
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT prow_mod_order_stages
SET TERM OFF

INSERT INTO PROW_MOD_ORDER_STAGES
       (PMOS_ORDER_STAGE
       ,PMOS_STATUS_CODE
       )
SELECT 
        'ABANDONED'
       ,'COMPLETED' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_MOD_ORDER_STAGES
                   WHERE PMOS_ORDER_STAGE = 'ABANDONED'
                    AND  PMOS_STATUS_CODE = 'COMPLETED');
--
INSERT INTO PROW_MOD_ORDER_STAGES
       (PMOS_ORDER_STAGE
       ,PMOS_STATUS_CODE
       )
SELECT 
        'APPEAL'
       ,'DETERMINED' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_MOD_ORDER_STAGES
                   WHERE PMOS_ORDER_STAGE = 'APPEAL'
                    AND  PMOS_STATUS_CODE = 'DETERMINED');
--
INSERT INTO PROW_MOD_ORDER_STAGES
       (PMOS_ORDER_STAGE
       ,PMOS_STATUS_CODE
       )
SELECT 
        'APPMADE'
       ,'UNDETERMINED' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_MOD_ORDER_STAGES
                   WHERE PMOS_ORDER_STAGE = 'APPMADE'
                    AND  PMOS_STATUS_CODE = 'UNDETERMINED');
--
INSERT INTO PROW_MOD_ORDER_STAGES
       (PMOS_ORDER_STAGE
       ,PMOS_STATUS_CODE
       )
SELECT 
        'CONFIRMED'
       ,'COMPLETED' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_MOD_ORDER_STAGES
                   WHERE PMOS_ORDER_STAGE = 'CONFIRMED'
                    AND  PMOS_STATUS_CODE = 'COMPLETED');
--
INSERT INTO PROW_MOD_ORDER_STAGES
       (PMOS_ORDER_STAGE
       ,PMOS_STATUS_CODE
       )
SELECT 
        'CONSOLIDATED'
       ,'COMPLETED' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_MOD_ORDER_STAGES
                   WHERE PMOS_ORDER_STAGE = 'CONSOLIDATED'
                    AND  PMOS_STATUS_CODE = 'COMPLETED');
--
INSERT INTO PROW_MOD_ORDER_STAGES
       (PMOS_ORDER_STAGE
       ,PMOS_STATUS_CODE
       )
SELECT 
        'DRAFTORDER'
       ,'DETERMINED' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_MOD_ORDER_STAGES
                   WHERE PMOS_ORDER_STAGE = 'DRAFTORDER'
                    AND  PMOS_STATUS_CODE = 'DETERMINED');
--
INSERT INTO PROW_MOD_ORDER_STAGES
       (PMOS_ORDER_STAGE
       ,PMOS_STATUS_CODE
       )
SELECT 
        'INVEST'
       ,'UNDETERMINED' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_MOD_ORDER_STAGES
                   WHERE PMOS_ORDER_STAGE = 'INVEST'
                    AND  PMOS_STATUS_CODE = 'UNDETERMINED');
--
INSERT INTO PROW_MOD_ORDER_STAGES
       (PMOS_ORDER_STAGE
       ,PMOS_STATUS_CODE
       )
SELECT 
        'ORDERMADE-O'
       ,'DETERMINED' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_MOD_ORDER_STAGES
                   WHERE PMOS_ORDER_STAGE = 'ORDERMADE-O'
                    AND  PMOS_STATUS_CODE = 'DETERMINED');
--
INSERT INTO PROW_MOD_ORDER_STAGES
       (PMOS_ORDER_STAGE
       ,PMOS_STATUS_CODE
       )
SELECT 
        'ORDERMADE-U'
       ,'DETERMINED' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_MOD_ORDER_STAGES
                   WHERE PMOS_ORDER_STAGE = 'ORDERMADE-U'
                    AND  PMOS_STATUS_CODE = 'DETERMINED');
--
INSERT INTO PROW_MOD_ORDER_STAGES
       (PMOS_ORDER_STAGE
       ,PMOS_STATUS_CODE
       )
SELECT 
        'POTENTIAL'
       ,'UNDETERMINED' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM PROW_MOD_ORDER_STAGES
                   WHERE PMOS_ORDER_STAGE = 'POTENTIAL'
                    AND  PMOS_STATUS_CODE = 'UNDETERMINED');
--
--
--
----------------------------------------------------------------------------------------

--
COMMIT;
--
set feedback on
set define on
--
-------------------------------
-- END OF GENERATED METADATA --
-------------------------------
--
