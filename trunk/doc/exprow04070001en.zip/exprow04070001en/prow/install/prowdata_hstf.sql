-- SCCS ID Keyword, do not remove
-------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
-----------------------------------------------------------------------------
define sccsid = '$Header:   //vm_latest/archives/prow/install/prowdata_hstf.sql-arc   2.1   Jun 27 2013 15:50:20   James.Wadsworth  $'

-----------------------------------------------------------------------------
--
-- This script populates data for the menu on PROW v4.0
--
-----------------------------------------------------------------------------


----------------------------------------------------------------------------------
-- Create PROW main menu

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('FAVOURITES','PROW','Public Rights Of Way Manager','F',3);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW','PROW_OPERATIONS','Operations','F',1);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW','PROW_DEFINITIVE','Definitive Map','F',2);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW','PROW_REFERENCE','Reference Data','F',3);


----------------------------------------------------------------------------------
-- Create PROW Operations menu

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_OPERATIONS','PROW6000','Worktray','M',1);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_OPERATIONS','PROW6012','Enquiry Summary','M',2);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_OPERATIONS','DOC0150','Enquiries','M',3);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_OPERATIONS','PROW6022','Contacts','M',4);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_OPERATIONS','NM0510','Asset Items','M',5);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_OPERATIONS','PROW6021','Land Ownership Summary','M',6);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_OPERATIONS','PROW6020','Land Ownership','M',7);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_OPERATIONS','PROW6030','Access Land','M',8);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_OPERATIONS','PROW6050','Access Land History','M',9);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_OPERATIONS','PROW6222','Enforcement Summary','M',10);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_OPERATIONS','PROW6220','Enforcements','M',11);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_OPERATIONS','PROW6230','Prosecutions','M',12);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_OPERATIONS','PROW6210','Vehicle Use Licences','M',13);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_OPERATIONS','PROW6060','Path History','M',14);


----------------------------------------------------------------------------------
-- Create PROW Definitive Map menu

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_DEFINITIVE','PROW6000','Worktray','M',1);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_DEFINITIVE','PROW6012','Enquiry Summary','M',2);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_DEFINITIVE','DOC0150','Enquiries','M',3);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_DEFINITIVE','PROW6022','Contacts','M',4);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_DEFINITIVE','PROW6240','Depositions','M',5);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_DEFINITIVE','PROW6250','Definitive Statement','M',6);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_DEFINITIVE','PROW6261','Public Path Order Summary','M',7);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_DEFINITIVE','PROW6260','Public Path Orders','M',8);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_DEFINITIVE','PROW6271','Modification Order Summary','M',9);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_DEFINITIVE','PROW6270','Modification Orders','M',10);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_DEFINITIVE','PROW6281','Path Closure Summary','M',11);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_DEFINITIVE','PROW6280','Path Closures','M',12);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_DEFINITIVE','PROW6060','Path History','M',13);


----------------------------------------------------------------------------------
-- Create PROW Reference Data menu


INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_REFERENCE','PROW9120','Domains','M',1);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_REFERENCE','NM0410','Asset Metamodel','M',2);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_REFERENCE','PROW6002','Worktray Blocks','M',3);

INSERT INTO hig_standard_favourites (HSTF_PARENT, HSTF_CHILD, HSTF_DESCR, HSTF_TYPE, HSTF_ORDER)
VALUES ('PROW_REFERENCE','PROW6292','Audit Options','M',4);

----------------------------------------------------------------------------------


COMMIT
/
