--
-----------------------------------------------------------------------------
--
--   PVCS Identifiers :-
--
--       PVCS id          : $Header:   //vm_latest/archives/prow/install/prowroles.sql-arc   2.2   Jun 27 2013 15:48:08   James.Wadsworth  $
--       Module Name      : $Workfile:   prowroles.sql  $
--       Date into PVCS   : $Date:   Jun 27 2013 15:48:08  $
--       Date fetched Out : $Modtime:   Jun 27 2013 12:53:56  $
--       Version          : $Revision:   2.2  $
--
--   Product upgrade script
--
-----------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
-----------------------------------------------------------------------------
--
REM **************************************************************************
REM
REM	Copyright (c) 2009 EXOR Corporation.
REM
REM	This script creates a set of roles which may be granted to PROW users
REM
REM **************************************************************************

rem --------------------------------------------------------------------------
rem	Create a role for granting to the administrator.

set feedback off

PROMPT CREATE ROLE PROW_ADMIN;

DECLARE
  role_exists Exception;
  Pragma Exception_Init(role_exists, -1921); 
BEGIN
  EXECUTE IMMEDIATE 'CREATE ROLE PROW_ADMIN';
  NULL;
EXCEPTION
WHEN role_exists
THEN 
  Null;
END;
/

-- Grant the role to the user, with admin option
begin
   execute immediate 'grant prow_admin to '||user;
   execute immediate 'grant prow_admin to '||user||' with admin option';
end;
/

grant select any table to prow_admin;
grant insert any table to prow_admin;
grant update any table to prow_admin;
grant delete any table to prow_admin;
grant lock any table to prow_admin;
grant create any table to prow_admin;
grant create any view to prow_admin;
grant execute any procedure to prow_admin;
grant select any sequence to prow_admin;
grant create session to prow_admin;

grant alter session to prow_admin;
grant create public synonym to prow_admin;
grant create trigger to prow_admin;
grant create sequence to prow_admin;
grant create role to prow_admin;
grant create synonym to prow_admin;
grant create procedure to prow_admin;
grant create user to prow_admin;
grant grant any privilege to prow_admin;
grant grant any role to prow_admin;
grant drop public synonym to prow_admin;
grant drop user to prow_admin;
grant alter user to prow_admin;


rem --------------------------------------------------------------------------
rem	Create a role for granting to users who need update privileges.

PROMPT CREATE ROLE PROW_USER;

DECLARE
  role_exists Exception;
  Pragma Exception_Init(role_exists, -1921); 
BEGIN
  EXECUTE IMMEDIATE 'CREATE ROLE PROW_USER';
  NULL;
EXCEPTION
WHEN role_exists
THEN 
  Null;
END;
/

-- Grant the role to the user, with admin option
begin
   execute immediate 'grant prow_user to '||user;
   execute immediate 'grant prow_user to '||user||' with admin option';
end;
/

grant select any table to prow_user;
grant insert any table to prow_user;
grant update any table to prow_user;
grant delete any table to prow_user;
grant lock any table to prow_user;
grant create table to prow_user;
grant create view  to prow_user;
grant select any sequence to prow_user;
grant execute any procedure to prow_user;
grant create session to prow_user;


rem --------------------------------------------------------------------------
rem	Create a role for granting to readonly users.

PROMPT CREATE ROLE PROW_READONLY;

DECLARE
  role_exists Exception;
  Pragma Exception_Init(role_exists, -1921); 
BEGIN
  EXECUTE IMMEDIATE 'CREATE ROLE PROW_READONLY';
  NULL;
EXCEPTION
WHEN role_exists
THEN 
  Null;
END;
/

-- Grant the role to the user, with admin option
begin
   execute immediate 'grant prow_readonly to '||user;
   execute immediate 'grant prow_readonly to '||user||' with admin option';
end;
/

grant select any table to prow_readonly;
grant lock any table to prow_readonly;
grant create table to prow_readonly;
grant create view  to prow_readonly;
grant select any sequence to prow_readonly;
grant execute any procedure to prow_readonly;
grant create session to prow_readonly;

rem ---------------------------------------------------------------------------
rem These roles can now be assigned to Oracle users.

REM End of command file
REM
