-----------------------------------------------------------------------------
--
--   SCCS Identifiers :-
--
--       sccsid           : @(#)strpkb.sql	1.2 09/29/06
--       Module Name      : strpkb.sql
--       Date into SCCS   : 06/09/29 09:09:01
--       Date fetched Out : 07/06/15 08:50:09
--       SCCS Version     : 1.2
--
--
-----------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
-----------------------------------------------------------------------------
SET echo OFF
SET term OFF
--
col run_file new_value run_file noprint
--

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
           '&terminator'||'pck'||'&terminator'||'strsplit.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
           '&terminator'||'pck'||'&terminator'||'strmerge.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
           '&terminator'||'pck'||'&terminator'||'strrepl.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
           '&terminator'||'pck'||'&terminator'||'strrecal.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
           '&terminator'||'pck'||'&terminator'||'strclose.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
           '&terminator'||'pck'||'&terminator'||'strpbi.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'strinit.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'strutils.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'strdisc.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'strsas.pkh' run_file
from dual
/
start '&run_file'
set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'strsas.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'strhier.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'strbci.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'str_sdo_util.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'str_sdo_util.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'str3020.pkw' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'str3086.pkw' run_file
from dual
/
start '&run_file'

--
--
-- New proc above here
--
SET term ON

