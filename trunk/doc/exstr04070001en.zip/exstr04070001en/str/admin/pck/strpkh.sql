-----------------------------------------------------------------------------
--
--   SCCS Identifiers :-
--
--       sccsid           : @(#)strpkh.sql	1.2 09/29/06
--       Module Name      : strpkh.sql
--       Date into SCCS   : 06/09/29 09:08:42
--       Date fetched Out : 07/06/15 08:50:10
--       SCCS Version     : 1.2
--
--
-----------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
-----------------------------------------------------------------------------
SET echo OFF
SET term OFF
--
col run_file new_value run_file noprint
--

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
           '&terminator'||'pck'||'&terminator'||'strsplit.pkh' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
           '&terminator'||'pck'||'&terminator'||'strmerge.pkh' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
           '&terminator'||'pck'||'&terminator'||'strrepl.pkh' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
           '&terminator'||'pck'||'&terminator'||'strrecal.pkh' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
           '&terminator'||'pck'||'&terminator'||'strclose.pkh' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
           '&terminator'||'pck'||'&terminator'||'strpbi.pkh' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'strinit.pkh' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'strutils.pkh' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'strdisc.pkh' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'strhier.pkh' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'strbci.pkh' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'str_sdo_util.pkh' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'str3020.pkh' run_file
from dual
/
start '&run_file'

set define on
select '&exor_base'||'str'||'&terminator'||'admin'||
	   '&terminator'||'pck'||'&terminator'||'str3086.pkh' run_file
from dual
/
start '&run_file'

--
--
-- New proc above here
--
SET term ON

