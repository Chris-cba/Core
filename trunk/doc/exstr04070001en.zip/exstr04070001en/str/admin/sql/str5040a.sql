REM   ******************************************************************
REM   *                                                                *
REM   *              	      Structures by Exor                       *
REM   *                                                                *
REM   *  Copyright C 1998 Exor Corporation Ltd.                        *
REM   *                                                                *
REM   *  All rights reserved                                           *
REM   *                                                                *
REM   *  This  material has  been provided  pursuant to  an agreement  *
REM   *  containing  restrictions  on its use.  The  material is also  *
REM   *  protected  by  copyright law.  No part  of this material may  *
REM   *  be copied   or distributed,  transmitted  or transcribed, in  *
REM   *  any form or  by any means, electronic, mechanical, magnetic,  *
REM   *  manual, or  otherwise, or disclosed to third parties without  *
REM   *  the express written permission of Exor Corporation Ltd.       *
REM   *                                                                *
REM   ******************************************************************
REM
REM
REM Author : Graham Anns
REM Module : STR5040A.SQL
REM Date   : 01-JUL-1998
REM Purpose: List of Structures with Named Attributes Report
REM
REM NOTES  : Based on Structures v1.7 STR5040.SQL
REM
REM
REM Change History:
REM Name/Date      Details
REM -------------- -------------------------------------------------
REM
REM
REM ************************************************************************
REM                                                                        *
REM CALLING MODULES : STR5040.fmx                                          *
REM                                                                        *
REM MODULES CALLED  :                                                      *
REM                                                                        *
REM COMMENTS        :                                                      *
REM                                                                        *
REM ------------------------------------------------------------------------

-----------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
-----------------------------------------------------------------------------

REM SCCS ID Keyword, do not remove
define sccsid = '@(#)str5040a.sql	1.1 04/18/01';

SET DOCUMENT ON;
SET VERIFY OFF;
SET FEEDBACK OFF;
SET HEADING OFF;
SET TERMOUT OFF;

REM  set up calls to other modules.


COLUMN title	          NEW_VALUE title	       NOPRINT;
COLUMN authority	  NEW_VALUE authority	       NOPRINT;
COLUMN username		  NEW_VALUE username	       NOPRINT;
COLUMN sql.pno		  FORMAT 999;
COLUMN tdate		  NEW_VALUE tdate 	       NOPRINT;
COLUMN spool		  NEW_VALUE spool	       NOPRINT;

SELECT to_char(sysdate,'DD-MON-YYYY') tdate
FROM   dual
/

SELECT username username
FROM   user_users
/

SELECT hau_name authority
FROM   hig_admin_units,
       hig_users
WHERE  hus_admin_unit = hau_admin_unit
       and hus_username = user
/

SELECT hmo_title title
FROM   hig_modules
WHERE  upper(hmo_module) = 'STR5040A'
AND    rownum=1;

SELECT higgrirp.get_module_spoolpath(&&1,user)||higgrirp.get_module_spoolfile(&&1) spool
FROM   dual;

REM ------------------------------------------------------------------------

REM Turn everything off again

SET FEEDBACK OFF;
SET HEADING OFF;
SET TERMOUT OFF;

set pagesize 43;
set linesize 125;


REM ------------------------------------------------------------------------
REM Read parameters from temporary table, populated by calling FORM
REM Note that arraysize is reduced from 20 to 10 because of the large
REM amount of data being retrieved

SET ARRAYSIZE 10;

COLUMN p1 NEW_VALUE p1
COLUMN p2 NEW_VALUE p2
COLUMN p3 NEW_VALUE p3
COLUMN p4 NEW_VALUE p4
COLUMN p5 NEW_VALUE p5
COLUMN p6 NEW_VALUE p6
COLUMN p7 NEW_VALUE p7
COLUMN p8 NEW_VALUE p8
COLUMN p9 NEW_VALUE p9

SELECT rep_p1 p1,
       rep_p2 p2,
       rep_p3 p3,
       rep_p4 p4,
       rep_p5 p5,
       rep_p6 p6,
       rep_p7 p7,
       rep_p8 p8,
       rep_p9 p9
FROM   report_params
WHERE  rep_sessionid = &&1
/

REM Delete from temporary table

DELETE report_params
WHERE  rep_sessionid = &&1
/

REM ---------------------------------------------------------------------------

REM Spool output to file
spool &spool

--SPOOL str5040;

REM set up report title

BREAK ON REPORT SKIP PAGE;
TTITLE LEFT   '&&username' -
       CENTER '&&authority' -
       RIGHT  '&&tdate' SKIP -
       LEFT   'STR5040' -
       CENTER '&&title' -
       RIGHT  'Page          0' SKIP 4

SELECT 'Selection criteria:
-------------------'||'
Structure Type:    '||'&&p1'||'
Item Type:         '||'&&p2'||'
Search Conditions: '||'&&p3'||'
                   '||'&&p4'||'
                   '||'&&p5'
FROM    DUAL
/

REM Dummy entry to force page throw!
TTITLE LEFT '' -
       RIGHT '' SKIP PAGE

select '' from dual
/

REM re-issue title command to start now at page one

BREAK ON REPORT SKIP PAGE;
TTITLE LEFT   '&&username' -
       CENTER '&&authority' -
       RIGHT  '&&tdate' SKIP -
       LEFT   'STR5040' -
       CENTER '&&title' -
       RIGHT  'Page ' sql.pno FORMAT 999 SKIP SKIP


REM --------------------------------------------------------------------------
REM Perform SQL Query

SET HEADING ON;

COLUMN  type        FORMAT a4  HEADING 'Str|Type'
COLUMN  name        FORMAT a25 HEADING 'Structure|Name'  WORD_WRAP
COLUMN  local_ref   FORMAT a15 HEADING 'Local Ref'       WORD_WRAP
COLUMN  item_type   FORMAT a4  HEADING 'Item|Type'
COLUMN  item_name   FORMAT a25 HEADING 'Item Name'       WORD_WRAP
COLUMN  attribute   FORMAT a19 HEADING 'Attribute'       WORD_WRAP
COLUMN  value       FORMAT a20 HEADING 'Value'           WORD_WRAP

BREAK ON type SKIP 0-
      ON name SKIP 0-
      ON local_ref SKIP 0-
      ON item_type SKIP 0-
      ON item_name SKIP 0;

SELECT vti.top_sit_id    type,
       vti.top_local_ref local_ref,
       vti.top_str_name  name,
       vti.item_sit_id   item_type,
       vti.item_str_name item_name,
       sat.sat_name      attribute,
       sia.sia_value     value
FROM   v_top_items       vti,
       str_item_attr     sia,
       str_attr_types    sat
WHERE  vti.item_str_id = sia.sia_str_id
AND    sia.sia_sat_id  = sat.sat_id
&p6 &p7 &p8 &p9
ORDER BY vti.top_sit_id,
         vti.top_local_ref,
         vti.top_str_name,
         vti.item_sit_id,
         vti.item_str_name
/

REM ---------------------------------------------------------------------------
REM Tidy up, and exit program

SPOOL OFF;

update gri_report_runs
set grr_end_date = sysdate,
grr_error_no = 0,
grr_error_descr = 'Normal Successful Completion'
where grr_job_id = &&1;


CLEAR BREAKS;
BTITLE OFF;
TTITLE OFF;
SET NEWPAGE 1;
EXIT;

