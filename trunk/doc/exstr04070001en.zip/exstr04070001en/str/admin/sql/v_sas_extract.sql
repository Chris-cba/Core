CREATE OR REPLACE VIEW v_sas_extract AS
SELECT
--
--   SCCS Identifiers :-
--
--       sccsid           : @(#)v_sas_extract.sql	1.3 06/10/02
--       Module Name      : v_sas_extract.sql
--       Date into SCCS   : 02/06/10 14:48:17
--       Date fetched Out : 07/06/15 08:52:26
--       SCCS Version     : 1.3
--
--
-- MRWA view V_SAS_EXTRACT.
--
-- Author : Mike Huitson
-- 04-Oct-01: JC - amended to suit new specification from MRWA
-- 02-APR-02: JC - corrected number format for DECK_AREA
--     "    :     ,now uses STR_ITEMS view to exclude end-dated structures
--     "    :     ,
-- 22-MAY-02: JM - SUBSTR on character columns
--
-----------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
-----------------------------------------------------------------------------
--
       str_name str_no
      ,SUBSTR(strsas.get_route_no(NVL(rin_rse_he_id,0)),1,30) route_no
      ,strsas.get_slk           (NVL(rin_rse_he_id,0),NVL(rin_st_chain,0)) slk
      ,SUBSTR(strsas.get_attr_value(str_id,'TBBS',str_sit_id),1,2) status
      ,str_sit_id str_type
      ,SUBSTR(strsas.get_attr_value (str_id,'CUTY',str_sit_id),1,2) culv_type
      ,DECODE(str_sit_id
             ,'CULV',strsas.get_attr_number(str_id,'CUNB',str_sit_id)
             ,strsas.get_no_of_spans(str_id)
             ) spans_barrels
      ,strsas.get_attr_number   (str_id
                                ,DECODE(str_sit_id,'CULV','CUBL','TBTL')
                                ,str_sit_id
                                ) LENGTH
      ,strsas.get_attr_number   (str_id
                                ,DECODE(str_sit_id,'CULV','CUWI','TBTW')
                                ,str_sit_id
                                ) width
      ,SUBSTR(strsas.get_attr_value(str_id
                                   ,DECODE(str_sit_id
                                          ,'TMBR','TBSP'
                                          ,'THBR','THST'
                                          ,'STBR','STST'
                                          ,'SCBR','SCSP'
                                          ,'RCBR','RCSP'
                                          ,'PCSP'
                                          )
                                   ,str_sit_id)
             ,1,2) superstructure
      ,SUBSTR(strsas.get_attr_value(str_id,'TBCO',str_sit_id),1,1) conc_overlay
      ,SUBSTR(strsas.get_attr_date_val (str_id,'TBDB',str_sit_id),1,8) date_built
      ,SUBSTR(strsas.get_attr_value(str_id,'CUMT',str_sit_id),1,3) culv_material
      ,strsas.get_attr_number   (str_id,'CUVS',str_sit_id) culv_vert_size
      ,strsas.get_attr_number   (str_id,'CUHS',str_sit_id) culv_hori_size
      ,strsas.get_attr_number   (str_id,'CUDI',str_sit_id) culv_diameter
      ,SUBSTR(strsas.get_region_no(str_admin_unit),1,10) region_no
      ,SUBSTR(strsas.get_lga_no(str_admin_unit),1,10) lga_no
      ,SUBSTR(strsas.get_attr_value(str_id
                                   ,DECODE(str_sit_id
                                          ,'TUNL','TUPF'
                                          ,'SIGA','SIFU'
                                          ,'TBPF'
                                          )
                                   ,str_sit_id
                                   )
             ,1,2) primary_function
      ,SUBSTR(strsas.get_region_name(str_admin_unit),1,40) region_name
      ,SUBSTR(strsas.get_lga_name(str_admin_unit),1,40) lga_name
      ,SUBSTR(strsas.get_inv_item(NVL(rin_rse_he_id,0)
                                 ,NVL(rin_st_chain,0)
                                 ,'CWTH'
                                 ,'IIT_COMMONWEALTH_CLASS'  -- 'IIT_CHR_ATTRIB26'
                                 )
             ,1,2) commonwealth_class
      ,strsas.get_attr_number   (str_id
                                ,'TBWK'
                                ,str_sit_id
                                ) width_between_kerbs
      ,SUBSTR(strsas.get_design_value(str_id,'DILO'),1,8) design_load_1
      ,strsas.get_min_rating    (str_id,'RATA') tandem_axel_rating
      ,strsas.get_min_rating    (str_id,'RATR') triple_axel_rating
      ,strsas.get_min_rating    (str_id,'RAQA') quad_ax_rating
      ,strsas.get_attr_number   (str_id,'TBT4',str_sit_id) t44_rating
      ,strsas.get_attr_number   (str_id,'TBLL',str_sit_id) gross_load_limit
      ,LTRIM(TO_CHAR(NVL(strsas.get_attr_number(str_id,DECODE(str_sit_id,'CULV','CUBL','TBTL'),str_sit_id),0)
          * NVL(strsas.get_attr_number(str_id,'TBWK',str_sit_id),0),'00000.00'),' ') deck_area
      ,strsas.get_max_span_length(str_id,'SNLE') max_span_length
      ,strsas.get_min_rating    (str_id,'RAMT') min_truck_rating
      ,SUBSTR(strsas.get_attr_value(str_id
                                   ,DECODE(str_sit_id
                                          ,'TUNL','TUSF'
                                          ,'TBSF'
                                          )
                                   ,str_sit_id
                                   )
             ,1,2) secondary_function
      ,SUBSTR(strsas.get_attr_date_val(str_id,'TBCD',str_sit_id),1,8) brid_conc_overlay_date
      ,SUBSTR(strsas.get_attr_value(str_id,'TBXN',str_sit_id),1,30) crossing_name
      ,strsas.get_min_rating    (str_id,'RA48') axel_484q_rating
      ,SUBSTR(strsas.get_route_name(NVL(rin_rse_he_id,0)),1,80) route_name
      ,SUBSTR(strsas.get_attr_value(str_id,'TBO1',str_sit_id),1,2) owner_1
      ,SUBSTR(strsas.get_attr_value(str_id,'TBO2',str_sit_id),1,2) owner_2
      ,strsas.get_attr_number   (str_id,'TBMH',str_sit_id) max_headroom
      ,SUBSTR(strsas.get_attr_date_val(str_id,'TBLD',str_sit_id),1,8) load_limit_date
      ,SUBSTR(strsas.get_attr_date_val(str_id,'TBRD',str_sit_id),1,8) rating_date
      ,SUBSTR(strsas.get_design_value(str_id,'DIDA'),1,8) design_date
      ,strsas.get_attr_number   (str_id,'TBMS',str_sit_id) ms1600_rating
      ,strsas.get_min_rating    (str_id,'RAH1') hlp320_rating
      ,strsas.get_min_rating    (str_id,'RAH2') hlp400_rating
      ,strsas.get_attr_number   (str_id,'TBPL',str_sit_id) pedstrn_loading
      ,strsas.get_min_rating    (str_id,'RASV') serv_veh_rating
 FROM  ROAD_INTERSECTIONS
      ,STR_ITEMS
 WHERE rin_primary     = 'Y'
  AND  str_id          = rin_str_id
  AND  str_parent_id+0 = 0
  AND  str_id          > 0
  AND  nm3net.get_nt_type(rin_rse_he_id) IN ('MDAT','LDAT','ZDAT')
/
