--
define sccsid = '%W% %G%'
-------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
-----------------------------------------------------------------------------
--
--      It should be executed during upgrades and new installations.
--
------------------------------------------------------------------------
--
--SET echo OFF
--
COL run_file new_value run_file noprint
--
SET define ON
SELECT '&exor_base'||'str'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'rin_instead_i_u_d_trg.trg' run_file
FROM dual
/
START '&run_file'
--
SET define ON
SELECT '&exor_base'||'str'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'str_instead_i_u_trg.trg' run_file
FROM dual
/
START '&run_file'
--
SET define ON
SELECT '&exor_base'||'str'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'sih_b_i_u_trg.trg' run_file
FROM dual
/
START '&run_file'
--
SET define ON
SELECT '&exor_base'||'str'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'str_hier_a_stm_trg.trg' run_file
FROM dual
/
START '&run_file'
--
SET define ON
SELECT '&exor_base'||'str'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'str_hier_b_i_trg.trg' run_file
FROM dual
/
START '&run_file'
--
SET define ON
SELECT '&exor_base'||'str'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'str_hier_b_stm_trg.trg' run_file
FROM dual
/
START '&run_file'
--
