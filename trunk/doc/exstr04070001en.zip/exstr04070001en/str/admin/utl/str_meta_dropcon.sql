-----------------------------------------------------------------------------
--
--   SCCS Identifiers :-
--
--       sccsid           : @(#)str_meta_dropcon.sql	1.1 05/07/04
--       Module Name      : str_meta_dropcon.sql
--       Date into SCCS   : 04/05/07 15:14:25
--       Date fetched Out : 07/06/15 08:53:30
--       SCCS Version     : 1.1
--
-----------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
-----------------------------------------------------------------------------


set pagesize 10000 linesize 132 term off feed off head off echo off

spool strdropcon.sql
SELECT 'spool strdropcon.log'
FROM   dual
/
select     'PROMPT Dropping '||decode(constraint_type,'R','Foreign Constraint ','U','Unique ','P','Primary Key ','C','Check ',constraint_type||' ')||constraint_name||' on table '||table_name
          ,'ALTER TABLE '||table_name||' DROP CONSTRAINT '|| constraint_name||' CASCADE'||chr(10)||'/'
from   user_constraints
where    (
            table_name like 'STR_%')
    or table_name like ('TEMP_STR%') 
    or table_name like ('OBSTRUCTION%') 
    or table_name like ('ROAD_INTERSECTIONS') 
         )
/*and  ( 
            (constraint_type != 'C') 
       or   (constraint_type = 'C' and constraint_name like 'WOR_CK%') 
       or   (constraint_type = 'C' and constraint_name like 'ACC%')
      )         */
order by decode(constraint_type,'R',1,'U',2,'P',3,4)
/
SELECT 'spool off'
FROM   dual
/
spool off
set pagesize 30 linesize 80 term on feed on head on 

Prompt Completed
Prompt Created sql script accdropcon.sql
Prompt

















