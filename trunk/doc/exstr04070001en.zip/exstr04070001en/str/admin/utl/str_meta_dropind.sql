-----------------------------------------------------------------------------
--
--   SCCS Identifiers :-
--
--       sccsid           : @(#)str_meta_dropind.sql	1.1 05/07/04
--       Module Name      : str_meta_dropind.sql
--       Date into SCCS   : 04/05/07 15:31:51
--       Date fetched Out : 07/06/15 08:53:30
--       SCCS Version     : 1.1
--
-----------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
-----------------------------------------------------------------------------

set pagesize 10000 linesize 132 term off feed off head off echo off

spool strdropind.sql
SELECT 'spool strdropind.log'
FROM   dual
/
select  'PROMPT Dropping index '||index_name||' on table '||table_name
      , 'DROP INDEX '|| index_name||chr(10)||'/'
from   user_indexes
where    (
            table_name like 'STR_%')
    or table_name like ('TEMP_STR%') 
    or table_name like ('OBSTRUCTION%') 
    or table_name like ('ROAD_INTERSECTIONS')            
         )
ORDER BY table_name
/
SELECT 'spool off'
FROM   dual
/
spool off
set pagesize 30 linesize 80 term on feed on head on 

Prompt Completed
Prompt Created sql script accdropind.sql
Prompt
