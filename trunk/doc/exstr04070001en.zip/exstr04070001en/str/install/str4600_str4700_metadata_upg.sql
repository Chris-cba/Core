------------------------------------------------------------------
-- str4600_str4700_metadata_upg.sql
------------------------------------------------------------------


------------------------------------------------------------------

--
--   PVCS Identifiers :-
--
--       PVCS id          : $Header:   //vm_nm3/archives/admin/pck/ecdm_lite_release_scripting.pkb-arc   1.13   Jan 21 2009 17:21:20   malexander  $
--       Module Name      : $Workfile:   ecdm_lite_release_scripting.pkb  $
--       Date into PVCS   : $Date:   Jan 21 2009 17:21:20  $
--       Date fetched Out : $Modtime:   Jan 21 2009 17:20:26  $
--       Version          : $Revision:   1.13  $
--
------------------------------------------------------------------
--	Copyright (c) exor corporation ltd, 2013

SET ECHO OFF
SET LINESIZE 120
SET HEADING OFF
SET FEEDBACK OFF

DECLARE
  l_temp nm3type.max_varchar2;
BEGIN
  -- Dummy call to HIG to instantiate it
  l_temp := hig.get_version;
  l_temp := nm_debug.get_version;
EXCEPTION
  WHEN others
   THEN
 Null;
END;
/

BEGIN
  nm_debug.debug_off;
END;
/

------------------------------------------------------------------


------------------------------------------------------------------

Commit;
------------------------------------------------------------------



------------------------------------------------------------------
-- end of script 
------------------------------------------------------------------

