------------------------------------------------------------------
--
--   PVCS Identifiers :-
--
--       PVCS id          : $Header:   //vm_latest/archives/str/install/str_install.sql-arc   2.16   Dec 10 2013 16:28:22   Emil.Yohanov  $
--       Module Name      : $Workfile:   str_install.sql  $
--       Date into PVCS   : $Date:   Dec 10 2013 16:28:22  $
--       Date fetched Out : $Modtime:   Dec 10 2013 16:27:56  $
--       Version          : $Revision:   2.16  $
--
------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
------------------------------------------------------------------
--
set echo off
set linesize 120
set heading off
set feedback off
--
---------------------------------------------------------------------------------------------------
--                             ****************** LOG FILE *******************
-- Grab date/time to append to log file names this is standard to all upgrade/install scripts
--
undefine log_extension
col         log_extension new_value log_extension noprint
set term off
select  TO_CHAR(sysdate,'DDMONYYYY_HH24MISS')||'.LOG' log_extension from dual
/
set term on

define logfile1='str_install_1_&log_extension'
define logfile2='str_install_2_&log_extension'
spool &logfile1
--
---------------------------------------------------------------------------------------------------
--                                     ********** CHECKS  ***********
select 'Installation Date ' || to_char(sysdate, 'DD-MON-YYYY HH24:MI:SS') from dual;

SELECT 'Install Running on ' ||LOWER(USER||'@'||instance_name||'.'||host_name)||' - DB ver : '||version
FROM v$instance;

SELECT 'Current version of '||hpr_product||' ' ||hpr_version
FROM hig_products
WHERE hpr_product IN ('HIG','NET');

WHENEVER SQLERROR EXIT
--
-- Check that the user isn't sys or system
--
BEGIN
   --
      IF USER IN ('SYS','SYSTEM')
       THEN
         RAISE_APPLICATION_ERROR(-20000,'You cannot install this product as ' || USER);
      END IF;
END;
/

-- Check that the STR has not already been installed
BEGIN
   --
   FOR v_recs IN (SELECT hpr_version
                  FROM user_tables
                      ,hig_products
                  WHERE hpr_product = 'STR'
                  AND   table_name = 'STR_DEFECT_CODES') LOOP

               RAISE_APPLICATION_ERROR(-20000,'STR version '||v_recs.hpr_version||' already installed.');

   END LOOP;
END;
/

--
-- Check that HIG has been installed @ v4.5.0.0, as STR is dependent this
--
BEGIN
 hig2.product_exists_at_version (p_product        => 'HIG'
                                ,p_VERSION        => '4.7.0.0'
                                );
END;
/

WHENEVER SQLERROR CONTINUE
--
---------------------------------------------------------------------------------------------------
--                    ********************* TABLES *************************
SET TERM ON
Prompt Tables...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'install'||
        '&terminator'||'str.tab' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                    ********************* SEQUENCES *************************
SET TERM ON
Prompt Sequences...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'install'||
        '&terminator'||'str.sqs' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                    ********************* CONSTRAINTS *************************
SET TERM ON
Prompt Constraints...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'install'||
        '&terminator'||'str.con' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                    ********************* INDEXES *************************
SET TERM ON
Prompt Indexes...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'install'||
        '&terminator'||'str.ind' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                    ********************* VIEWS *************************
SET TERM ON
Prompt Views...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'install'||
        '&terminator'||'strviews' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
--
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'install'||
        '&terminator'||'str.vw' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                    ********************* TRIGGERS *************************
SET TERM ON
Prompt Constraints...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'admin'||
       '&terminator'||'trg'||'&terminator'||'strtrg.sql' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                    ********************* PACKAGES *************************
SET TERM ON
Prompt Packages...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'admin'||
        '&terminator'||'pck'||'&terminator'||'strpkh.sql' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
--
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'admin'||
        '&terminator'||'pck'||'&terminator'||'strpkb.sql' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                    ********************* TRIGGERS *************************
SET TERM ON
Prompt Triggers...
SET TERM OFF
SET DEFINE ON
SELECT '&exor_base'||'str'||'&terminator'||'admin'||
'&terminator'||'trg'||'&terminator'||'strtrg.sql' run_file
FROM dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                        ****************   COMPILE SCHEMA   *******************
SET TERM ON
Prompt Creating Compiling Schema Script...
SET TERM OFF
SPOOL OFF

SET DEFINE ON
SELECT '&exor_base'||'nm3'||'&terminator'||'admin'||
'&terminator'||'utl'||'&terminator'||'compile_schema.sql' run_file
FROM dual
/
START '&run_file'

spool &logfile2

--get some db info
select 'Install Date ' || to_char(sysdate, 'DD-MON-YYYY HH24:MI:SS') from dual;
SELECT 'Install Running on ' ||LOWER(username||'@'||instance_name||'.'||host_name)||' - DB ver : '||version
FROM v$instance
    ,user_users;

START compile_all.sql
--
---------------------------------------------------------------------------------------------------
--                    ********************* META-DATA *************************
SET TERM ON
Prompt Meta-Data...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'install'||
        '&terminator'||'strdata_install.sql' run_file
from dual
/
SET FEEDBACK ON
start &&run_file
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                        ****************   SYNONYMS   *******************
SET TERM ON
Prompt Creating Synonyms That Do Not Exist...
SET TERM OFF
EXECUTE nm3ddl.refresh_all_synonyms;
--
---------------------------------------------------------------------------------------------------
--                        ****************   ROLES  *******************
SET TERM ON
prompt Roles...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'install'||
        '&terminator'||'strroles' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
--
SET TERM ON
Prompt Updating HIG_USER_ROLES...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'nm3'||'&terminator'||'install'||
        '&terminator'||'hig_user_roles.sql' run_file
from dual
/
SET FEEDBACK ON
start &&run_file
SET FEEDBACK OFF
--
---------------------------------------------------------------------------------------------------
--                        ****************   VERSION NUMBER   *******************
SET TERM ON
Prompt Setting The Version Number...
SET TERM OFF
BEGIN
      hig2.upgrade('STR','str_install.sql','Installed','4.7.0.0');
END;
/
COMMIT;
SELECT 'Product installed at version '||hpr_product||' ' ||hpr_version details
FROM hig_products
WHERE hpr_product IN ('STR');
--
--
spool off
exit











