-----------------------------------------------------------------------------
--
--   PVCS Identifiers :-
--
--       PVCS id          : $Header:$
--       Module Name      : $Workfile:$
--       Date into PVCS   : $Date:$
--       Date fetched Out : $Modtime:$
--       Version          : $Revision:$
--       Table Owner      : STR_METADATA
--       Generation Date  : 10-DEC-2013 16:49
--
--   Product metadata script
--   As at Release 4.7.0.0
--
--   Copyright (c) exor corporation ltd, 2013
--
--   TABLES PROCESSED
--   ================
--   DOC_GATEWAYS
--   DOC_GATE_SYNS
--   GRI_MODULES
--   GRI_PARAMS
--   GRI_MODULE_PARAMS
--   GRI_PARAM_DEPENDENCIES
--   GRI_PARAM_LOOKUP
--   HIG_ERRORS
--
-----------------------------------------------------------------------------


set define off;
set feedback off;

---------------------------------
-- START OF GENERATED METADATA --
---------------------------------


----------------------------------------------------------------------------------------
-- DOC_GATEWAYS
--
-- select * from str_metadata.doc_gateways
-- order by dgt_table_name
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT doc_gateways
SET TERM OFF

INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'OBSTRUCTIONS'
       ,'Structure Obstructions'
       ,'OBS_ID'
       ,'RPAD(STR_NAME,30)||'' ''||RPAD(RSE_AGENCY||RSE_LINKCODE||'' ''||RSE_SECT_NO,16)||'' ''||RPAD(OBT_NAME,6)||'' ''||LPAD(TO_CHAR(OBS_LIMIT),6)||'' ''||RPAD( OBT_UNITS,6)'
       ,'OBSTRUCTIONS ,OBSTRUCTION_TYPES ,ROAD_INTERSECTIONS ,ROAD_SEGMENTS ,STR_ITEMS_ALL'
       ,'RIN_STR_ID = STR_ID AND RIN_RSE_HE_ID = RSE_HE_ID AND OBS_RIN_ID = RIN_ID AND OBS_OBT_ID = OBT_ID'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'OBSTRUCTIONS');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'ROAD_INTERSECTIONS'
       ,'Road Intersections'
       ,'RIN_ID'
       ,'RPAD(STR_NAME,30)||'' ''||RPAD(RSE_AGENCY||RSE_LINKCODE||'' ''||RSE_SECT_NO,16)||'' ''||DECODE(RIN_PRIMARY,''Y'',''PRIMARY'',''       '')||'' ''||RSE_DESCR'
       ,'ROAD_INTERSECTIONS ,ROAD_SEGMENTS ,STR_ITEMS_ALL'
       ,'ROAD_INTERSECTIONS.RIN_STR_ID = STR_ITEMS_ALL.STR_ID AND ROAD_INTERSECTIONS.RIN_RSE_HE_ID = ROAD_SEGMENTS.RSE_HE_ID'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'ROAD_INTERSECTIONS');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'STR_ATTR_DOMAIN'
       ,'Structure Attribute Domains'
       ,'SAD_ID'
       ,'SAD_ID'
       ,'STR_ATTR_DOMAIN'
       ,''
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'STR_ATTR_DOMAIN');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'STR_ATTR_TYPES'
       ,'Structure Attribute Types'
       ,'SAT_ID'
       ,'SAT_NAME'
       ,'STR_ATTR_TYPES'
       ,''
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'STR_ATTR_TYPES');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'STR_EQPT'
       ,'Structure Equipment'
       ,'SEQ_ID'
       ,'SEQ_NAME'
       ,'STR_EQPT'
       ,''
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'STR_EQPT');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'STR_INSP'
       ,'Structure Inspections'
       ,'SIP_ID'
       ,'RPAD(STR_ITEMS_ALL.STR_NAME,30)||'' ''||NVL(STR_INSP.SIP_DATE_INSPECTED,STR_INSP.SIP_DATE_SCHEDULED)||'' ''||DECODE(STR_INSP.SIP_DATE_INSPECTED,NULL,''SCHEDULED'',''INSPECTED'')||'' ''||STR_INSP_TYPES.SNT_NAME'
       ,'STR_INSP, STR_ITEMS_ALL, STR_INSP_TYPES'
       ,'STR_INSP_TYPES.SNT_ID = STR_INSP.SIP_SNT_ID AND STR_ITEMS_ALL.STR_ID = STR_INSP.SIP_STR_ID'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'STR_INSP');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'STR_INSP_CYCLES'
       ,'Structure Inspection Cycles'
       ,'SIC_ID'
       ,'SIC_NAME'
       ,'STR_INSP_CYCLES'
       ,''
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'STR_INSP_CYCLES');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'STR_INSP_LINES'
       ,'Structure Inspection Lines'
       ,'SIL_ID'
       ,'RPAD(STR_ITEMS_ALL.STR_NAME,30)||'' ''||RPAD(DECODE(STR_INSP_LINES.SIL_CMP_STR_ID ,NULL ,STR_INSP_LINES.SIL_CMP_SIT_ID ,STR_CMP_ALL.STR_NAME),30)||'' ''||NVL(STR_INSP.SIP_DATE_INSPECTED,STR_INSP.SIP_DATE_SCHEDULED)||'' ''||STR_INSP_TYPES.SNT_NAME'
       ,'STR_INSP_LINES ,STR_INSP ,STR_ITEMS_ALL ,STR_ITEMS_ALL STR_CMP_ALL ,STR_INSP_TYPES'
       ,'STR_INSP_LINES.SIL_SIP_ID = STR_INSP.SIP_ID AND STR_INSP_TYPES.SNT_ID = STR_INSP.SIP_SNT_ID AND STR_ITEMS_ALL.STR_ID = STR_INSP.SIP_STR_ID AND STR_CMP_ALL.STR_ID(+) = STR_INSP_LINES.SIL_CMP_STR_ID'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'STR_INSP_LINES');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'STR_INSP_SETS'
       ,'Structure Inspection Sets'
       ,'SIS_ID'
       ,'SIS_NAME'
       ,'STR_INSP_SETS'
       ,''
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'STR_INSP_SETS');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'STR_INSP_TYPES'
       ,'Structure Inspection Types'
       ,'SNT_ID'
       ,'SNT_NAME'
       ,'STR_INSP_TYPES'
       ,''
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'STR_INSP_TYPES');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'STR_ITEMS_ALL'
       ,'Structures'
       ,'STR_ID'
       ,'STR_NAME'
       ,'STR_ITEMS_ALL'
       ,''
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'STR_ITEMS_ALL');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'STR_ITEM_TYPES'
       ,'Structure Item Types'
       ,'SIT_ID'
       ,'SIT_NAME'
       ,'STR_ITEM_TYPES'
       ,''
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'STR_ITEM_TYPES');
--
INSERT INTO DOC_GATEWAYS
       (DGT_TABLE_NAME
       ,DGT_TABLE_DESCR
       ,DGT_PK_COL_NAME
       ,DGT_LOV_DESCR_LIST
       ,DGT_LOV_FROM_LIST
       ,DGT_LOV_JOIN_CONDITION
       ,DGT_EXPAND_MODULE
       ,DGT_START_DATE
       ,DGT_END_DATE
       )
SELECT 
        'STR_TEMPLATES'
       ,'Structure Templates'
       ,'STE_ID'
       ,'STE_NAME'
       ,'STR_TEMPLATES'
       ,''
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATEWAYS
                   WHERE DGT_TABLE_NAME = 'STR_TEMPLATES');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- DOC_GATE_SYNS
--
-- select * from str_metadata.doc_gate_syns
-- order by dgs_dgt_table_name
--         ,dgs_table_syn
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT doc_gate_syns
SET TERM OFF

INSERT INTO DOC_GATE_SYNS
       (DGS_DGT_TABLE_NAME
       ,DGS_TABLE_SYN
       )
SELECT 
        'STR_ITEMS_ALL'
       ,'STR_ITEMS' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM DOC_GATE_SYNS
                   WHERE DGS_DGT_TABLE_NAME = 'STR_ITEMS_ALL'
                    AND  DGS_TABLE_SYN = 'STR_ITEMS');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- GRI_MODULES
--
-- select * from str_metadata.gri_modules
-- order by grm_module
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT gri_modules
SET TERM OFF

INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR1001'
       ,'SVR'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR1001');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR1002'
       ,'SVR'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR1002');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR1003'
       ,'SVR'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR1003');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR1004'
       ,'SVR'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR1004');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5004'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,80
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5004');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5005'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5005');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5006'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5006');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5007'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5007');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5008'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5008');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5009'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5009');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5010'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5010');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5015'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5015');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5020'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5020');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5030'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5030');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5040A'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5040A');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5042'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5042');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5050'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5050');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5070'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5070');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5072'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5072');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5074'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5074');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5076'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5076');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5078'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5078');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5080'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5080');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5082'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5082');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR5084'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR5084');
--
INSERT INTO GRI_MODULES
       (GRM_MODULE
       ,GRM_MODULE_TYPE
       ,GRM_MODULE_PATH
       ,GRM_FILE_TYPE
       ,GRM_TAG_FLAG
       ,GRM_TAG_TABLE
       ,GRM_TAG_COLUMN
       ,GRM_TAG_WHERE
       ,GRM_LINESIZE
       ,GRM_PAGESIZE
       ,GRM_PRE_PROCESS
       )
SELECT 
        'STR7045'
       ,'N/A'
       ,'$PROD_HOME/bin'
       ,'lis'
       ,'N'
       ,''
       ,''
       ,''
       ,132
       ,66
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULES
                   WHERE GRM_MODULE = 'STR7045');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- GRI_PARAMS
--
-- select * from str_metadata.gri_params
-- order by gp_param
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT gri_params
SET TERM OFF

INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STRUCTURE_NAME'
       ,'CHAR'
       ,'STR_ITEMS_ALL'
       ,'STR_NAME'
       ,'STR_LOCAL_REF'
       ,'STR_NAME'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STRUCTURE_NAME');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STRUCTURE_REF'
       ,'CHAR'
       ,'STR_ITEMS_ALL'
       ,'STR_LOCAL_REF'
       ,'STR_NAME'
       ,'STR_LOCAL_REF'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STRUCTURE_REF');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STRUCTURE_TYPE'
       ,'CHAR'
       ,'STR_ITEM_TYPES'
       ,'SIT_ID'
       ,'SIT_NAME'
       ,'SIT_ID'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STRUCTURE_TYPE');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_ACTION'
       ,'CHAR'
       ,'STR_ATTR_LOOKUP'
       ,'SAL_VALUE'
       ,'SAL_MEANING'
       ,'SAL_VALUE'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_ACTION');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_CYCLE'
       ,'NUMBER'
       ,'STR_INSP_CYCLES'
       ,'SIC_ID'
       ,'SIC_NAME'
       ,'SIC_ID'
       ,'NUMBER'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_CYCLE');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_DOMAIN'
       ,'CHAR'
       ,'STR_ATTR_DOMAIN'
       ,'SAD_ID'
       ,'SAD_TITLE'
       ,'SAD_ID'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_DOMAIN');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_EQPT'
       ,'CHAR'
       ,'STR_EQPT'
       ,'SEQ_ID'
       ,'SEQ_NAME'
       ,'SEQ_ID'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_EQPT');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_EXTENT'
       ,'CHAR'
       ,'STR_ATTR_LOOKUP'
       ,'SAL_VALUE'
       ,'SAL_MEANING'
       ,'SAL_VALUE'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_EXTENT');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_EXTENT2'
       ,'CHAR'
       ,'STR_ATTR_LOOKUP'
       ,'SAL_VALUE'
       ,'SAL_MEANING'
       ,'SAL_VALUE'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_EXTENT2');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_EXTENT_VARIANCE'
       ,'NUMBER'
       ,''
       ,''
       ,''
       ,''
       ,'NUMBER'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_EXTENT_VARIANCE');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_INSP_BATCH'
       ,'NUMBER'
       ,'STR_INSP_BATCH'
       ,'SIB_ID'
       ,'TO_CHAR(SIB_DATE_CREATED,''DD-MON-YYYY'')'
       ,'SIB_ID'
       ,'NUMBER'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_INSP_BATCH');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_INSP_TYPE'
       ,'CHAR'
       ,'STR_INSP_TYPES'
       ,'SNT_ID'
       ,'SNT_NAME'
       ,'SNT_ID'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_INSP_TYPE');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_ITEM_TYPE'
       ,'CHAR'
       ,'STR_ITEM_TYPES'
       ,'SIT_ID'
       ,'SIT_NAME'
       ,'SIT_ID'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_ITEM_TYPE');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_OBS_LIMIT1'
       ,'NUMBER'
       ,'OBSTRUCTIONS'
       ,'OBS_LIMIT'
       ,''
       ,'OBS_LIMIT'
       ,'NUMBER'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_OBS_LIMIT1');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_OBS_LIMIT2'
       ,'NUMBER'
       ,'OBSTRUCTIONS'
       ,'OBS_LIMIT'
       ,''
       ,'OBS_LIMIT'
       ,'NUMBER'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_OBS_LIMIT2');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_OBS_LIMIT3'
       ,'NUMBER'
       ,'OBSTRUCTIONS'
       ,'OBS_LIMIT'
       ,''
       ,'OBS_LIMIT'
       ,'NUMBER'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_OBS_LIMIT3');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_OBS_LIMIT4'
       ,'NUMBER'
       ,'OBSTRUCTIONS'
       ,'OBS_LIMIT'
       ,''
       ,'OBS_LIMIT'
       ,'NUMBER'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_OBS_LIMIT4');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_OBS_TYPE'
       ,'CHAR'
       ,'OBSTRUCTION_TYPES'
       ,'OBT_ID'
       ,'OBT_NAME'
       ,'OBT_ID'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_OBS_TYPE');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_OBS_TYPE2'
       ,'CHAR'
       ,'OBSTRUCTION_TYPES'
       ,'OBT_ID'
       ,'OBT_NAME'
       ,'OBT_ID'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_OBS_TYPE2');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_OBS_TYPE3'
       ,'CHAR'
       ,'OBSTRUCTION_TYPES'
       ,'OBT_ID'
       ,'OBT_NAME'
       ,'OBT_ID'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_OBS_TYPE3');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_OBS_TYPE4'
       ,'CHAR'
       ,'OBSTRUCTION_TYPES'
       ,'OBT_ID'
       ,'OBT_NAME'
       ,'OBT_ID'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_OBS_TYPE4');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_PRIORITY'
       ,'CHAR'
       ,'STR_ATTR_LOOKUP'
       ,'SAL_VALUE'
       ,'SAL_MEANING'
       ,'SAL_VALUE'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_PRIORITY');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_SEVERITY'
       ,'CHAR'
       ,'STR_ATTR_LOOKUP'
       ,'SAL_VALUE'
       ,'SAL_MEANING'
       ,'SAL_VALUE'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_SEVERITY');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_SEVERITY2'
       ,'CHAR'
       ,'STR_ATTR_LOOKUP'
       ,'SAL_VALUE'
       ,'SAL_MEANING'
       ,'SAL_VALUE'
       ,'CHAR'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_SEVERITY2');
--
INSERT INTO GRI_PARAMS
       (GP_PARAM
       ,GP_PARAM_TYPE
       ,GP_TABLE
       ,GP_COLUMN
       ,GP_DESCR_COLUMN
       ,GP_SHOWN_COLUMN
       ,GP_SHOWN_TYPE
       ,GP_DESCR_TYPE
       ,GP_ORDER
       ,GP_CASE
       ,GP_GAZ_RESTRICTION
       )
SELECT 
        'STR_SEVERITY_VARIANCE'
       ,'NUMBER'
       ,''
       ,''
       ,''
       ,''
       ,'NUMBER'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAMS
                   WHERE GP_PARAM = 'STR_SEVERITY_VARIANCE');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- GRI_MODULE_PARAMS
--
-- select * from str_metadata.gri_module_params
-- order by gmp_module
--         ,gmp_param
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT gri_module_params
SET TERM OFF

INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR1001'
       ,'ANSWER'
       ,1
       ,'Continue ?'
       ,'Y'
       ,1
       ,'GPL_PARAM=''ANSWER'''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,'N'
       ,'N'
       ,'Do you wish to continue ?'
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR1001'
                    AND  GMP_PARAM = 'ANSWER');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR1002'
       ,'ANSWER'
       ,2
       ,'Use previous Inspection ?'
       ,'Y'
       ,1
       ,'GPL_PARAM=''ANSWER'''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,'N'
       ,'N'
       ,'Do you wish to use the results from the previous Inspection ?'
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR1002'
                    AND  GMP_PARAM = 'ANSWER');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR1002'
       ,'STR_INSP_BATCH'
       ,1
       ,'Batch Id'
       ,'Y'
       ,1
       ,'SIB_ID IN (SELECT DISTINCT SIP_SIB_ID FROM STR_INSP, STR_INSP_BATCH WHERE SIP_SIB_ID = SIB_ID AND SIB_DATE_DCD_GEN IS NULL)'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,'N'
       ,'N'
       ,'Enter Inspection Batch Id'
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR1002'
                    AND  GMP_PARAM = 'STR_INSP_BATCH');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR1003'
       ,'LOADER_FILE'
       ,1
       ,'Load File Path'
       ,'Y'
       ,1
       ,''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,'N'
       ,'N'
       ,'Enter pathname of load file'
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR1003'
                    AND  GMP_PARAM = 'LOADER_FILE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR1004'
       ,'LOADER_FILE'
       ,1
       ,'Load File Path'
       ,'Y'
       ,1
       ,''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,'N'
       ,'N'
       ,'Enter pathname of load file'
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR1004'
                    AND  GMP_PARAM = 'LOADER_FILE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5004'
       ,'STR_DOMAIN'
       ,1
       ,'Domain'
       ,'N'
       ,1
       ,'SAD_ID IN (SELECT SAD_ID FROM STR_ATTR_DOMAIN)'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5004'
                    AND  GMP_PARAM = 'STR_DOMAIN');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5010'
       ,'ADMIN_UNIT'
       ,1
       ,'Admin Unit'
       ,'N'
       ,1
       ,'(HAU_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE HAG_PARENT_ADMIN_UNIT IN (SELECT'||CHR(10)||'HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,'HIG_ADMIN_UNITS'
       ,'HAU_ADMIN_UNIT'
       ,'HAU_ADMIN_UNIT'||CHR(10)||'= (SELECT MAX(HUS_ADMIN_UNIT) FROM HIG_USERS WHERE HUS_USERNAME = USER)'
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5010'
                    AND  GMP_PARAM = 'ADMIN_UNIT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5010'
       ,'ROAD_ID'
       ,2
       ,'Road Id'
       ,'N'
       ,1
       ,'RSE_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR (HAG_PARENT_ADMIN_UNIT IN'||CHR(10)||'(SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'Y'
       ,'N'
       ,'road_id'
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5010'
                    AND  GMP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5010'
       ,'STRUCTURE_NAME'
       ,4
       ,'Structure Name'
       ,'N'
       ,1
       ,'STR_SIT_ID IN (SELECT SIT_ID FROM STR_ITEM_TYPES WHERE SIT_LEVEL = 1) AND'||CHR(10)||'STR_NAME IN'||CHR(10)||'(SELECT STR_NAME FROM STR_ITEMS_ALL WHERE STR_SIT_ID LIKE NVL(:STRUCTURE_TYPE,''%'') AND'||CHR(10)||'(STR_ID IN (SELECT RIN_STR_ID FROM ROAD_INTERSECTIONS WHERE RIN_RSE_HE_ID = :ROAD_ID) OR'||CHR(10)||':ROAD_ID IS NULL) AND'||CHR(10)||'((STR_ADMIN_UNIT IS NULL AND LENGTH(:ADMIN_UNIT) IS NULL) OR (STR_ADMIN_UNIT IN'||CHR(10)||'(SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE (HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT OR'||CHR(10)||'HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER))))))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5010'
                    AND  GMP_PARAM = 'STRUCTURE_NAME');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5010'
       ,'STRUCTURE_REF'
       ,5
       ,'Structure Ref.'
       ,'N'
       ,1
       ,'STR_SIT_ID IN (SELECT SIT_ID FROM STR_ITEM_TYPES WHERE SIT_LEVEL = 1) AND'||CHR(10)||'STR_LOCAL_REF IN'||CHR(10)||'(SELECT STR_LOCAL_REF FROM STR_ITEMS_ALL WHERE STR_SIT_ID LIKE NVL(:STRUCTURE_TYPE,''%'') AND'||CHR(10)||'(STR_ID IN (SELECT RIN_STR_ID FROM ROAD_INTERSECTIONS WHERE RIN_RSE_HE_ID = :ROAD_ID) OR'||CHR(10)||':ROAD_ID IS NULL) AND'||CHR(10)||'((STR_ADMIN_UNIT IS NULL AND LENGTH(:ADMIN_UNIT) IS NULL) OR (STR_ADMIN_UNIT IN'||CHR(10)||'(SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE (HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT OR'||CHR(10)||'HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER))))))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5010'
                    AND  GMP_PARAM = 'STRUCTURE_REF');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5010'
       ,'STRUCTURE_TYPE'
       ,3
       ,'Structure Type'
       ,'N'
       ,1
       ,'SIT_LEVEL = 1'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5010'
                    AND  GMP_PARAM = 'STRUCTURE_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5015'
       ,'ADMIN_UNIT'
       ,1
       ,'Admin Unit'
       ,'N'
       ,1
       ,'(HAU_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE HAG_PARENT_ADMIN_UNIT IN (SELECT'||CHR(10)||'HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,'HIG_ADMIN_UNITS'
       ,'HAU_ADMIN_UNIT'
       ,'HAU_ADMIN_UNIT'||CHR(10)||'= (SELECT MAX(HUS_ADMIN_UNIT) FROM HIG_USERS WHERE HUS_USERNAME = USER)'
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5015'
                    AND  GMP_PARAM = 'ADMIN_UNIT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5015'
       ,'FROM_DATE'
       ,7
       ,'From Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE AND :FROM_DATE <= SYSDATE) OR (:TO_DATE IS NULL AND :FROM_DATE <= SYSDATE))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5015'
                    AND  GMP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5015'
       ,'STRUCTURE_NAME'
       ,5
       ,'Structure Name'
       ,'N'
       ,1
       ,'STR_NAME IN'||CHR(10)||'(SELECT DISTINCT STR_NAME FROM STR_ITEMS_ALL, STR_INSP WHERE SIP_STR_ID = STR_ID AND SIP_SNT_ID LIKE NVL(:STR_INSP_TYPE,''%'')'||CHR(10)||'AND STR_SIT_ID LIKE NVL(:STRUCTURE_TYPE,''%'') AND'||CHR(10)||'((STR_ADMIN_UNIT IS NULL AND LENGTH(:ADMIN_UNIT) IS NULL) OR (STR_ADMIN_UNIT IN'||CHR(10)||'(SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE (HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT OR'||CHR(10)||'HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER))))))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5015'
                    AND  GMP_PARAM = 'STRUCTURE_NAME');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5015'
       ,'STRUCTURE_REF'
       ,6
       ,'Structure Ref.'
       ,'N'
       ,1
       ,'STR_LOCAL_REF IN'||CHR(10)||'(SELECT DISTINCT STR_LOCAL_REF FROM STR_ITEMS_ALL, STR_INSP WHERE SIP_STR_ID = STR_ID AND SIP_SNT_ID LIKE'||CHR(10)||'NVL(:STR_INSP_TYPE,''%'') AND STR_SIT_ID LIKE NVL(:STRUCTURE_TYPE,''%'') AND'||CHR(10)||'((STR_ADMIN_UNIT IS NULL AND LENGTH(:ADMIN_UNIT) IS NULL) OR (STR_ADMIN_UNIT IN'||CHR(10)||'(SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE (HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT OR'||CHR(10)||'HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER))))))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5015'
                    AND  GMP_PARAM = 'STRUCTURE_REF');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5015'
       ,'STRUCTURE_TYPE'
       ,4
       ,'Structure Type'
       ,'N'
       ,1
       ,'SIT_LEVEL = 1'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5015'
                    AND  GMP_PARAM = 'STRUCTURE_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5015'
       ,'STR_INSP_BATCH'
       ,2
       ,'Inspection Batch'
       ,'N'
       ,1
       ,'SIB_ID IN (SELECT DISTINCT SIP_SIB_ID FROM STR_INSP,STR_ITEMS_ALL'||CHR(10)||'WHERE SIP_STR_ID = STR_ID AND ((STR_ADMIN_UNIT IS NULL AND LENGTH(:ADMIN_UNIT) IS NULL) OR STR_ADMIN_UNIT IN'||CHR(10)||'(SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE (HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5015'
                    AND  GMP_PARAM = 'STR_INSP_BATCH');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5015'
       ,'STR_INSP_TYPE'
       ,3
       ,'Inspection Type'
       ,'N'
       ,1
       ,''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5015'
                    AND  GMP_PARAM = 'STR_INSP_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5015'
       ,'TO_DATE'
       ,8
       ,'To Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE) OR (:FROM_DATE IS NULL))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5015'
                    AND  GMP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5020'
       ,'ADMIN_UNIT'
       ,1
       ,'Admin Unit'
       ,'N'
       ,1
       ,'(HAU_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,'HIG_ADMIN_UNITS'
       ,'HAU_ADMIN_UNIT'
       ,'HAU_ADMIN_UNIT = (SELECT MAX(HUS_ADMIN_UNIT) FROM HIG_USERS WHERE HUS_USERNAME = USER)'
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5020'
                    AND  GMP_PARAM = 'ADMIN_UNIT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5020'
       ,'FROM_DATE'
       ,4
       ,'From Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE AND :FROM_DATE <= SYSDATE) OR (:TO_DATE IS NULL AND :FROM_DATE <= SYSDATE))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5020'
                    AND  GMP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5020'
       ,'ROAD_ID'
       ,2
       ,'Road Id'
       ,'N'
       ,1
       ,'RSE_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR (HAG_PARENT_ADMIN_UNIT IN'||CHR(10)||'(SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'Y'
       ,'N'
       ,'road_id'
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5020'
                    AND  GMP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5020'
       ,'STR_OBS_TYPE'
       ,3
       ,'Obstruction Type'
       ,'N'
       ,1
       ,'OBT_ID IN (SELECT OBT_ID FROM OBSTRUCTION_TYPES)'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5020'
                    AND  GMP_PARAM = 'STR_OBS_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5020'
       ,'TO_DATE'
       ,5
       ,'To Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE AND :TO_DATE <= SYSDATE) OR (:FROM_DATE IS NULL AND :TO_DATE <= SYSDATE))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5020'
                    AND  GMP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5030'
       ,'ADMIN_UNIT'
       ,1
       ,'Admin Unit'
       ,'N'
       ,1
       ,'(HAU_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,'HIG_ADMIN_UNITS'
       ,'HAU_ADMIN_UNIT'
       ,'HAU_ADMIN_UNIT = (SELECT MAX(HUS_ADMIN_UNIT) FROM HIG_USERS WHERE HUS_USERNAME = USER)'
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5030'
                    AND  GMP_PARAM = 'ADMIN_UNIT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5030'
       ,'ROAD_ID'
       ,2
       ,'Road Id'
       ,'N'
       ,1
       ,'RSE_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR (HAG_PARENT_ADMIN_UNIT IN'||CHR(10)||'(SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'Y'
       ,'N'
       ,'road_id'
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5030'
                    AND  GMP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5030'
       ,'STR_OBS_LIMIT1'
       ,7
       ,'Obstruction Limit 1'
       ,'N'
       ,1
       ,'OBS_ID IN (SELECT DISTINCT OBS_ID FROM OBSTRUCTIONS, ROAD_INTERSECTIONS, STR_ITEMS_ALL WHERE OBS_RIN_ID = RIN_ID AND RIN_STR_ID = STR_ID AND (OBS_OBT_ID = :STR_OBS_TYPE OR :STR_OBS_TYPE IS NULL) AND ((STR_ADMIN_UNIT IS NULL AND LENGTH(:ADMIN_UNIT) IS NULL) OR STR_ADMIN_UNIT IN'||CHR(10)||'(SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE (HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5030'
                    AND  GMP_PARAM = 'STR_OBS_LIMIT1');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5030'
       ,'STR_OBS_LIMIT2'
       ,8
       ,'Obstruction Limit 2'
       ,'N'
       ,1
       ,'OBS_ID IN (SELECT DISTINCT OBS_ID FROM OBSTRUCTIONS, ROAD_INTERSECTIONS, STR_ITEMS_ALL WHERE OBS_RIN_ID = RIN_ID AND RIN_STR_ID = STR_ID AND (OBS_OBT_ID = :STR_OBS_TYPE2 OR :STR_OBS_TYPE2 IS NULL) AND ((STR_ADMIN_UNIT IS NULL AND LENGTH(:ADMIN_UNIT) IS NULL) OR STR_ADMIN_UNIT IN'||CHR(10)||'(SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE (HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5030'
                    AND  GMP_PARAM = 'STR_OBS_LIMIT2');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5030'
       ,'STR_OBS_LIMIT3'
       ,9
       ,'Obstruction Limit 3'
       ,'N'
       ,1
       ,'OBS_ID IN (SELECT DISTINCT OBS_ID FROM OBSTRUCTIONS, ROAD_INTERSECTIONS, STR_ITEMS_ALL WHERE OBS_RIN_ID = RIN_ID AND RIN_STR_ID = STR_ID AND (OBS_OBT_ID = :STR_OBS_TYPE3 OR :STR_OBS_TYPE3 IS NULL) AND ((STR_ADMIN_UNIT IS NULL AND LENGTH(:ADMIN_UNIT) IS NULL) OR STR_ADMIN_UNIT IN'||CHR(10)||'(SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE (HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5030'
                    AND  GMP_PARAM = 'STR_OBS_LIMIT3');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5030'
       ,'STR_OBS_LIMIT4'
       ,10
       ,'Obstruction Limit 4'
       ,'N'
       ,1
       ,'OBS_ID IN (SELECT DISTINCT OBS_ID FROM OBSTRUCTIONS, ROAD_INTERSECTIONS, STR_ITEMS_ALL WHERE OBS_RIN_ID = RIN_ID AND RIN_STR_ID = STR_ID AND (OBS_OBT_ID = :STR_OBS_TYPE4 OR :STR_OBS_TYPE4 IS NULL) AND ((STR_ADMIN_UNIT IS NULL AND LENGTH(:ADMIN_UNIT) IS NULL) OR STR_ADMIN_UNIT IN'||CHR(10)||'(SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE (HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5030'
                    AND  GMP_PARAM = 'STR_OBS_LIMIT4');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5030'
       ,'STR_OBS_TYPE'
       ,3
       ,'Obstruction 1'
       ,'N'
       ,1
       ,'OBS_ID IN (SELECT DISTINCT OBS_ID FROM OBSTRUCTIONS, ROAD_INTERSECTIONS, STR_ITEMS_ALL WHERE OBS_RIN_ID = RIN_ID AND RIN_STR_ID = STR_ID AND (STR_ADMIN_UNIT IS NULL AND'||CHR(10)||'LENGTH(:ADMIN_UNIT) IS NULL) OR STR_ADMIN_UNIT IN'||CHR(10)||'(SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE (HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER))))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5030'
                    AND  GMP_PARAM = 'STR_OBS_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5030'
       ,'STR_OBS_TYPE2'
       ,4
       ,'Obstruction 2'
       ,'N'
       ,1
       ,'OBS_ID IN (SELECT DISTINCT OBS_ID FROM OBSTRUCTIONS, ROAD_INTERSECTIONS, STR_ITEMS_ALL WHERE OBS_RIN_ID = RIN_ID AND RIN_STR_ID = STR_ID AND (STR_ADMIN_UNIT IS NULL AND'||CHR(10)||'LENGTH(:ADMIN_UNIT) IS NULL) OR STR_ADMIN_UNIT IN'||CHR(10)||'(SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE (HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER))))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5030'
                    AND  GMP_PARAM = 'STR_OBS_TYPE2');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5030'
       ,'STR_OBS_TYPE3'
       ,5
       ,'Obstruction 3'
       ,'N'
       ,1
       ,'OBS_ID IN (SELECT DISTINCT OBS_ID FROM OBSTRUCTIONS, ROAD_INTERSECTIONS, STR_ITEMS_ALL WHERE OBS_RIN_ID = RIN_ID AND RIN_STR_ID = STR_ID AND (STR_ADMIN_UNIT IS NULL AND'||CHR(10)||'LENGTH(:ADMIN_UNIT) IS NULL) OR STR_ADMIN_UNIT IN'||CHR(10)||'(SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE (HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER))))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5030'
                    AND  GMP_PARAM = 'STR_OBS_TYPE3');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5030'
       ,'STR_OBS_TYPE4'
       ,6
       ,'Obstruction 4'
       ,'N'
       ,1
       ,'OBS_ID IN (SELECT DISTINCT OBS_ID FROM OBSTRUCTIONS, ROAD_INTERSECTIONS, STR_ITEMS_ALL WHERE OBS_RIN_ID = RIN_ID AND RIN_STR_ID = STR_ID AND (STR_ADMIN_UNIT IS NULL AND'||CHR(10)||'LENGTH(:ADMIN_UNIT) IS NULL) OR STR_ADMIN_UNIT IN'||CHR(10)||'(SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE (HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER))))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5030'
                    AND  GMP_PARAM = 'STR_OBS_TYPE4');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5042'
       ,'ADMIN_UNIT'
       ,1
       ,'Admin Unit'
       ,'N'
       ,1
       ,'(HAU_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,'HIG_ADMIN_UNITS'
       ,'HAU_ADMIN_UNIT'
       ,'HAU_ADMIN_UNIT = (SELECT MAX(HUS_ADMIN_UNIT) FROM HIG_USERS WHERE HUS_USERNAME = USER)'
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5042'
                    AND  GMP_PARAM = 'ADMIN_UNIT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5042'
       ,'ROAD_ID'
       ,2
       ,'Road Id'
       ,'N'
       ,1
       ,'RSE_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR (HAG_PARENT_ADMIN_UNIT IN'||CHR(10)||'(SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'Y'
       ,'N'
       ,'road_id'
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5042'
                    AND  GMP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5042'
       ,'STR_EQPT'
       ,3
       ,'Equipment required for Inspection'
       ,'N'
       ,1
       ,''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5042'
                    AND  GMP_PARAM = 'STR_EQPT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5050'
       ,'ADMIN_UNIT'
       ,1
       ,'Admin Unit'
       ,'N'
       ,1
       ,'(HAU_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,'HIG_ADMIN_UNITS'
       ,'HAU_ADMIN_UNIT'
       ,'HAU_ADMIN_UNIT = (SELECT MAX(HUS_ADMIN_UNIT) FROM HIG_USERS WHERE HUS_USERNAME = USER)'
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5050'
                    AND  GMP_PARAM = 'ADMIN_UNIT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5050'
       ,'ROAD_ID'
       ,2
       ,'Road Id'
       ,'N'
       ,1
       ,'RSE_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR (HAG_PARENT_ADMIN_UNIT IN'||CHR(10)||'(SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'Y'
       ,'N'
       ,'road_id'
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5050'
                    AND  GMP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5070'
       ,'ADMIN_UNIT'
       ,1
       ,'Admin Unit'
       ,'N'
       ,1
       ,'NAU_ADMIN_UNIT IN (SELECT ADMIN_UNIT FROM V_NM_USER_AU_MODES)'
       ,'N'
       ,''
       ,'HIG_ADMIN_UNITS'
       ,'HAU_ADMIN_UNIT'
       ,'HAU_ADMIN_UNIT = (SELECT MIN(NUA_ADMIN_UNIT) FROM NM_USER_AUS WHERE nua_user_id=To_Number(Sys_Context(''NM3CORE'',''USER_ID'')))'
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5070'
                    AND  GMP_PARAM = 'ADMIN_UNIT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5070'
       ,'ANSWER'
       ,7
       ,'Detailed? (Y/N)'
       ,'Y'
       ,1
       ,'GPL_PARAM = ''ANSWER'''
       ,'N'
       ,''
       ,'GRI_PARAM_LOOKUP'
       ,'GPL_VALUE'
       ,'GPL_VALUE = ''N'' AND GPL_PARAM = ''ANSWER'''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5070'
                    AND  GMP_PARAM = 'ANSWER');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5070'
       ,'FROM_DATE'
       ,5
       ,'From Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE) OR (:TO_DATE IS NULL))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5070'
                    AND  GMP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5070'
       ,'ROAD_ID'
       ,2
       ,'Road Id'
       ,'N'
       ,1
       ,'EXISTS (SELECT 1 FROM V_NM_USER_AU_MODES WHERE :P_ADMIN_UNIT = RSE_ADMIN_UNIT)'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'Y'
       ,'N'
       ,'road_id'
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5070'
                    AND  GMP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5070'
       ,'STRUCTURE_TYPE'
       ,3
       ,'Structure Type'
       ,'N'
       ,1
       ,'SIT_LEVEL = 1'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5070'
                    AND  GMP_PARAM = 'STRUCTURE_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5070'
       ,'STR_EQPT'
       ,8
       ,'Equipment required'
       ,'N'
       ,1
       ,':ANSWER = ''Y'''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5070'
                    AND  GMP_PARAM = 'STR_EQPT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5070'
       ,'STR_INSP_TYPE'
       ,4
       ,'Inspection Type'
       ,'N'
       ,1
       ,''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5070'
                    AND  GMP_PARAM = 'STR_INSP_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5070'
       ,'TO_DATE'
       ,6
       ,'To Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE) OR (:FROM_DATE IS NULL))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5070'
                    AND  GMP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5072'
       ,'ADMIN_UNIT'
       ,1
       ,'Admin Unit'
       ,'N'
       ,1
       ,'(HAU_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,'HIG_ADMIN_UNITS'
       ,'HAU_ADMIN_UNIT'
       ,'HAU_ADMIN_UNIT = (SELECT MAX(HUS_ADMIN_UNIT) FROM HIG_USERS WHERE HUS_USERNAME = USER)'
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5072'
                    AND  GMP_PARAM = 'ADMIN_UNIT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5072'
       ,'ANSWER'
       ,6
       ,'Detailed? (Y/N)'
       ,'Y'
       ,1
       ,'GPL_PARAM = ''ANSWER'''
       ,'N'
       ,''
       ,'GRI_PARAM_LOOKUP'
       ,'GPL_VALUE'
       ,'GPL_VALUE = ''N'' AND GPL_PARAM = ''ANSWER'''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5072'
                    AND  GMP_PARAM = 'ANSWER');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5072'
       ,'FROM_DATE'
       ,4
       ,'From Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE AND :FROM_DATE <= SYSDATE) OR (:TO_DATE IS NULL AND :FROM_DATE <= SYSDATE))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5072'
                    AND  GMP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5072'
       ,'STRUCTURE_TYPE'
       ,3
       ,'Structure Type'
       ,'N'
       ,1
       ,'SIT_LEVEL = 1'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5072'
                    AND  GMP_PARAM = 'STRUCTURE_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5072'
       ,'STR_INSP_BATCH'
       ,2
       ,'Inspection Batch'
       ,'N'
       ,1
       ,'SIB_ID IN (SELECT DISTINCT SIP_SIB_ID FROM STR_INSP,STR_ITEMS_ALL'||CHR(10)||'WHERE SIP_STR_ID = STR_ID AND ((STR_ADMIN_UNIT IS NULL AND LENGTH(:ADMIN_UNIT) IS NULL) OR STR_ADMIN_UNIT IN'||CHR(10)||'(SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE (HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5072'
                    AND  GMP_PARAM = 'STR_INSP_BATCH');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5072'
       ,'TO_DATE'
       ,5
       ,'To Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE AND :TO_DATE <= SYSDATE) OR (:FROM_DATE IS NULL AND :TO_DATE <= SYSDATE))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5072'
                    AND  GMP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5074'
       ,'ADMIN_UNIT'
       ,1
       ,'Admin Unit'
       ,'N'
       ,1
       ,'(HAU_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,'HIG_ADMIN_UNITS'
       ,'HAU_ADMIN_UNIT'
       ,'HAU_ADMIN_UNIT = (SELECT MAX(HUS_ADMIN_UNIT) FROM HIG_USERS WHERE HUS_USERNAME = USER)'
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5074'
                    AND  GMP_PARAM = 'ADMIN_UNIT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5074'
       ,'FROM_DATE'
       ,6
       ,'From Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE) OR (:TO_DATE IS NULL))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5074'
                    AND  GMP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5074'
       ,'ROAD_ID'
       ,2
       ,'Road Id'
       ,'N'
       ,1
       ,'RSE_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR (HAG_PARENT_ADMIN_UNIT IN'||CHR(10)||'(SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'Y'
       ,'N'
       ,'road_id'
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5074'
                    AND  GMP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5074'
       ,'STRUCTURE_TYPE'
       ,4
       ,'Structure Type'
       ,'N'
       ,1
       ,'SIT_LEVEL = 1'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5074'
                    AND  GMP_PARAM = 'STRUCTURE_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5074'
       ,'STR_CYCLE'
       ,3
       ,'Inspection Cycle'
       ,'N'
       ,1
       ,''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5074'
                    AND  GMP_PARAM = 'STR_CYCLE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5074'
       ,'STR_INSP_TYPE'
       ,5
       ,'Inspection Type'
       ,'N'
       ,1
       ,''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5074'
                    AND  GMP_PARAM = 'STR_INSP_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5074'
       ,'TO_DATE'
       ,7
       ,'To Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE) OR (:FROM_DATE IS NULL))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5074'
                    AND  GMP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5076'
       ,'ADMIN_UNIT'
       ,1
       ,'Admin Unit'
       ,'N'
       ,1
       ,'(HAU_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,'HIG_ADMIN_UNITS'
       ,'HAU_ADMIN_UNIT'
       ,'HAU_ADMIN_UNIT = (SELECT MAX(HUS_ADMIN_UNIT) FROM HIG_USERS WHERE HUS_USERNAME = USER)'
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5076'
                    AND  GMP_PARAM = 'ADMIN_UNIT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5076'
       ,'FROM_DATE'
       ,5
       ,'From Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE AND :FROM_DATE <= SYSDATE) OR (:TO_DATE IS NULL AND :FROM_DATE <= SYSDATE))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5076'
                    AND  GMP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5076'
       ,'ROAD_ID'
       ,2
       ,'Road Id'
       ,'N'
       ,1
       ,'RSE_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR (HAG_PARENT_ADMIN_UNIT IN'||CHR(10)||'(SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'Y'
       ,'N'
       ,'road_id'
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5076'
                    AND  GMP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5076'
       ,'STRUCTURE_TYPE'
       ,4
       ,'Structure Type'
       ,'N'
       ,1
       ,'SIT_LEVEL = 1'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5076'
                    AND  GMP_PARAM = 'STRUCTURE_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5076'
       ,'STR_CYCLE'
       ,3
       ,'Inspection Cycle'
       ,'N'
       ,1
       ,''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5076'
                    AND  GMP_PARAM = 'STR_CYCLE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5076'
       ,'TO_DATE'
       ,6
       ,'To Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE AND :TO_DATE <= SYSDATE) OR (:FROM_DATE IS NULL AND :TO_DATE <= SYSDATE))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5076'
                    AND  GMP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5078'
       ,'ADMIN_UNIT'
       ,1
       ,'Admin Unit'
       ,'N'
       ,1
       ,'(HAU_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,'HIG_ADMIN_UNITS'
       ,'HAU_ADMIN_UNIT'
       ,'HAU_ADMIN_UNIT = (SELECT MAX(HUS_ADMIN_UNIT) FROM HIG_USERS WHERE HUS_USERNAME = USER)'
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5078'
                    AND  GMP_PARAM = 'ADMIN_UNIT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5078'
       ,'FROM_DATE'
       ,5
       ,'From Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE AND :FROM_DATE <= SYSDATE) OR (:TO_DATE IS NULL AND :FROM_DATE <= SYSDATE))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5078'
                    AND  GMP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5078'
       ,'ROAD_ID'
       ,2
       ,'Road Id'
       ,'N'
       ,1
       ,'RSE_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR (HAG_PARENT_ADMIN_UNIT IN'||CHR(10)||'(SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'Y'
       ,'N'
       ,'road_id'
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5078'
                    AND  GMP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5078'
       ,'STRUCTURE_TYPE'
       ,3
       ,'Structure Type'
       ,'N'
       ,1
       ,'SIT_LEVEL = 1'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5078'
                    AND  GMP_PARAM = 'STRUCTURE_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5078'
       ,'STR_INSP_TYPE'
       ,4
       ,'Inspection Type'
       ,'N'
       ,1
       ,''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5078'
                    AND  GMP_PARAM = 'STR_INSP_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5078'
       ,'TO_DATE'
       ,6
       ,'To Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE AND :TO_DATE <= SYSDATE) OR (:FROM_DATE IS NULL AND :TO_DATE <= SYSDATE))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5078'
                    AND  GMP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5080'
       ,'ADMIN_UNIT'
       ,1
       ,'Admin Unit'
       ,'N'
       ,1
       ,'(HAU_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,'HIG_ADMIN_UNITS'
       ,'HAU_ADMIN_UNIT'
       ,'HAU_ADMIN_UNIT = (SELECT MAX(HUS_ADMIN_UNIT) FROM HIG_USERS WHERE HUS_USERNAME = USER)'
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5080'
                    AND  GMP_PARAM = 'ADMIN_UNIT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5080'
       ,'FROM_DATE'
       ,5
       ,'From Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE AND :FROM_DATE <= SYSDATE) OR (:TO_DATE IS NULL AND :FROM_DATE <= SYSDATE))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5080'
                    AND  GMP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5080'
       ,'ROAD_ID'
       ,2
       ,'Road Id'
       ,'N'
       ,1
       ,'RSE_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR (HAG_PARENT_ADMIN_UNIT IN'||CHR(10)||'(SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'Y'
       ,'N'
       ,'road_id'
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5080'
                    AND  GMP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5080'
       ,'STRUCTURE_TYPE'
       ,3
       ,'Structure Type'
       ,'N'
       ,1
       ,'SIT_LEVEL = 1'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5080'
                    AND  GMP_PARAM = 'STRUCTURE_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5080'
       ,'STR_INSP_TYPE'
       ,4
       ,'Inspection Type'
       ,'N'
       ,1
       ,''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5080'
                    AND  GMP_PARAM = 'STR_INSP_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5080'
       ,'TO_DATE'
       ,6
       ,'To Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE AND :TO_DATE <= SYSDATE) OR (:FROM_DATE IS NULL AND :TO_DATE <= SYSDATE))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5080'
                    AND  GMP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5082'
       ,'ADMIN_UNIT'
       ,1
       ,'Admin Unit'
       ,'N'
       ,1
       ,'(HAU_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,'HIG_ADMIN_UNITS'
       ,'HAU_ADMIN_UNIT'
       ,'HAU_ADMIN_UNIT = (SELECT MAX(HUS_ADMIN_UNIT) FROM HIG_USERS WHERE HUS_USERNAME = USER)'
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5082'
                    AND  GMP_PARAM = 'ADMIN_UNIT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5082'
       ,'FROM_DATE'
       ,11
       ,'From Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE) OR (:TO_DATE IS NULL))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5082'
                    AND  GMP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5082'
       ,'ROAD_ID'
       ,2
       ,'Road Id'
       ,'N'
       ,1
       ,'RSE_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR (HAG_PARENT_ADMIN_UNIT IN'||CHR(10)||'(SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'Y'
       ,'N'
       ,'road_id'
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5082'
                    AND  GMP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5082'
       ,'STRUCTURE_TYPE'
       ,3
       ,'Structure Type'
       ,'N'
       ,1
       ,'SIT_LEVEL = 1'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5082'
                    AND  GMP_PARAM = 'STRUCTURE_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5082'
       ,'STR_ACTION'
       ,10
       ,'Inspection Item Action'
       ,'N'
       ,1
       ,'SAL_SAD_ID = ''DEFECT ACTION'''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5082'
                    AND  GMP_PARAM = 'STR_ACTION');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5082'
       ,'STR_EXTENT'
       ,7
       ,'Inspection Item Extent'
       ,'N'
       ,1
       ,'SAL_SAD_ID = ''DEFECT EXTENT'''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5082'
                    AND  GMP_PARAM = 'STR_EXTENT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5082'
       ,'STR_EXTENT2'
       ,8
       ,'Inspection Item Extent'
       ,'N'
       ,1
       ,'SAL_SAD_ID = ''DEFECT EXTENT'''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5082'
                    AND  GMP_PARAM = 'STR_EXTENT2');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5082'
       ,'STR_ITEM_TYPE'
       ,4
       ,'Component Structure Type'
       ,'N'
       ,1
       ,'SIT_ID IN (SELECT DISTINCT SIL_CMP_SIT_ID FROM STR_INSP_LINES, STR_INSP, STR_ITEMS_ALL WHERE  SIL_SIP_ID = SIP_ID AND SIP_STR_ID = STR_ID AND (STR_SIT_ID = :STRUCTURE_TYPE OR :STRUCTURE_TYPE IS NULL))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5082'
                    AND  GMP_PARAM = 'STR_ITEM_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5082'
       ,'STR_PRIORITY'
       ,9
       ,'Inspection Item Priority'
       ,'N'
       ,1
       ,'SAL_SAD_ID = ''DEFECT PRIORITY'''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5082'
                    AND  GMP_PARAM = 'STR_PRIORITY');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5082'
       ,'STR_SEVERITY'
       ,5
       ,'Inspection Item Severity'
       ,'N'
       ,1
       ,'SAL_SAD_ID = ''DEFECT SEVERITY'''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5082'
                    AND  GMP_PARAM = 'STR_SEVERITY');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5082'
       ,'STR_SEVERITY2'
       ,6
       ,'Inspection Item Severity'
       ,'N'
       ,1
       ,'SAL_SAD_ID = ''DEFECT SEVERITY'''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5082'
                    AND  GMP_PARAM = 'STR_SEVERITY2');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5082'
       ,'TO_DATE'
       ,12
       ,'To Date'
       ,'N'
       ,1
       ,'((:FROM_DATE <= :TO_DATE) OR'||CHR(10)||' (:FROM_DATE IS NULL))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5082'
                    AND  GMP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5084'
       ,'ADMIN_UNIT'
       ,1
       ,'Admin Unit'
       ,'N'
       ,1
       ,'(HAU_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE HAG_PARENT_ADMIN_UNIT IN (SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,'HIG_ADMIN_UNITS'
       ,'HAU_ADMIN_UNIT'
       ,'HAU_ADMIN_UNIT = (SELECT MAX(HUS_ADMIN_UNIT) FROM HIG_USERS WHERE HUS_USERNAME = USER)'
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5084'
                    AND  GMP_PARAM = 'ADMIN_UNIT');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5084'
       ,'ROAD_ID'
       ,2
       ,'Road Id'
       ,'N'
       ,1
       ,'RSE_ADMIN_UNIT IN (SELECT HAG_CHILD_ADMIN_UNIT FROM HIG_ADMIN_GROUPS WHERE'||CHR(10)||'(HAG_PARENT_ADMIN_UNIT = :ADMIN_UNIT) OR (HAG_PARENT_ADMIN_UNIT IN'||CHR(10)||'(SELECT HUS_ADMIN_UNIT FROM HIG_USERS WHERE HUS_USERNAME = USER)))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'Y'
       ,'N'
       ,'road_id'
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5084'
                    AND  GMP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5084'
       ,'STRUCTURE_TYPE'
       ,3
       ,'Structure Type'
       ,'N'
       ,1
       ,'SIT_LEVEL = 1'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5084'
                    AND  GMP_PARAM = 'STRUCTURE_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5084'
       ,'STR_EXTENT_VARIANCE'
       ,7
       ,'Item Extent Variance'
       ,'N'
       ,1
       ,''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5084'
                    AND  GMP_PARAM = 'STR_EXTENT_VARIANCE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5084'
       ,'STR_ITEM_TYPE'
       ,4
       ,'Component Structure Type'
       ,'N'
       ,1
       ,'SIT_ID IN (SELECT DISTINCT SIL_CMP_SIT_ID FROM STR_INSP_LINES,'||CHR(10)||' STR_INSP, STR_ITEMS_ALL WHERE  SIL_SIP_ID = SIP_ID AND SIP_STR_ID ='||CHR(10)||' STR_ID AND (STR_SIT_ID = :STRUCTURE_TYPE OR :STRUCTURE_TYPE IS NULL))'
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'Y'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5084'
                    AND  GMP_PARAM = 'STR_ITEM_TYPE');
--
INSERT INTO GRI_MODULE_PARAMS
       (GMP_MODULE
       ,GMP_PARAM
       ,GMP_SEQ
       ,GMP_PARAM_DESCR
       ,GMP_MANDATORY
       ,GMP_NO_ALLOWED
       ,GMP_WHERE
       ,GMP_TAG_RESTRICTION
       ,GMP_TAG_WHERE
       ,GMP_DEFAULT_TABLE
       ,GMP_DEFAULT_COLUMN
       ,GMP_DEFAULT_WHERE
       ,GMP_VISIBLE
       ,GMP_GAZETTEER
       ,GMP_LOV
       ,GMP_VAL_GLOBAL
       ,GMP_WILDCARD
       ,GMP_HINT_TEXT
       ,GMP_ALLOW_PARTIAL
       ,GMP_BASE_TABLE
       ,GMP_BASE_TABLE_COLUMN
       ,GMP_OPERATOR
       )
SELECT 
        'STR5084'
       ,'STR_SEVERITY_VARIANCE'
       ,5
       ,'Item Severity Variance'
       ,'N'
       ,1
       ,''
       ,'N'
       ,''
       ,''
       ,''
       ,''
       ,'Y'
       ,'N'
       ,'N'
       ,''
       ,'N'
       ,''
       ,'N'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_MODULE_PARAMS
                   WHERE GMP_MODULE = 'STR5084'
                    AND  GMP_PARAM = 'STR_SEVERITY_VARIANCE');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- GRI_PARAM_DEPENDENCIES
--
-- select * from str_metadata.gri_param_dependencies
-- order by gpd_indep_param
--         ,gpd_module
--         ,gpd_dep_param
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT gri_param_dependencies
SET TERM OFF

INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5010'
       ,'ROAD_ID'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5010'
                    AND  GPD_DEP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5010'
       ,'STRUCTURE_NAME'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5010'
                    AND  GPD_DEP_PARAM = 'STRUCTURE_NAME');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5010'
       ,'STRUCTURE_REF'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5010'
                    AND  GPD_DEP_PARAM = 'STRUCTURE_REF');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5015'
       ,'STRUCTURE_NAME'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5015'
                    AND  GPD_DEP_PARAM = 'STRUCTURE_NAME');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5015'
       ,'STRUCTURE_REF'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5015'
                    AND  GPD_DEP_PARAM = 'STRUCTURE_REF');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5015'
       ,'STR_INSP_BATCH'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5015'
                    AND  GPD_DEP_PARAM = 'STR_INSP_BATCH');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5020'
       ,'ROAD_ID'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5020'
                    AND  GPD_DEP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5020'
       ,'STR_OBS_TYPE'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5020'
                    AND  GPD_DEP_PARAM = 'STR_OBS_TYPE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5030'
       ,'ROAD_ID'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5030'
                    AND  GPD_DEP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5030'
       ,'STR_OBS_LIMIT1'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5030'
                    AND  GPD_DEP_PARAM = 'STR_OBS_LIMIT1');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5030'
       ,'STR_OBS_LIMIT2'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5030'
                    AND  GPD_DEP_PARAM = 'STR_OBS_LIMIT2');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5030'
       ,'STR_OBS_LIMIT3'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5030'
                    AND  GPD_DEP_PARAM = 'STR_OBS_LIMIT3');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5030'
       ,'STR_OBS_LIMIT4'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5030'
                    AND  GPD_DEP_PARAM = 'STR_OBS_LIMIT4');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5030'
       ,'STR_OBS_TYPE'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5030'
                    AND  GPD_DEP_PARAM = 'STR_OBS_TYPE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5030'
       ,'STR_OBS_TYPE2'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5030'
                    AND  GPD_DEP_PARAM = 'STR_OBS_TYPE2');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5030'
       ,'STR_OBS_TYPE3'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5030'
                    AND  GPD_DEP_PARAM = 'STR_OBS_TYPE3');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5030'
       ,'STR_OBS_TYPE4'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5030'
                    AND  GPD_DEP_PARAM = 'STR_OBS_TYPE4');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5042'
       ,'ROAD_ID'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5042'
                    AND  GPD_DEP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5050'
       ,'ROAD_ID'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5050'
                    AND  GPD_DEP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5070'
       ,'ROAD_ID'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5070'
                    AND  GPD_DEP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5072'
       ,'STR_INSP_BATCH'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5072'
                    AND  GPD_DEP_PARAM = 'STR_INSP_BATCH');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5074'
       ,'ROAD_ID'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5074'
                    AND  GPD_DEP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5076'
       ,'ROAD_ID'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5076'
                    AND  GPD_DEP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5078'
       ,'ROAD_ID'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5078'
                    AND  GPD_DEP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5080'
       ,'ROAD_ID'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5080'
                    AND  GPD_DEP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5082'
       ,'ROAD_ID'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5082'
                    AND  GPD_DEP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5084'
       ,'ROAD_ID'
       ,'ADMIN_UNIT' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ADMIN_UNIT'
                    AND  GPD_MODULE = 'STR5084'
                    AND  GPD_DEP_PARAM = 'ROAD_ID');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5070'
       ,'STR_EQPT'
       ,'ANSWER' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ANSWER'
                    AND  GPD_MODULE = 'STR5070'
                    AND  GPD_DEP_PARAM = 'STR_EQPT');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5015'
       ,'FROM_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5015'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5015'
       ,'TO_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5015'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5020'
       ,'FROM_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5020'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5020'
       ,'TO_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5020'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5070'
       ,'FROM_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5070'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5070'
       ,'TO_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5070'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5072'
       ,'FROM_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5072'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5072'
       ,'TO_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5072'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5074'
       ,'FROM_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5074'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5074'
       ,'TO_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5074'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5076'
       ,'FROM_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5076'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5076'
       ,'TO_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5076'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5078'
       ,'FROM_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5078'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5078'
       ,'TO_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5078'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5080'
       ,'FROM_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5080'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5080'
       ,'TO_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5080'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5082'
       ,'FROM_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5082'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5082'
       ,'TO_DATE'
       ,'FROM_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'FROM_DATE'
                    AND  GPD_MODULE = 'STR5082'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5010'
       ,'STRUCTURE_NAME'
       ,'ROAD_ID' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ROAD_ID'
                    AND  GPD_MODULE = 'STR5010'
                    AND  GPD_DEP_PARAM = 'STRUCTURE_NAME');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5010'
       ,'STRUCTURE_REF'
       ,'ROAD_ID' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'ROAD_ID'
                    AND  GPD_MODULE = 'STR5010'
                    AND  GPD_DEP_PARAM = 'STRUCTURE_REF');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5010'
       ,'STRUCTURE_NAME'
       ,'STRUCTURE_TYPE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'STRUCTURE_TYPE'
                    AND  GPD_MODULE = 'STR5010'
                    AND  GPD_DEP_PARAM = 'STRUCTURE_NAME');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5010'
       ,'STRUCTURE_REF'
       ,'STRUCTURE_TYPE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'STRUCTURE_TYPE'
                    AND  GPD_MODULE = 'STR5010'
                    AND  GPD_DEP_PARAM = 'STRUCTURE_REF');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5015'
       ,'STRUCTURE_NAME'
       ,'STRUCTURE_TYPE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'STRUCTURE_TYPE'
                    AND  GPD_MODULE = 'STR5015'
                    AND  GPD_DEP_PARAM = 'STRUCTURE_NAME');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5015'
       ,'STRUCTURE_REF'
       ,'STRUCTURE_TYPE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'STRUCTURE_TYPE'
                    AND  GPD_MODULE = 'STR5015'
                    AND  GPD_DEP_PARAM = 'STRUCTURE_REF');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5082'
       ,'STR_ITEM_TYPE'
       ,'STRUCTURE_TYPE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'STRUCTURE_TYPE'
                    AND  GPD_MODULE = 'STR5082'
                    AND  GPD_DEP_PARAM = 'STR_ITEM_TYPE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5084'
       ,'STR_ITEM_TYPE'
       ,'STRUCTURE_TYPE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'STRUCTURE_TYPE'
                    AND  GPD_MODULE = 'STR5084'
                    AND  GPD_DEP_PARAM = 'STR_ITEM_TYPE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5015'
       ,'STRUCTURE_NAME'
       ,'STR_INSP_TYPE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'STR_INSP_TYPE'
                    AND  GPD_MODULE = 'STR5015'
                    AND  GPD_DEP_PARAM = 'STRUCTURE_NAME');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5015'
       ,'STRUCTURE_REF'
       ,'STR_INSP_TYPE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'STR_INSP_TYPE'
                    AND  GPD_MODULE = 'STR5015'
                    AND  GPD_DEP_PARAM = 'STRUCTURE_REF');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5030'
       ,'STR_OBS_LIMIT1'
       ,'STR_OBS_TYPE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'STR_OBS_TYPE'
                    AND  GPD_MODULE = 'STR5030'
                    AND  GPD_DEP_PARAM = 'STR_OBS_LIMIT1');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5030'
       ,'STR_OBS_LIMIT2'
       ,'STR_OBS_TYPE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'STR_OBS_TYPE'
                    AND  GPD_MODULE = 'STR5030'
                    AND  GPD_DEP_PARAM = 'STR_OBS_LIMIT2');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5030'
       ,'STR_OBS_LIMIT3'
       ,'STR_OBS_TYPE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'STR_OBS_TYPE'
                    AND  GPD_MODULE = 'STR5030'
                    AND  GPD_DEP_PARAM = 'STR_OBS_LIMIT3');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5030'
       ,'STR_OBS_LIMIT4'
       ,'STR_OBS_TYPE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'STR_OBS_TYPE'
                    AND  GPD_MODULE = 'STR5030'
                    AND  GPD_DEP_PARAM = 'STR_OBS_LIMIT4');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5015'
       ,'FROM_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5015'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5015'
       ,'TO_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5015'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5020'
       ,'FROM_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5020'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5020'
       ,'TO_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5020'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5070'
       ,'FROM_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5070'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5070'
       ,'TO_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5070'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5072'
       ,'FROM_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5072'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5072'
       ,'TO_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5072'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5074'
       ,'FROM_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5074'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5074'
       ,'TO_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5074'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5076'
       ,'FROM_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5076'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5076'
       ,'TO_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5076'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5078'
       ,'FROM_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5078'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5078'
       ,'TO_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5078'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5080'
       ,'FROM_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5080'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5080'
       ,'TO_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5080'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5082'
       ,'FROM_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5082'
                    AND  GPD_DEP_PARAM = 'FROM_DATE');
--
INSERT INTO GRI_PARAM_DEPENDENCIES
       (GPD_MODULE
       ,GPD_DEP_PARAM
       ,GPD_INDEP_PARAM
       )
SELECT 
        'STR5082'
       ,'TO_DATE'
       ,'TO_DATE' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM GRI_PARAM_DEPENDENCIES
                   WHERE GPD_INDEP_PARAM = 'TO_DATE'
                    AND  GPD_MODULE = 'STR5082'
                    AND  GPD_DEP_PARAM = 'TO_DATE');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- GRI_PARAM_LOOKUP
--
-- select * from str_metadata.gri_param_lookup
-- order by gpl_param
--         ,gpl_value
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT gri_param_lookup
SET TERM OFF

--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- HIG_ERRORS
--
-- select * from str_metadata.hig_errors
-- order by her_appl
--         ,her_no
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT hig_errors
SET TERM OFF

INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,1
       ,'E'
       ,'At last record.'
       ,'You are at the last record in the block.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 1);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,2
       ,'I'
       ,'Transaction complete.'
       ,'Transaction complete, all records posted and committed.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 2);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,3
       ,'E'
       ,'This is a mandatory field'
       ,'This field must be entered before proceeding.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 3);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,4
       ,'E'
       ,'Block name required if field name entered.'
       ,'Either enter the block name corresponding to the entered field name or'
       ,'remove the field name value.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 4);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,5
       ,'E'
       ,'Code already exists.'
       ,'Enter unique code.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 5);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,6
       ,'E'
       ,'Allowed values are Y or N'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 6);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,7
       ,'E'
       ,'Allowed values are CHAR, INT, NUM, DATE or LIST'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 7);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,8
       ,'E'
       ,'Value must be greater than 0.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 8);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,9
       ,'E'
       ,'The Maximum value must be greater than Minimum value.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 9);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,10
       ,'E'
       ,'Record cannot be deleted since associated records exist.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 10);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,11
       ,'E'
       ,'That template does not exist.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 11);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,12
       ,'E'
       ,'You cannot delete the structure in this form.'
       ,'Deletion of a Structure is a separate form.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 12);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,13
       ,'E'
       ,'Field is protected against update.'
       ,'This field is protected against update.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 13);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,14
       ,'E'
       ,'Length of Value exceeds Maximum Length.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 14);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,15
       ,'E'
       ,'The number entered is outside the max and min range.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 15);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,16
       ,'E'
       ,'This is not a valid number.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 16);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,17
       ,'E'
       ,'Incorrect number of decimal places.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 17);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,18
       ,'E'
       ,'Invalid date format entered'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 18);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,19
       ,'E'
       ,'The value entered is not valid; use [List]'
       ,'Select a valid value from the [list of values].'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 19);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,20
       ,'E'
       ,'List of values not available for this field.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 20);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,21
       ,'E'
       ,'The Template record must be accessed via the top block.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 21);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,22
       ,'E'
       ,'Invalid Attribute code entered.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 22);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,23
       ,'E'
       ,'This record can not be deleted in this block.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 23);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,24
       ,'E'
       ,'At first Block'
       ,'You are the first block in this form. No blocks precede it.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 24);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,25
       ,'E'
       ,'At last Block'
       ,'You are at the last block in this form. No more blocks follow it.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 25);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,26
       ,'E'
       ,'You must query or enter a record before proceeding.'
       ,'You have tried to move to the next block before any details have been'
       ,'entered in the current block. Either query a record back or enter a record'
       ,'as appropriate.'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 26);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,27
       ,'E'
       ,'Allowed values are Y or N'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 27);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,28
       ,'E'
       ,'Obstructions of this type still exist'
       ,'You have tried to delete an obstruction type when obstructions of that type'
       ,'still exist in the database. The only way of removing an obstruction type'
       ,'is by first removing all obstructions which are of that type.'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 28);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,29
       ,'I'
       ,'Scrolling to last record.'
       ,'You are currently at the first record in the block. The cursor will now be'
       ,'repositioned on the last record.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 29);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,30
       ,'I'
       ,'Scrolling to first record.'
       ,'You are currently at the last record in the block. The cursor will now be'
       ,'repositioned to the first record in the block.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 30);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,31
       ,'E'
       ,'At first record.'
       ,'You are at the first record in the block.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 31);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,32
       ,'E'
       ,'Invalid Linkname / Section'
       ,'You have entered an invalid Linkname / Section.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 32);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,33
       ,'E'
       ,'Invalid Obstruction type.'
       ,'You have entered an invalid obstruction type.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 33);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,34
       ,'E'
       ,'Invalid road intersection juxtaposition.'
       ,'You have entered an invalid road intersection juxtaposition.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 34);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,35
       ,'E'
       ,'Invalid cross sectional position.'
       ,'You have entered an invalid cross sectional position for the structure.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 35);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,36
       ,'E'
       ,'Start Date must not be greater than End Date.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 36);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,37
       ,'E'
       ,'New Structure must be committed before processing further.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 37);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,38
       ,'E'
       ,'The name of the new structure must be entered.'
       ,'When creating a new structure it is not possible to press [COMMIT] without'
       ,'having entered the name of the new structure.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 38);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,39
       ,'E'
       ,'Name already exists.'
       ,'Attribute List Name already exist. Enter a new list name.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 39);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,40
       ,'E'
       ,'Value already exists.'
       ,'This Look-up value already exist. Enter a New value.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 40);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,41
       ,'E'
       ,'Structure must be selected from [List], or [Execute Query]'
       ,'You must select the structure to be maintained either from the [List]'
       ,'function or executing a query.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 41);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,42
       ,'E'
       ,'Structure Name already exists.'
       ,'The name given to the structure already exists for another structure.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 42);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,43
       ,'E'
       ,'Template must be selected from [List], or [Execute Query]'
       ,'The Template name must be selected either from the list-of-values [List]'
       ,'or by entering/executing a query.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 43);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,44
       ,'E'
       ,'Item Type does not exist.'
       ,'This Item Type does not exist. Select a valid type from the list-of-values'
       ,'[List].'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 44);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,45
       ,'E'
       ,'Unable to delete record as dependants exist.'
       ,'This ''Parent'' record has dependants. The dependants must be deleted first.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 45);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,46
       ,'E'
       ,'Cannot update Item Type, associated records exist.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 46);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,47
       ,'E'
       ,'Template Name already exists.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 47);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,48
       ,'E'
       ,'Item type incorrect for this level.'
       ,'The level associated with this item type must be greater or equal to the'
       ,'previous item type level.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 48);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,49
       ,'E'
       ,'Start Value must not be greater than End Value.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 49);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,50
       ,'E'
       ,'Cannot update Item Type, dependencies exist.'
       ,'This item has dependents within the hierarchy and therefore cannot be'
       ,'updated'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 50);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,51
       ,'E'
       ,'Obstruction Type must be unique within Road Intersection'
       ,'You have entered a duplicate Obstruction Type eg. LENG for the Intersection'
       ,'The Obstruction Type must be unique within the Intersection.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 51);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,52
       ,'E'
       ,'Sequence number must be unique within the Structure.'
       ,'You have entered a non unique sequence number for the Instersection within'
       ,'the structure.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 52);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,53
       ,'E'
       ,'Template Name already exists.'
       ,'You have entered a duplicate Template name.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 53);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,54
       ,'E'
       ,'Invalid operator entered'
       ,'You have entered an invalid operator.  The valid operators are =>< and L'
       ,'(List).  The particular operator that can be used depends on the nature of'
       ,'the attribute itself, i.e. MATL (Material) expects numeric values, and'
       ,'thus entering ''ONE'' (and not ''1'') would be incorrect.'
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 54);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,55
       ,'E'
       ,'Cannot create records with this application.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 55);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,56
       ,'E'
       ,'Value required if Attribute Code entered.'
       ,'You have entered an Attribute Code but have tried to leave this field'
       ,'without supplying a value.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 56);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,57
       ,'E'
       ,'An Authority Code must exist if the Organisation type is ''A'''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 57);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,58
       ,'E'
       ,'Electricity Code already exists.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 58);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,59
       ,'E'
       ,'Electricity Board must be completed.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 59);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,60
       ,'E'
       ,'Unable to read CODE_CONTROLS record for Street Id.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 60);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,61
       ,'S'
       ,'Unable to update CODE_CONTROLS record.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 61);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,62
       ,'E'
       ,'These are the Authority Organisation details. Cannot delete.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 62);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,63
       ,'E'
       ,'Road segments exist. Cannot delete.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 63);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,64
       ,'E'
       ,'These are the Authority Organisation details. Cannot delete.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 64);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,65
       ,'E'
       ,'Cannot update field. Organisation is the Primary Agent.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 65);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,66
       ,'E'
       ,'Invalid Electricity Board Id entered.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 66);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,67
       ,'E'
       ,'This is not a valid Organisation Type.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 67);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,68
       ,'E'
       ,'Organisation code must exist of Electricity Board.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 68);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,69
       ,'E'
       ,'You cannot change these agent details.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 69);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,70
       ,'E'
       ,'You cannot enter an authority code.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 70);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,71
       ,'E'
       ,'Partial Budget Code already exists.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 71);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,72
       ,'E'
       ,'Further records cannot be entered.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 72);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,73
       ,'S'
       ,'Unable to insert ORG_UNITS record for Primary Agent.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 73);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,74
       ,'E'
       ,'You cannot delete records in this block.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 74);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,75
       ,'E'
       ,'This function key is not defined for this form.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 75);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,76
       ,'S'
       ,'Unable to read CODE_CONTROLS record for ORG_UNITS.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 76);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,77
       ,'E'
       ,'Cannot delete Inspection Cycle while Structure is on it'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 77);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,78
       ,'E'
       ,'Row exists already with same Cycle No'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 78);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,79
       ,'E'
       ,'Row exists already with same Cycle Name'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 79);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,80
       ,'E'
       ,'Row exists already with same Equipment'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 80);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,81
       ,'E'
       ,'Both Group Type and Group Name must be entered, or neither.'
       ,'Enter Group Type and Group Name or neither of them.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 81);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,82
       ,'E'
       ,'Invalid Cycle Id; use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 82);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,83
       ,'E'
       ,'Invalid Inspection Type; use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 83);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,84
       ,'E'
       ,'Invalid Batch number; use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 84);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,85
       ,'E'
       ,'Batch number and Detail flag must be entered'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 85);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,86
       ,'E'
       ,'Detailed Notes Flag must be entered'
       ,'Enter either Y or N.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 86);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,87
       ,'E'
       ,'Invalid Group Type/Group Name Combination'
       ,'Use List of Values to obtain valid combination.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 87);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,88
       ,'E'
       ,'Invalid Group Type'
       ,'Use List of Values to obtain valid Group Type.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 88);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,89
       ,'E'
       ,'Invalid Group Name'
       ,'Use List of Values to obtain valid Group Name.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 89);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,90
       ,'I'
       ,'Field should be left Blank'
       ,'A Value cannot be entered without a Valid Obstruction Type'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 90);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,91
       ,'E'
       ,'Obstruction Type already entered - re-enter'
       ,'Obstruction Types cannot be duplicated. Use List of Values for valid types'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 91);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,92
       ,'I'
       ,'Leave Field Blank - Use 2nd type field first'
       ,'The 2nd obstruction type field must be populated before the 3rd one. The'
       ,'type fields should be used in sequence from left to right.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 92);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,93
       ,'I'
       ,'Leave Field Blank - Use 2nd or 3rd type field first'
       ,'The 2nd and 3rd Obstruction types must be populated before the 4th one.'
       ,'The type fields should be used in sequence from left to right.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 93);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,94
       ,'I'
       ,'List of values not available in current context.'
       ,'List of Values is available for this field, but not in the current context'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 94);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,95
       ,'E'
       ,'Row exists for this Structure, Inspection and Organisation'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 95);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,96
       ,'E'
       ,'Structure currently locked by another user'
       ,'Another user is concurrently updating this structure and has therefore'
       ,'locked the structure to ensure data integrity.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 96);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,97
       ,'E'
       ,'Both Group Type and Group Name must be entered.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 97);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,98
       ,'E'
       ,'Must be a level 1 item type.'
       ,'Enter a structure type defined as a level 1 type.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 98);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,99
       ,'E'
       ,'Start date of item must not be earlier than the parent item'
       ,'Within the structure hierarchy the ''child item'' start date must not be'
       ,'earlier than that of its ''parent item'''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 99);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,100
       ,'E'
       ,'End date of item must not be later than the parent item'
       ,'Within the structure hierarchy, the end date of a ''child item'' must not'
       ,'be later than that of its ''parent item'''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 100);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,101
       ,'E'
       ,'This structure may only be built from a template with 1 span'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 101);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,102
       ,'E'
       ,'Invalid attribute type / item type combination.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 102);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,103
       ,'E'
       ,'Attribute value must be entered.'
       ,'For this operation it is neccessary to enter a value against the'
       ,'attribute.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 103);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,104
       ,'I'
       ,'Locking records ...'
       ,'Records are being locked prior to transaction.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 104);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,105
       ,'I'
       ,'No attributes have been initialised.'
       ,'Transaction did not insert any records.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 105);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,106
       ,'E'
       ,'Create template with [Insert Record], enter top level item'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 106);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,107
       ,'E'
       ,'Decription is mandatory for top level component'
       ,'You must enter a description for the first component you enter in the'
       ,'template hierarchy, as the Item Name corresponding to this forms the name'
       ,'of the template itself.'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 107);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,108
       ,'E'
       ,'Item no longer exists. Re-query before proceeding.'
       ,'The structure displayed has been changed since the query was executed.'
       ,'Before proceeding with any updates requery to populate the block with the'
       ,'correct records.'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 108);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,109
       ,'E'
       ,'Item changed since last query. Re-query before proceeding.'
       ,'This structure item has changed since the query was actioned. Re-query'
       ,'the block to populate with up to date records.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 109);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,110
       ,'E'
       ,'Template currently locked by another user'
       ,'This template is concurrently being accessed by another user who is also'
       ,'performing updates against the user.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 110);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,111
       ,'E'
       ,'No Structures match these query conditions.'
       ,'The query conditions entered in block 1 do not correspond to'
       ,'any structures.'
       ,'Re-enter query conditions and press [Next Block].'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 111);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,112
       ,'E'
       ,'Mandatory field for top level Item'
       ,'This description is a mandatory field for a top level Item'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 112);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,113
       ,'E'
       ,'Field may not be changed as items exist with this attribute.'
       ,'The attribute''s nature may not be altered if items exist with values'
       ,'set for this attribute.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 113);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,114
       ,'E'
       ,'Invalid Structure Type; use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 114);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,115
       ,'E'
       ,'Invalid Group Type; use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 115);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,116
       ,'E'
       ,'Invalid Group Type/Name combination; use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 116);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,117
       ,'E'
       ,'Invalid Item Type; use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 117);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,118
       ,'S'
       ,'Structure Name not found for this V_INTERSECTIONS.RIN_STR_ID'
       ,'There is an error in your data. Contact your DBA.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 118);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,119
       ,'I'
       ,'No Obstructions retrieved for these Selection Criteria'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 119);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,120
       ,'E'
       ,'Invalid Road Group Name; use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 120);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,121
       ,'E'
       ,'Invalid Organisation code; use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 121);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,122
       ,'E'
       ,'Invalid Equipment Code; use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 122);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,123
       ,'E'
       ,'Row exists with same Structure, Inspection and Equipment'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 123);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,124
       ,'E'
       ,'Inspection in progress; cannot modify record.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 124);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,125
       ,'E'
       ,'Invalid Equipment Name; use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 125);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,126
       ,'E'
       ,'Interval cannot be greater than mandated interval.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 126);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,127
       ,'E'
       ,'Mandated Interval cannot be less than any actual intervals'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 127);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,128
       ,'E'
       ,'Preferred Interval must be less than Mandated Interval.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 128);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,129
       ,'E'
       ,'Component Type does not exist.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 129);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,130
       ,'E'
       ,'Attribute Type does not exist.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 130);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,131
       ,'E'
       ,'Cannot delete while Valid Structural Inspections exist.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 131);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,132
       ,'E'
       ,'Cannot delete while Inspections exist.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 132);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,133
       ,'E'
       ,'Cannot delete while Inspection Intervals exist.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 133);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,134
       ,'E'
       ,'Cannot delete while Valid Inspection Attributes exist.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 134);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,135
       ,'E'
       ,'Cannot delete while Inspection Default Components exist.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 135);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,136
       ,'E'
       ,'Row exists already with same name.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 136);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,137
       ,'E'
       ,'Row exists already with same code.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 137);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,138
       ,'E'
       ,'Row exists already with same Structure Type, Inspection Type'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 138);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,139
       ,'E'
       ,'Row exists with same Structure, Inspection and Component'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 139);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,140
       ,'E'
       ,'This Component Type, Attribute Type does not exist.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 140);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,141
       ,'E'
       ,'Row exists with Structure,Inspection,Component & Attribute'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 141);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,142
       ,'E'
       ,'Equipment used in equipment list'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 142);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,143
       ,'E'
       ,'Person identification error.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 143);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,144
       ,'E'
       ,'Inspection Type identification error.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 144);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,145
       ,'E'
       ,'Start Date required with End Date.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 145);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,146
       ,'E'
       ,'You cannot create records in this block.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 146);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,147
       ,'I'
       ,'Inspection in progress; cannot modify record.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 147);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,148
       ,'E'
       ,'Invalid Extent value, rectify and resubmit'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 148);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,149
       ,'E'
       ,'Invalid Severity value, rectify and resubmit'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 149);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,150
       ,'E'
       ,'Invalid Priority value, rectify and resubmit'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 150);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,151
       ,'E'
       ,'Invalid Required Action value, rectify and resubmit'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 151);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,152
       ,'E'
       ,'Invalid Inspector''s initials, rectify and resubmit'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 152);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,153
       ,'E'
       ,'Invalid Attribute Value, rectify and resubmit'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 153);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,154
       ,'E'
       ,'Structure type location error.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 154);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,155
       ,'W'
       ,'That batch cannot be updated.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 155);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,156
       ,'W'
       ,'Inspection de-selected.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 156);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,157
       ,'E'
       ,'Intervals do not exist, cannot go to next block.'
       ,'There are no intervals for the structure, this form does not allow'
       ,'creation of intervals records, so the user is not allowed to go into'
       ,'the block.'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 157);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,158
       ,'E'
       ,'Record must be ENTERED or DELETED first.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 158);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,159
       ,'E'
       ,'Inspection in progress; cannot create record.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 159);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,160
       ,'E'
       ,'Cannot delete structure, inspections exist.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 160);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,161
       ,'E'
       ,'Structure locked by another user'
       ,'The Structure cannot be deleted since it is locked by another user at'
       ,'this time.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 161);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,162
       ,'E'
       ,'Inspection batch number has already been downloaded.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 162);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,163
       ,'E'
       ,'Inspection exists for scheduled date.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 163);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,164
       ,'E'
       ,'Scheduled date must NOT be less than the current date.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 164);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,165
       ,'E'
       ,'Key is NOT available.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 165);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,166
       ,'E'
       ,'Invalid Structure/Inspection combination.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 166);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,167
       ,'E'
       ,'Inspection interval location error.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 167);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,168
       ,'E'
       ,'Cannot modify records with this application.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 168);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,169
       ,'I'
       ,'There are no road groups for the selected group type.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 169);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,170
       ,'E'
       ,'Cannot delete Attribute Group. Group Members exist'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 170);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,171
       ,'E'
       ,'Cannot delete Attribute Group. Group Permissions exists'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 171);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,172
       ,'E'
       ,'Enter (R)ead or (U)pdate'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 172);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,173
       ,'I'
       ,'There are no outstanding Inspections.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 173);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,174
       ,'I'
       ,'No records retrieved for specified selection criteria'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 174);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,175
       ,'I'
       ,'No structure attributes found for selected structure item'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 175);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,176
       ,'E'
       ,'You have not been granted any permissions on this attr group'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 176);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,177
       ,'S'
       ,'Unrecognised attribute group permission'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 177);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,178
       ,'E'
       ,'Item type and Attribute type already exist for this attr group'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 178);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,179
       ,'E'
       ,'Permission already exists for this User/Attribute Group'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 179);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,180
       ,'I'
       ,'Obtaining outstanding inspections.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 180);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,181
       ,'S'
       ,'Unable to retrieve attribute type details'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 181);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,182
       ,'S'
       ,'Unable to retrieve attribute value''s meaning'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 182);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,183
       ,'E'
       ,'Invalid District; Use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 183);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,184
       ,'E'
       ,'Invalid County; Use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 184);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,185
       ,'E'
       ,'No structures match these selection criteria. Please re-enter'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 185);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,186
       ,'E'
       ,'Invalid District/County combination'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 186);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,187
       ,'E'
       ,'You must enter at least one selection criteria'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 187);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,188
       ,'E'
       ,'Initial sequence number MUST be 1.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 188);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,189
       ,'E'
       ,'Attribute value cannot be made mandatory. Null values exist.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 189);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,190
       ,'E'
       ,'Entered attribute group name exists.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 190);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,191
       ,'E'
       ,'A single Primary Route must be nominated.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 191);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,192
       ,'E'
       ,'Numeric sequence must not contain gaps.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 192);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,193
       ,'E'
       ,'Invalid Road Id.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 193);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,194
       ,'E'
       ,'Invalid Inspection Set; Use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 194);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,195
       ,'E'
       ,'Cannot delete Inspection Set while Inspection Types exist'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 195);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,196
       ,'E'
       ,'Cannot delete Inspection Type while VALID INSP TYPES exist'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 196);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,197
       ,'E'
       ,'Intervals in the same inspection set must be integer multiples'
       ,'Intervals in an inspection set must be integer multiples/denominators of'
       ,'each other, and no two may be the same.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 197);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,198
       ,'E'
       ,'Incorrect hierarchy specified by intervals'
       ,'The intervals entered define an inspection hierarchy that is not the same'
       ,'as the hierarchy already defined by the mandated or preferred intervals.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 198);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,199
       ,'E'
       ,'Invalid Structure; use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 199);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,200
       ,'E'
       ,'Interval cannot equal preferred interval'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 200);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,201
       ,'E'
       ,'Inspected date must not be after today.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 201);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,202
       ,'I'
       ,'No inspectable items or attributes for this inspection.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 202);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,203
       ,'E'
       ,'Item locked by another user'
       ,'Try again later'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 203);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,204
       ,'W'
       ,'Numeric sequence must not contain gaps'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 204);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,205
       ,'W'
       ,'A single primary route must be nominated'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 205);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,206
       ,'W'
       ,'Re-sequencing intersections'
       ,'Occurs when an intersection is deleted which is not the last in the sequence'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 206);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,207
       ,'E'
       ,'You are not allowed to update a completed inspection record'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 207);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,208
       ,'E'
       ,'Inspection dated DD-MON-YYYY exceeds the mandatory interval'
       ,'This message is hard coded into the check_interval procedure in str3072'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 208);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,209
       ,'E'
       ,'Invalid batch id'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 209);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,210
       ,'E'
       ,'Invalid inspection type'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 210);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,211
       ,'E'
       ,'No structure with this name'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 211);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,212
       ,'E'
       ,'No structure with this reference'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 212);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,213
       ,'E'
       ,'No inspectable attributes for this inspection'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 213);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,214
       ,'W'
       ,'Selected Inspection Batch has already been downloaded.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 214);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,215
       ,'E'
       ,'Maximum severity must be greater than minimum severity.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 215);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,216
       ,'E'
       ,'Maximum extent must be greater than minimum extent.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 216);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,217
       ,'E'
       ,'Cannot enter a min or a max severity value separately.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 217);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,218
       ,'E'
       ,'Cannot enter a min or a max extent value separately.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 218);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,219
       ,'E'
       ,'The maximum variance is ?'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 219);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,220
       ,'E'
       ,'Inspection Set name already exists.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 220);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,221
       ,'E'
       ,'Inspection Type name already exists.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 221);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,222
       ,'E'
       ,'You must first enter an inspection date'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 222);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,223
       ,'E'
       ,'Attribute value is out of range'
       ,'Modify the attribute accordingly'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 223);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,224
       ,'E'
       ,'Lookup of Load Carrying Capacity failed'
       ,'Invalid values for attributes used in the calculation of the Appraisal'
       ,'Ratings has led to failure of lookup. Attribute values should be checked.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 224);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,225
       ,'E'
       ,'Lookup of Deck Geometry has failed'
       ,'Attributes used in the calculation of the Deck Geometry Appraisal Rating'
       ,'should be checked.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 225);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,226
       ,'E'
       ,'Lookup of (Railroad) Underclearance Vert/Horiz. has failed.'
       ,'Attributes used in the calculation of the Underclearance Appraisal Rating'
       ,'should be checked.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 226);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,227
       ,'E'
       ,'Lookup of Underclearance Vert/Horiz. has failed.'
       ,'Attributes used in the calculation of the Underclearance Appraisal Rating'
       ,'should be checked.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 227);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,228
       ,'E'
       ,'Calculation of Safe Capacity has failed'
       ,'Invalid values for attributes used in the calculation of the Appraisal'
       ,'Ratings has led to failure. Attribute values should be checked.'
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 228);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,229
       ,'E'
       ,'Invalid Stress value'
       ,'Invalid values for attributes used in the calculation of the Appraisal'
       ,'Ratings has led to failure to calculate a meaningful stress value during'
       ,'the calculation of safe capacity. Attribute values should be checked.'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 229);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,230
       ,'I'
       ,'This inspection value will not update the attribute value'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 230);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,231
       ,'E'
       ,'Record padded with spaces - incorrect attribute format'
       ,'Check the value of the attribute and change as required.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 231);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,232
       ,'E'
       ,'Record value overwritten  - incorrect attribute format'
       ,'Check the value of the attribute and change as required.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 232);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,233
       ,'E'
       ,'Cost summation causes number overflow'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 233);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,234
       ,'E'
       ,'Quantity summation causes number overflow'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 234);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,235
       ,'E'
       ,'A line for this item already exists on this estimate'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 235);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,236
       ,'E'
       ,'Invalid item number'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 236);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,237
       ,'E'
       ,'Cost calculation causes number overflow'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 237);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,238
       ,'E'
       ,'Invalid person'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 238);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,239
       ,'E'
       ,'Invalid structure'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 239);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,240
       ,'E'
       ,'Invalid group type'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 240);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,241
       ,'E'
       ,'Invalid group name'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 241);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,242
       ,'E'
       ,'There are no structures for this group'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 242);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,243
       ,'E'
       ,'This structure has already been selected for this item'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 243);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,244
       ,'E'
       ,'Invalid structure name'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 244);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,245
       ,'E'
       ,'This structure does not lie within the selected road group'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 245);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,246
       ,'E'
       ,'Group type and name must both be entered or both left null'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 246);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,247
       ,'E'
       ,'You must first select structures'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 247);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,248
       ,'E'
       ,'You must first select an item'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 248);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,249
       ,'E'
       ,'Item has been deleted'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 249);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,250
       ,'E'
       ,'Invalid estimate'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 250);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,251
       ,'E'
       ,'Sructures exist on this estimate which are not in this group'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 251);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,252
       ,'E'
       ,'Date raised cannot be greater than today'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 252);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,253
       ,'E'
       ,'Deletion not allowed while there are associated estimate lines'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 253);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,254
       ,'E'
       ,'Invalid unit'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 254);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,255
       ,'E'
       ,'Invalid BOQ section'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 255);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,256
       ,'E'
       ,'Use list of values to modify this field'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 256);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,257
       ,'E'
       ,'This structure is not in the selected district'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 257);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,258
       ,'E'
       ,'This structure is not in the selected county'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 258);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,259
       ,'E'
       ,'Lines exist on this estimate which are not in this district'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 259);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,260
       ,'E'
       ,'Lines exist on this estimate which are not in this county'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 260);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,261
       ,'E'
       ,'Lines are being modified by another user'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 261);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,262
       ,'E'
       ,'Identify structure before proceeding to the next block.'
       ,'Here, the user will have attempted to move into the next block.'
       ,'This block will be specific to a structure, therefore a structure must be'
       ,'entered within the first block. This will NOT have happened.'
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 262);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,263
       ,'E'
       ,'Invalid road group/group type combination.'
       ,'Validation failure due to invalid road group/group combination.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 263);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,264
       ,'E'
       ,'Attribute validation values are not found.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 264);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,265
       ,'E'
       ,'Attribute not found in temporary table.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 265);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,636
       ,'E'
       ,'Field must be fully entered.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 636);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,637
       ,'E'
       ,'Inspection date cannot precede current date'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 637);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,638
       ,'E'
       ,'Attribute missing'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 638);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,639
       ,'E'
       ,'Must enter either DART Query ID, Structure Type or Single Structure'
       ,'Please enter either the  DART Query ID, Structure Type or Single Structure'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 639);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,640
       ,'E'
       ,'Extent/Severity Combination already exists for %s1'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 640);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,641
       ,'E'
       ,'Ruleset name entered already exists.'
       ,'Please enter an alternative Ruleset name'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 641);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,642
       ,'E'
       ,'Element entered is either invalid or already exists within %s1'
       ,'Please enter an alternative Element...'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 642);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,643
       ,'E'
       ,'%s1 must be entered.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 643);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,644
       ,'E'
       ,'Could not create ruleset %s1. Please contact exor support.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 644);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,645
       ,'E'
       ,'Please highlight the ruleset you wish to copy prior to using this facility.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 645);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,646
       ,'E'
       ,'Defect Code entered is not valid with respect to Item and Severity. use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 646);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,647
       ,'E'
       ,'Defect Code entered is not valid for this Item type. use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 647);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,648
       ,'E'
       ,'Please select the Item/Defect Code Set you wish to copy prior to using this facility.'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 648);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,649
       ,'E'
       ,'A Defect Code Set for this Item Type already exist. Use [List]'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 649);
--
INSERT INTO HIG_ERRORS
       (HER_APPL
       ,HER_NO
       ,HER_TYPE
       ,HER_DESCR
       ,HER_ACTION_1
       ,HER_ACTION_2
       ,HER_ACTION_3
       ,HER_ACTION_4
       ,HER_ACTION_5
       ,HER_ACTION_6
       ,HER_ACTION_7
       )
SELECT 
        'STR'
       ,650
       ,'E'
       ,'The Defect Code/Severity combination specified already exists for this Item'
       ,''
       ,''
       ,''
       ,''
       ,''
       ,''
       ,'' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM HIG_ERRORS
                   WHERE HER_APPL = 'STR'
                    AND  HER_NO = 650);
--
--
--
----------------------------------------------------------------------------------------

--
COMMIT;
--
set feedback on
set define on
--
-------------------------------
-- END OF GENERATED METADATA --
-------------------------------
--
