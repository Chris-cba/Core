-----------------------------------------------------------------------------
--
--   PVCS Identifiers :-
--
--       PVCS id          : $Header:$
--       Module Name      : $Workfile:$
--       Date into PVCS   : $Date:$
--       Date fetched Out : $Modtime:$
--       Version          : $Revision:$
--       Table Owner      : STR_METADATA
--       Generation Date  : 10-DEC-2013 16:49
--
--   Product metadata script
--   As at Release 4.7.0.0
--
--   Copyright (c) exor corporation ltd, 2013
--
--   TABLES PROCESSED
--   ================
--   OBSTRUCTION_TYPES
--   STR_INSP_CYCLES
--
-----------------------------------------------------------------------------


set define off;
set feedback off;

---------------------------------
-- START OF GENERATED METADATA --
---------------------------------


----------------------------------------------------------------------------------------
-- OBSTRUCTION_TYPES
--
-- select * from str_metadata.obstruction_types
-- order by obt_id
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT obstruction_types
SET TERM OFF

INSERT INTO OBSTRUCTION_TYPES
       (OBT_ID
       ,OBT_UNITS
       ,OBT_NAME
       ,OBT_DESCR
       ,OBT_START_DATE
       ,OBT_END_DATE
       )
SELECT 
        'HGHT'
       ,'Metres'
       ,'Height'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM OBSTRUCTION_TYPES
                   WHERE OBT_ID = 'HGHT');
--
INSERT INTO OBSTRUCTION_TYPES
       (OBT_ID
       ,OBT_UNITS
       ,OBT_NAME
       ,OBT_DESCR
       ,OBT_START_DATE
       ,OBT_END_DATE
       )
SELECT 
        'LENG'
       ,'Metres'
       ,'Length'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM OBSTRUCTION_TYPES
                   WHERE OBT_ID = 'LENG');
--
INSERT INTO OBSTRUCTION_TYPES
       (OBT_ID
       ,OBT_UNITS
       ,OBT_NAME
       ,OBT_DESCR
       ,OBT_START_DATE
       ,OBT_END_DATE
       )
SELECT 
        'WGHT'
       ,'Tonnes'
       ,'Weight'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM OBSTRUCTION_TYPES
                   WHERE OBT_ID = 'WGHT');
--
INSERT INTO OBSTRUCTION_TYPES
       (OBT_ID
       ,OBT_UNITS
       ,OBT_NAME
       ,OBT_DESCR
       ,OBT_START_DATE
       ,OBT_END_DATE
       )
SELECT 
        'WIDT'
       ,'Metres'
       ,'Width'
       ,''
       ,null
       ,null FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM OBSTRUCTION_TYPES
                   WHERE OBT_ID = 'WIDT');
--
--
--
----------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------
-- STR_INSP_CYCLES
--
-- select * from str_metadata.str_insp_cycles
-- order by sic_id
--
----------------------------------------------------------------------------------------

SET TERM ON
PROMPT str_insp_cycles
SET TERM OFF

INSERT INTO STR_INSP_CYCLES
       (SIC_ID
       ,SIC_NAME
       ,SIC_START_DATE
       ,SIC_DESCR
       )
SELECT 
        1
       ,'Cycle 1'
       ,to_date('19930628154816','YYYYMMDDHH24MISS')
       ,'Initial Cycle' FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM STR_INSP_CYCLES
                   WHERE SIC_ID = 1);
--
--
--
----------------------------------------------------------------------------------------

--
COMMIT;
--
set feedback on
set define on
--
-------------------------------
-- END OF GENERATED METADATA --
-------------------------------
--
