--
-----------------------------------------------------------------------------
--
--   PVCS Identifiers :-
--
--       PVCS id          : $Header:   //vm_latest/archives/str/install/strdata_install.sql-arc   2.2   Jun 27 2013 10:04:02   James.Wadsworth  $
--       Module Name      : $Workfile:   strdata_install.sql  $
--       Date into PVCS   : $Date:   Jun 27 2013 10:04:02  $
--       Date fetched Out : $Modtime:   Jun 26 2013 15:38:28  $
--       Version          : $Revision:   2.2  $
--
--   Product upgrade script
--
-----------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
-----------------------------------------------------------------------------
--
set echo off
set linesize 120
set heading off
set feedback off

DECLARE
  l_temp nm3type.max_varchar2;
BEGIN
  -- Dummy call to HIG to instantiate it
  l_temp := hig.get_version;
  l_temp := nm_debug.get_version;
EXCEPTION
  WHEN others
   THEN
     Null;
END;
/
--
--
----------------------------------------------------------------------------
--Call a proc in nm_debug to instantiate it before calling metadata scripts.
--
--If this is not done any inserts into hig_option_values may fail due to
-- mutating trigger when nm_debug checks DEBUGAUTON.
----------------------------------------------------------------------------
BEGIN
  nm_debug.debug_off;
END;
/
--
--
---------------------------------------------------------------
--Strip out application metadata
-- Some application metadata was previously installed with Core
-- Metadata will be installed correctly with data files
---------------------------------------------------------------
--
SET TERM ON
Prompt removing application metadata ...
SET TERM OFF
SET DEFINE ON
delete  from hig_standard_favourites where (substr(hstf_parent,1,3) like 'STR%'  OR hstf_child = 'STR');
Commit;
/
--
--
SET TERM ON
Prompt Running strdata1...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'install'||
        '&terminator'||'strdata1' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
--
SET TERM ON
Prompt Running strdata2...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'install'||
        '&terminator'||'strdata2' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
--
SET TERM ON
Prompt Running strdata3...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'install'||
        '&terminator'||'strdata3' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
--
SET TERM ON
Prompt Running strdata4...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'install'||
        '&terminator'||'strdata4' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
--
SET TERM ON
Prompt Running strdata5...
SET TERM OFF
SET DEFINE ON
select '&exor_base'||'str'||'&terminator'||'install'||
        '&terminator'||'strdata5' run_file
from dual
/
SET FEEDBACK ON
start '&&run_file'
SET FEEDBACK OFF
--
--
COMMIT;
/

