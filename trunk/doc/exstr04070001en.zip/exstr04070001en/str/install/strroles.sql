------------------------------------------------------------------
--
--   PVCS Identifiers :-
--
--       PVCS id          : $Header:   //vm_latest/archives/str/install/strroles.sql-arc   2.3   Jun 27 2013 10:04:18   James.Wadsworth  $
--       Module Name      : $Workfile:   strroles.sql  $
--       Date into PVCS   : $Date:   Jun 27 2013 10:04:18  $
--       Date fetched Out : $Modtime:   Jun 26 2013 15:41:42  $
--       Version          : $Revision:   2.3  $
--
--
REM **************************************************************************
REM
REM	Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
REM
REM	This script creates a set of roles which may be granted to
REM	structures users.
REM
REM **************************************************************************

rem --------------------------------------------------------------------------
rem	Create a role for granting to the structures manager administrator.

set feedback off

PROMPT CREATE ROLE STR_ADMIN;

DECLARE
  role_exists Exception;
  Pragma Exception_Init(role_exists, -1921); 
BEGIN
  EXECUTE IMMEDIATE 'CREATE ROLE STR_ADMIN';
  NULL;
EXCEPTION
WHEN role_exists
THEN 
  Null;
END;
/

-- Grant the role to the user, with admin option
begin
   execute immediate 'grant str_admin to '||user;
   execute immediate 'grant str_admin to '||user||' with admin option';
end;
/

grant select any table to str_admin;
grant insert any table to str_admin;
grant update any table to str_admin;
grant delete any table to str_admin;
grant lock any table to str_admin;
grant create any table to str_admin;
grant create any view to str_admin;
grant execute any procedure to str_admin;
grant select any sequence to str_admin;
grant create session to str_admin;

grant alter session to str_admin;
grant create public synonym to str_admin;
grant create trigger to str_admin;
grant create sequence to str_admin;
grant create role to str_admin;
grant create synonym to str_admin;
grant create procedure to str_admin;
grant create user to str_admin;
grant grant any privilege to str_admin;
grant grant any role to str_admin;
grant drop public synonym to str_admin;
grant drop user to str_admin;
grant alter user to str_admin;


rem --------------------------------------------------------------------------
rem	Create a role for granting to users who need update privileges.

PROMPT CREATE ROLE STR_USER;

DECLARE
  role_exists Exception;
  Pragma Exception_Init(role_exists, -1921); 
BEGIN
  EXECUTE IMMEDIATE 'CREATE ROLE STR_USER';
  NULL;
EXCEPTION
WHEN role_exists
THEN 
  Null;
END;
/

-- Grant the role to the user, with admin option
begin
   execute immediate 'grant str_user to '||user;
   execute immediate 'grant str_user to '||user||' with admin option';
end;
/

grant select any table to str_user;
grant insert any table to str_user;
grant update any table to str_user;
grant delete any table to str_user;
grant lock any table to str_user;
grant create table to str_user;
grant create view  to str_user;
grant select any sequence to str_user;
grant execute any procedure to str_user;
grant create session to str_user;


rem --------------------------------------------------------------------------
rem	Create a role for granting to readonly users.

PROMPT CREATE ROLE STR_READONLY;

DECLARE
  role_exists Exception;
  Pragma Exception_Init(role_exists, -1921); 
BEGIN
  EXECUTE IMMEDIATE 'CREATE ROLE STR_READONLY';
  NULL;
EXCEPTION
WHEN role_exists
THEN 
  Null;
END;
/

-- Grant the role to the user, with admin option
begin
   execute immediate 'grant str_readonly to '||user;
   execute immediate 'grant str_readonly to '||user||' with admin option';
end;
/

grant select any table to str_readonly;
grant lock any table to str_readonly;
grant create table to str_readonly;
grant create view  to str_readonly;
grant select any sequence to str_readonly;
grant execute any procedure to str_readonly;
grant create session to str_readonly;

grant insert,update,delete on str_pbi_query to str_readonly;
grant insert,update,delete on str_pbi_query_attribs to str_readonly;
grant insert,update,delete on str_pbi_query_types to str_readonly;
grant insert,update,delete on str_pbi_results to str_readonly;
grant insert,update,delete on str_pbi_sql to str_readonly;
grant insert,update,delete on report_tags to str_readonly;

rem ---------------------------------------------------------------------------
rem These roles can now be assigned to Oracle users.

REM End of command file
REM
