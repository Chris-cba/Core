-----------------------------------------------------------------------------
-- strviews.sql
-----------------------------------------------------------------------------
--   PVCS Identifiers :-
--
--       pvcsid                 : $Header:   //vm_latest/archives/str/install/strviews.sql-arc   2.2   Jun 27 2013 10:04:18   James.Wadsworth  $
--       Module Name      : $Workfile:   strviews.sql  $
--       Date into PVCS   : $Date:   Jun 27 2013 10:04:18  $
--       Date fetched Out : $Modtime:   Jun 26 2013 15:38:28  $
--       PVCS Version     : $Revision:   2.2  $
--
--
--  STR v3 views installation script
--  Created on 17/03/97 for Structures implementation
--
--  CP 24/03/2004 Remove view creation statements from this script (now in str.vw)
--
-----------------------------------------------------------------------------
--   Copyright (c) 2013 Bentley Systems Incorporated. All rights reserved.
-----------------------------------------------------------------------------

set feedback off;

SET define ON
SELECT '&exor_base'||'str'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'str_items_all.vw' run_file
FROM dual
/
START '&run_file'

SET define ON
SELECT '&exor_base'||'str'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'str_items_all_historic.vw' run_file
FROM dual
/
START '&run_file'

SET define ON
SELECT '&exor_base'||'str'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'road_intersections.vw' run_file
FROM dual
/
START '&run_file'
--
SET define ON
SELECT '&exor_base'||'str'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'str_admin_units.vw' run_file
FROM dual
/
START '&run_file'

SET define ON
SELECT '&exor_base'||'str'||'&terminator'||'admin'||
'&terminator'||'views'||'&terminator'||'str_insp_completed.vw' run_file
FROM dual
/
START '&run_file'


